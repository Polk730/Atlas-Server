document.querySelector('#mobile-login').addEventListener('submit',async event=>{
  event.preventDefault();const button=event.target.querySelector('button'),error=document.querySelector('#error');button.disabled=true;button.textContent='Anmeldung läuft …';error.textContent='';
  try{const response=await fetch('/api/mobile/login',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-Atlas-Client':'atlas-web'},body:JSON.stringify({email:document.querySelector('#email').value,password:document.querySelector('#password').value})});const result=await response.json();document.querySelector('#password').value='';if(!response.ok)throw new Error(result.error||'Die Anmeldung ist fehlgeschlagen.');location.replace('/atlas');}
  catch(failure){error.textContent=failure.message||'Keine Verbindung zu Atlas.';button.disabled=false;button.textContent='Anmelden ↗';}
});
