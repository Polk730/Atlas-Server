/* Shared rules for online rooms and two players on one device. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('node:crypto'));else root.AtlasPartyEngine=factory({randomInt(min,max){if(max===undefined){max=min;min=0;}const range=max-min,limit=Math.floor(4294967296/range)*range;let value;do{value=root.crypto.getRandomValues(new Uint32Array(1))[0];}while(value>=limit);return min+value%range;}});})(typeof globalThis==='object'?globalThis:this,function(crypto){
'use strict';
const ids=['rps','pig','nim','dots','gomoku','code'];
const isExtra=id=>ids.includes(id);
const fail=t=>{throw new Error(t);};
function finish(r,w,why){r.phase='finished';r.winner=w;r.reason=why;if(w){const p=r.players.find(p=>p.id===w);if(p)p.score=Math.max(1,p.score);}r.version++;}
function next(r){const i=r.players.findIndex(p=>p.id===r.turn);r.turn=r.players[(i+1)%r.players.length].id;r.deadline=Date.now()+45000;}
function init(r){r.phase='party-play';r.turn=r.players[0].id;r.deadline=Date.now()+45000;r.party={};
 if(r.game==='rps'){r.party={round:1,choices:{},reveal:null};r.deadline=Date.now()+15000;}
 if(r.game==='pig')r.party={pot:0,last:0};
 if(r.game==='nim')r.party={piles:[3,5,7]};
 if(r.game==='dots')r.party={edges:[],boxes:Array(9).fill(null)};
 if(r.game==='gomoku')r.party={grid:Array(169).fill(0)};
 if(r.game==='code')r.party={secret:Array.from({length:4},()=>crypto.randomInt(1,7)).join(''),history:[]};
}
function rpsResult(r){const a=r.players[0],b=r.players[1],x=r.party.choices[a.id],y=r.party.choices[b.id];let w=null;if(x&&!y)w=a;else if(y&&!x)w=b;else if(x&&y&&x!==y)w=({rock:'scissors',scissors:'paper',paper:'rock'}[x]===y?a:b);if(w)w.score++;r.party.reveal={choices:{...r.party.choices},winner:w?.id||null};r.phase='party-reveal';r.nextAt=Date.now()+3000;r.version++;}
function advance(r){if(r.phase==='lobby'||r.phase==='finished')return;
 const left=r.players.filter(p=>p.left||Date.now()-p.seen>20000);if(left.length){const alive=r.players.filter(p=>!left.includes(p));finish(r,alive.length===1?alive[0].id:null,'Ein Spieler hat die Verbindung verlassen.');return;}
 if(r.game==='rps'){if(r.phase==='party-play'&&(Date.now()>=r.deadline||r.players.every(p=>r.party.choices[p.id])))rpsResult(r);if(r.phase==='party-reveal'&&Date.now()>=r.nextAt){if(r.party.round>=5){const [a,b]=r.players;finish(r,a.score===b.score?null:a.score>b.score?a.id:b.id,'Fünf Runden gespielt.');}else{r.party.round++;r.party.choices={};r.phase='party-play';r.deadline=Date.now()+15000;r.version++;}}return;}
 if(Date.now()>=r.deadline){finish(r,r.players.find(p=>p.id!==r.turn)?.id||null,'45 Sekunden ohne Zug.');}
}
function snapshot(r,p){const data={...r.party};delete data.secret;
 if(r.game==='rps'){data.submitted=!!r.party.choices[p.id];delete data.choices;}
 if(r.game==='code'&&r.phase==='finished')data.solution=r.party.secret;
 return {party:data,turn:r.turn,deadline:r.deadline,nextAt:r.nextAt,winner:r.winner,reason:r.reason};
}
function action(r,p,type,input){if(type!=='party')return false;if(!isExtra(r.game)||r.phase!=='party-play')fail('Diese Runde ist bereits beendet.');if(input.version!==r.version)fail('Spielstand aktualisiert. Versuche es erneut.');const d=r.party,v=input.value;
 if(r.game==='rps'){if(!['rock','paper','scissors'].includes(v)||d.choices[p.id])fail('Wähle genau einmal.');d.choices[p.id]=v;/* no public revision leak of secret choices */advance(r);return true;}
 if(p.id!==r.turn)fail('Du bist noch nicht am Zug.');
 if(r.game==='pig'){if(!['roll','bank'].includes(v))fail('Ungültige Würfelaktion.');if(v==='roll'){d.last=crypto.randomInt(1,7);if(d.last===1){d.pot=0;next(r);}else{d.pot+=d.last;r.deadline=Date.now()+45000;}}else{p.score+=d.pot;d.pot=0;if(p.score>=50)finish(r,p.id,'50 Punkte gesichert!');else next(r);}}
 if(r.game==='nim'){const {pile,count}=input;if(!Number.isInteger(pile)||pile<0||pile>2||!Number.isInteger(count)||count<1||count>d.piles[pile])fail('Wähle verfügbare Steine aus einem Haufen.');d.piles[pile]-=count;if(d.piles.every(n=>!n))finish(r,p.id,'Der letzte Stein gehört dir.');else next(r);}
 if(r.game==='gomoku'){const i=input.cell;if(!Number.isInteger(i)||i<0||i>=169||d.grid[i])fail('Wähle ein freies Feld.');const mark=r.players.indexOf(p)+1;d.grid[i]=mark;const x=i%13,y=Math.floor(i/13);let won=false;for(const [dx,dy]of [[1,0],[0,1],[1,1],[1,-1]]){let n=1;for(const dir of [-1,1])for(let k=1;k<5;k++){const xx=x+dx*k*dir,yy=y+dy*k*dir;if(xx<0||xx>=13||yy<0||yy>=13||d.grid[yy*13+xx]!==mark)break;n++;}if(n>=5)won=true;}if(won)finish(r,p.id,'Fünf Steine in einer Reihe.');else if(d.grid.every(Boolean))finish(r,null,'Unentschieden.');else next(r);}
 if(r.game==='dots'){const edge=input.edge;if(!Number.isInteger(edge)||edge<0||edge>=24||d.edges.includes(edge))fail('Wähle eine freie Kante.');d.edges.push(edge);let claimed=0;for(let y=0;y<3;y++)for(let x=0;x<3;x++){const i=y*3+x;if(!d.boxes[i]&&[y*3+x,(y+1)*3+x,12+y*4+x,12+y*4+x+1].every(e=>d.edges.includes(e))){d.boxes[i]=p.id;p.score++;claimed++;}}if(d.boxes.every(Boolean)){const [a,b]=r.players;finish(r,a.score>b.score?a.id:b.id,'Alle neun Kästchen vergeben.');}else if(!claimed)next(r);else r.deadline=Date.now()+45000;}
 if(r.game==='code'){const guess=String(v||'');if(!/^[1-6]{4}$/.test(guess))fail('Vier Ziffern zwischen 1 und 6 eingeben.');const secret=d.secret;let exact=0,total=0;for(let i=0;i<4;i++)if(guess[i]===secret[i])exact++;for(let n=1;n<=6;n++)total+=Math.min([...guess].filter(x=>x===String(n)).length,[...secret].filter(x=>x===String(n)).length);d.history.push({player:p.name,guess,exact,near:total-exact});if(exact===4)finish(r,p.id,'Code geknackt!');else if(d.history.length>=20)finish(r,null,'20 Versuche vorbei.');else next(r);}
 r.version++;return true;
}
return {isExtra,init,advance,snapshot,action};
});
