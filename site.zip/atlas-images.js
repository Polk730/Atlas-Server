/* Images stay in this device's IndexedDB; chat sync carries references only. */
let pendingChatImage = null;
let preparingChatImage = false;
let atlasImageDatabase;
function openAtlasImages() {
  if (!atlasImageDatabase) atlasImageDatabase = new Promise((resolve,reject) => {
    const request = indexedDB.open('atlas-image-attachments',1);
    request.onupgradeneeded = () => request.result.createObjectStore('images',{keyPath:'id'});
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => { atlasImageDatabase=null; reject(new Error('Bilder können auf diesem Gerät nicht gespeichert werden.')); };
  });
  return atlasImageDatabase;
}
async function atlasImageStore(action,value) {
  const db=await openAtlasImages();
  return new Promise((resolve,reject) => {
    const transaction=db.transaction('images',action==='put'?'readwrite':'readonly');
    const request=transaction.objectStore('images')[action](value);
    transaction.oncomplete=()=>resolve(request.result);
    transaction.onerror=()=>reject(new Error('Das Bild konnte nicht gespeichert werden. Prüfe den freien Speicherplatz.'));
    transaction.onabort=()=>reject(new Error('Das Bild konnte nicht gespeichert werden.'));
  });
}
function renderPendingImage() {
  const host=document.querySelector('#image-preview');host.replaceChildren();
  if (!pendingChatImage) return;
  const image=document.createElement('img');image.src=pendingChatImage.url;image.alt='Angehängtes Bild';
  const label=document.createElement('span');label.textContent=pendingChatImage.name;
  const remove=document.createElement('button');remove.type='button';remove.textContent='×';remove.title='Bild entfernen';remove.setAttribute('aria-label','Bild entfernen');
  remove.onclick=()=>{pendingChatImage=null;renderPendingImage();};host.append(image,label,remove);
}
async function prepareChatImage(file) {
  if (preparingChatImage || currentChatRequest) { toast('Bitte warte, bis Atlas fertig ist.');return; }
  if (!file || !['image/png','image/jpeg','image/webp'].includes(file.type)) { toast('Bitte ein PNG-, JPG- oder WebP-Bild wählen.',{error:true});return; }
  if (file.size>15*1024*1024) { toast('Bitte ein Bild unter 15 MB wählen.',{error:true});return; }
  preparingChatImage=true;const button=document.querySelector('#attach-image');button.disabled=true;
  let bitmap;
  try {
    bitmap=await createImageBitmap(file,{imageOrientation:'from-image'});
    if(bitmap.width*bitmap.height>40000000)throw new Error('Dieses Bild hat zu viele Pixel. Bitte verkleinere es.');
    const scale=Math.min(1,2048/Math.max(bitmap.width,bitmap.height));
    const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));
    const context=canvas.getContext('2d');context.fillStyle='#fff';context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(bitmap,0,0,canvas.width,canvas.height);
    const url=canvas.toDataURL('image/jpeg',0.85);
    if(url.length>2800000)throw new Error('Das Bild ist nach dem Verkleinern noch zu gross. Bitte einen kleineren Ausschnitt verwenden.');
    pendingChatImage={id:makeId(),name:(file.name||'Eingefügtes Bild').slice(0,120),mimeType:'image/jpeg',url};
    renderPendingImage();promptBox.focus();
  } catch(error){toast(error.message||'Das Bild konnte nicht gelesen werden.',{error:true});}
  finally{bitmap?.close();preparingChatImage=false;button.disabled=false;}
}
async function hydrateAtlasImages(context) {
  const result=context.map(message=>({...message}));let count=0;
  for(const message of [...result].reverse()) {
    const reference=message.attachments?.[0];delete message.attachments;
    if(!reference)continue;
    if(++count>4){message.text+='\n[Dieses ältere Bild ist nicht im aktuellen Bildkontext.]';continue;}
    const stored=await atlasImageStore('get',reference.id);
    if(!stored){message.text+='\n[Das zugehörige Bild ist auf diesem Gerät nicht verfügbar. Bitte bei Bedarf erneut anhängen.]';continue;}
    message.images=[{mimeType:stored.mimeType,data:stored.url.split(',')[1]}];
  }
  return result;
}

(() => {
  const style=document.createElement('style');style.textContent=`
    #image-preview{display:flex;align-items:center;gap:12px;overflow:hidden}
    #image-preview:not(:empty){padding:0 4px 12px;animation:image-arrive .22s ease-out}
    #image-preview img{width:68px;height:68px;object-fit:cover;border-radius:12px;border:1px solid #ffffff30}
    #image-preview span{font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:inherit}
    #image-preview button{border:0;border-radius:50%;background:#ffffff15;color:inherit;width:28px;height:28px;cursor:pointer}
    .message-image{display:block;max-width:min(380px,100%);max-height:340px;object-fit:contain;border-radius:14px;margin-top:12px;border:1px solid #ffffff20}
    .image-missing{display:block;color:#adb2c0;font-size:12px;margin-top:8px}
    .composer.image-drop{outline:2px solid #9a87ff;box-shadow:0 0 24px #9a87ff30}
    .image-note{font-size:10px;color:#969baa;margin:6px 4px 0}
    @keyframes image-arrive{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}
    @media(prefers-reduced-motion:reduce){#image-preview:not(:empty){animation:none}}
  `;document.head.append(style);
  const form=document.querySelector('#chat-form');
  const preview=document.createElement('div');preview.id='image-preview';preview.setAttribute('aria-live','polite');form.prepend(preview);
  const picker=document.createElement('input');picker.type='file';picker.accept='image/png,image/jpeg,image/webp';picker.hidden=true;
  picker.onchange=()=>{prepareChatImage(picker.files?.[0]);picker.value='';};form.append(picker);
  const button=document.createElement('button');button.type='button';button.id='attach-image';button.className='icon-button';button.title='Bild hinzufügen (oder einfügen / hierher ziehen)';button.setAttribute('aria-label','Bild hinzufügen');button.textContent='⊕';button.onclick=()=>picker.click();
  document.querySelector('.tool-actions').prepend(button);
  const note=document.createElement('p');note.className='image-note';note.textContent='Bildanhänge bleiben auf diesem Gerät gespeichert und werden für deine Anfrage auf dem Atlas-Server analysiert.';form.after(note);
  if(!window.samuelDesktop?.serverOnly&&window.samuelDesktop?.installVisionModel){
    const install=document.createElement('button');install.type='button';install.className='secondary-button';install.textContent='Lokales Bildmodell laden · ca. 3,3 GB';install.style.cssText='font-size:10px;margin:6px 4px;padding:5px 8px';note.after(install);
    install.onclick=async()=>{
      install.disabled=true;
      const stop=window.samuelDesktop.onLocalProgress(progress=>{if(progress.model==='gemma3:4b')install.textContent=progress.percent===null?progress.status:`Bildmodell lädt · ${progress.percent} %`;});
      try{await window.samuelDesktop.installVisionModel();install.textContent='Bildmodell bereit';toast('Das lokale Bildmodell ist bereit. Du kannst jetzt ein Bild senden.');}
      catch(error){install.textContent='Lokales Bildmodell laden · ca. 3,3 GB';toast(String(error.message).replace(/^Error invoking remote method .*?: Error: /,''),{error:true});}
      finally{stop?.();install.disabled=false;}
    };
  }
  promptBox.addEventListener('paste',event=>{const item=[...(event.clipboardData?.items||[])].find(item=>item.type.startsWith('image/'));if(item){event.preventDefault();prepareChatImage(item.getAsFile());}});
  let dragDepth=0;
  form.addEventListener('dragenter',event=>{if(event.dataTransfer?.types.includes('Files')){event.preventDefault();dragDepth++;form.classList.add('image-drop');}});
  form.addEventListener('dragover',event=>{if(event.dataTransfer?.types.includes('Files'))event.preventDefault();});
  form.addEventListener('dragleave',()=>{if(--dragDepth<=0){dragDepth=0;form.classList.remove('image-drop');}});
  form.addEventListener('drop',event=>{event.preventDefault();dragDepth=0;form.classList.remove('image-drop');prepareChatImage(event.dataTransfer?.files?.[0]);});
  // Prevent Electron navigation when a file is dropped outside the composer.
  document.addEventListener('dragover',event=>{if(event.dataTransfer?.types.includes('Files'))event.preventDefault();});
  document.addEventListener('drop',event=>{if(event.dataTransfer?.types.includes('Files'))event.preventDefault();});
  const originalAddBubble=addBubble;
  addBubble=function(item){
    const bubble=originalAddBubble(item);
    const reference=item.attachments?.[0];
    if(reference){
      const placeholder=document.createElement('span');placeholder.className='image-missing';placeholder.textContent='Bild wird geladen …';bubble.append(placeholder);
      atlasImageStore('get',reference.id).then(stored=>{
        if(!stored){placeholder.textContent='Bild auf diesem Gerät nicht verfügbar – bitte erneut anhängen.';return;}
        const image=document.createElement('img');image.className='message-image';image.alt=reference.name||'Angehängtes Bild';image.src=stored.url;placeholder.replaceWith(image);
      }).catch(()=>{placeholder.textContent='Bild konnte nicht geladen werden.';});
    }
    return bubble;
  };
  renderChat();
})();
