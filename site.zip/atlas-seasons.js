/* Seasonal atmosphere: CSS-composited motion, no per-frame JavaScript. */
(()=>{'use strict';
if(typeof uiPreferences==='undefined'||document.getElementById('atlas-season-scene'))return;
const names={spring:'Frühling',summer:'Sommer',autumn:'Herbst',winter:'Winter'};
const palettes={spring:['rose','#132c27','#3f2947','143,226,183','#9ae6bd','#4fa782'],summer:['ocean','#12394c','#48502b','113,213,237','#8bdcec','#3b9bb7'],autumn:['amber','#39241b','#562a30','243,184,111','#f3bd80','#bc7945'],winter:['ocean','#101f38','#263953','161,204,247','#b0d7fc','#6096d2']};
const seasonalKeys=['--theme-rgb','--accent','--accent-strong','--theme-backdrop','--theme-sidebar','--theme-topbar','--theme-card','--theme-card-raised','--theme-border','--theme-glow'];
uiPreferences.backgroundMode=uiPreferences.backgroundMode==='seasons'?'seasons':'colors';
uiPreferences.seasonChoice=Object.hasOwn(names,uiPreferences.seasonChoice)?uiPreferences.seasonChoice:'auto';
uiPreferences.seasonAnimation=uiPreferences.seasonAnimation!==false;
const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
const scene=el('div','season-scene');scene.id='atlas-season-scene';scene.setAttribute('aria-hidden','true');document.body.prepend(scene);
const heading=document.querySelector('.theme-heading'),presets=document.querySelector('.theme-presets');if(!heading||!presets)return;
heading.querySelector('h3').textContent='Erscheinungsbild';heading.querySelector('p').textContent='Farben oder eine animierte Jahreszeit für Atlas.';
const switcher=el('div','appearance-switch');switcher.setAttribute('role','group');switcher.setAttribute('aria-label','Hintergrundmodus');
const buttons={};for(const [key,label]of [['colors','Farben'],['seasons','Jahreszeiten']]){const b=el('button','',label);b.type='button';b.onclick=()=>{uiPreferences.backgroundMode=key;saveUIPreferences();refresh();};buttons[key]=b;switcher.append(b);}
heading.after(switcher);
const controls=el('div','season-settings'),label=el('label','season-select-label','Jahreszeit'),select=el('select');select.setAttribute('aria-label','Jahreszeit auswählen');
for(const [value,text]of [['auto','Automatisch · aktuelle Jahreszeit'],...Object.entries(names)]){const o=el('option','',text);o.value=value;select.append(o);}label.append(select);
const cards=el('div','season-cards');for(const [key,name]of Object.entries(names)){const b=el('button','season-card');b.type='button';b.dataset.season=key;b.setAttribute('aria-label',name+' als Hintergrund');const art=el('span','season-card-art');art.setAttribute('aria-hidden','true');art.append(el('i'),el('i'),el('i'));b.append(art,el('strong','',name));b.onclick=()=>{uiPreferences.seasonChoice=key;saveUIPreferences();refresh();};cards.append(b);}
const motion=el('label','season-motion'),check=el('input');check.type='checkbox';check.onchange=()=>{uiPreferences.seasonAnimation=check.checked;saveUIPreferences();refresh();};motion.append(check,el('span','','Hintergrund animieren'));
const status=el('p','preference-status');status.setAttribute('aria-live','polite');controls.append(label,cards,motion,status);presets.after(controls);
select.onchange=()=>{uiPreferences.seasonChoice=select.value;saveUIPreferences();refresh();};
function currentSeason(){const m=new Date().getMonth();return m>=2&&m<=4?'spring':m>=5&&m<=7?'summer':m>=8&&m<=10?'autumn':'winter';}
let shown='',month=-1;
function refresh(){const seasonal=uiPreferences.backgroundMode==='seasons',key=Object.hasOwn(names,uiPreferences.seasonChoice)?uiPreferences.seasonChoice:currentSeason();
for(const [mode,b]of Object.entries(buttons))b.setAttribute('aria-pressed',String(mode===uiPreferences.backgroundMode));presets.hidden=seasonal;controls.hidden=!seasonal;scene.hidden=!seasonal;
select.value=uiPreferences.seasonChoice||'auto';check.checked=uiPreferences.seasonAnimation!==false;
for(const b of cards.children)b.setAttribute('aria-pressed',String(b.dataset.season===key));
status.textContent=(select.value==='auto'?'Automatisch: ':'Ausgewählt: ')+names[key]+'.'+(select.value==='auto'?' Wechselt mit dem Datum (Nordhalbkugel).':' Wähle „Automatisch“, um der aktuellen Jahreszeit zu folgen.');
scene.dataset.motion=String(check.checked);month=new Date().getMonth();
if(!seasonal){delete document.body.dataset.season;seasonalKeys.forEach(k=>document.body.style.removeProperty(k));return;}
document.body.dataset.season=key;const [,base,glow,rgb,accent,strong]=palettes[key],style=document.body.style;
const values=[rgb,accent,strong,`radial-gradient(ellipse at 78% 12%,${glow},transparent 65%),${base}`,`linear-gradient(180deg,${base}f5,${base}ed)`,base+'e8',base+'eb',base,accent+'30',accent];
seasonalKeys.forEach((k,i)=>style.setProperty(k,values[i]));
if(shown!==key){shown=key;scene.dataset.season=key;scene.replaceChildren(el('div','season-haze'),el('div','season-sun'),el('div','season-cloud cloud-one'),el('div','season-cloud cloud-two'),el('div','season-hill hill-back'),el('div','season-hill hill-front'));
const particles=el('div','season-particles');const count=matchMedia('(max-width: 650px)').matches?16:28;
for(let i=0;i<count;i++){const p=el('i','season-particle');p.style.setProperty('--x',((i*37+11)%101)+'%');p.style.setProperty('--delay',(-i*1.37)+'s');p.style.setProperty('--duration',(key==='summer'?18+i%7:11+i%9)+'s');p.style.setProperty('--size',(key==='winter'?3+i%5:7+i%7)+'px');p.style.setProperty('--drift',(-70+(i*23)%160)+'px');particles.append(p);}scene.append(particles,el('div','season-vignette'));}
}
const oldApply=applyTheme;applyTheme=function(...args){const result=oldApply(...args);refresh();return result;};
const syncVisibility=()=>scene.dataset.paused=String(document.hidden||!document.getElementById('games-view')?.classList.contains('hidden'));
document.addEventListener('visibilitychange',()=>{syncVisibility();if(!document.hidden)refresh();});
const games=document.getElementById('games-view');if(games)new MutationObserver(syncVisibility).observe(games,{attributes:true,attributeFilter:['class']});
setInterval(()=>{if(!document.hidden&&new Date().getMonth()!==month)refresh();},60000);
refresh();syncVisibility();
})();
