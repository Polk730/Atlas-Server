(() => {
const apple=/iPad|iPhone|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1),standalone=matchMedia('(display-mode: standalone)').matches||navigator.standalone===true;
if(!apple)return;document.documentElement.classList.add('atlas-apple-device');if(standalone)document.documentElement.classList.add('atlas-ios-standalone');
if('serviceWorker' in navigator&&location.protocol==='https:')navigator.serviceWorker.register('/atlas-pwa-sw.js',{scope:'/'}).catch(()=>{});
})();
