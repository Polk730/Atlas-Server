/* Fixed-step board physics. Online movement and damage are server-owned. */
(function(root,factory){'use strict';const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.AtlasStickEngine=api;})(typeof globalThis==='object'?globalThis:this,function(){
'use strict';
const W=1280,H=720,DT=1/120,RULES_VERSION=11,WHEEL_RADIUS=20,WHEEL_BASE=78;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const weapons=[{name:'Doppelaxt',length:142,radius:26,power:1.05},{name:'Speer',length:175,radius:14,power:.85},{name:'Streithammer',length:127,radius:30,power:1.2},{name:'Schwert',length:158,radius:18,power:.95}];
const maps=[
 {name:'Mondtal',width:2600,height:1100,theme:0,points:[[90,560],[320,690],[660,850],[1050,930],[1550,930],[1940,850],[2280,690],[2510,560]]},
 {name:'Canyon-Rallye',width:3000,height:1200,theme:1,points:[[90,650],[450,810],[850,960],[1200,960],[1500,800],[1800,960],[2150,960],[2550,810],[2910,650]]},
 {name:'Bambus-Pass',width:2800,height:1200,theme:2,points:[[90,660],[450,820],[840,820],[1110,700],[1400,880],[1690,700],[1960,820],[2350,820],[2710,660]]},
 {name:'Frostwellen',width:3200,height:1200,theme:3,points:[[90,650],[400,800],[760,940],[1100,810],[1430,980],[1770,980],[2100,810],[2440,940],[2800,800],[3110,650]]},
 {name:'Neon-Boulevard',width:3400,height:1100,theme:4,points:[[90,650],[440,820],[1020,820],[1360,940],[2040,940],[2380,820],[2960,820],[3310,650]]},
 {name:'Krater-Kolosseum',width:3000,height:1250,theme:5,points:[[90,580],[420,770],[800,980],[1200,1050],[1500,930],[1800,1050],[2200,980],[2580,770],[2910,580]]}
];
const terrains=maps.map(m=>m.points);
function random(s){s.seed=(Math.imul(s.seed,1664525)+1013904223)>>>0;return s.seed/4294967296;}
function map(s){return maps[s.arena]||maps[0];}
function ground(s,x){const pts=map(s).points;if(x<=pts[0][0])return {y:pts[0][1],slope:0};for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1];if(x<=b[0])return {y:a[1]+(b[1]-a[1])*(x-a[0])/(b[0]-a[0]),slope:(b[1]-a[1])/(b[0]-a[0])};}return {y:pts.at(-1)[1],slope:0};}
// Rider and board have independent geometry. Gravity acts at the board.
function held(p){return Number.isInteger(p.grabbedBy);}
function point(p,x,y){return {x:(held(p)?p.riderX:p.x+(p.bodyX||0))+x,y:(held(p)?p.riderY:p.y+(p.bodyY||0))+y};}
function boardPoint(p,x,y){const c=Math.cos(p.boardAngle||0),s=Math.sin(p.boardAngle||0);return {x:p.x+x*c-y*s,y:p.y+x*s+y*c};}
function wheels(p){return [boardPoint(p,-WHEEL_BASE/2,22),boardPoint(p,WHEEL_BASE/2,22)];}
function support(s,p){const [a,b]=wheels(p);return Math.min(ground(s,a.x).y-(a.y-p.y)-WHEEL_RADIUS,ground(s,b.x).y-(b.y-p.y)-WHEEL_RADIUS);}
function geometry(p,s){const shoulder=point(p,0,-89),head=point(p,0,-126),hip=point(p,0,-45),w=weapons[s.weapon];const tip={x:shoulder.x+Math.cos(p.weaponAngle)*w.length,y:shoulder.y+Math.sin(p.weaponAngle)*w.length};return {shoulder,head,hip,tip,tail:{x:shoulder.x-Math.cos(p.weaponAngle)*43,y:shoulder.y-Math.sin(p.weaponAngle)*43}};}
function resetRound(s){s.round++;const previous=s.arena;s.arena=Math.floor(random(s)*maps.length);if(s.round>1&&s.arena===previous)s.arena=(s.arena+1)%maps.length;if(s.options.arena>=0)s.arena=s.options.arena;s.weapon=s.options.weapon>=0?s.options.weapon:Math.floor(random(s)*weapons.length);s.phase='countdown';s.until=s.time+2;s.roundStarted=s.time+2;s.roundWinner=-1;s.lastHit=null;s.clashContact=false;s.clashUntil=0;s.drops=[];s.nextDrop=s.time+7+random(s)*3;s.reason='';const m=map(s);s.fighters=[0,1].map(i=>{const x=m.width/2+(i?310:-310),p={x,y:0,vx:0,vy:0,angle:0,boardAngle:0,wheelAngle:0,weaponAngle:i?Math.PI+.26:-.26,wv:0,facing:i?-1:1,hp:100,hurtUntil:0,flashUntil:0,dir:0,seq:-1,inputAt:-100,grounded:true,grabbedBy:null,riderX:null,riderY:null,bodyX:0,bodyY:0,bodyVX:0,bodyVY:0,recoilUntil:0,combo:0,lastAttackAt:-100,item:null,boostUntil:0,boostDir:0,shieldUntil:0,useSeq:0,aiNext:0,aiDir:0};p.boardAngle=Math.atan(ground(s,x).slope);p.y=support(s,p);return p;});}
function create(seed,settings={}){const options={arena:Number.isInteger(settings.arena)&&settings.arena>=0&&settings.arena<maps.length?settings.arena:-1,weapon:Number.isInteger(settings.weapon)&&settings.weapon>=0&&settings.weapon<weapons.length?settings.weapon:-1,difficulty:['easy','normal','hard'].includes(settings.difficulty)?settings.difficulty:'normal'};const s={options,stats:[0,1].map(()=>({hits:0,headshots:0,grabs:0,damage:0,drain:0,bestCombo:0})),clashId:0,lastClash:null,dropId:0,itemId:0,lastItem:null,rulesVersion:RULES_VERSION,seed:seed>>>0,time:0,round:0,stars:[0,0],winner:-1,phase:'countdown',until:0,arena:0,weapon:0,hitId:0,lastHit:null,fighters:[]};resetRound(s);return s;}
const items={boost:{name:'Raketenboost',color:'#ff9b43',symbol:'»'},shield:{name:'Schutzschild',color:'#76dfff',symbol:'◇'},heal:{name:'Heilung',color:'#83ffa2',symbol:'+'}};
function useItem(s,i){const p=s.fighters[i];if(!p||held(p)||s.phase!=='playing'||!items[p.item])return false;const kind=p.item;p.item=null;if(kind==='boost'){p.boostUntil=s.time+1.8;p.boostDir=p.dir||p.facing;p.vx=p.boostDir*Math.max(680,Math.abs(p.vx));}else if(kind==='shield')p.shieldUntil=s.time+5;else p.hp=Math.min(100,p.hp+28);s.lastItem={id:++s.itemId,kind,player:i,used:true,at:s.time};return true;}
function input(s,i,dir,seq,useSequence=0){const p=s.fighters[i];if(!p||![-1,0,1].includes(dir)||!Number.isSafeInteger(seq)||seq<0||seq<=p.seq)return false;p.seq=seq;if(!held(p)){p.dir=dir;p.inputAt=s.time;}if(Number.isSafeInteger(useSequence)&&useSequence>p.useSeq){p.useSeq=useSequence;useItem(s,i);}return true;}
function supplies(s){
 if(s.time>=s.nextDrop){s.nextDrop=s.time+10+random(s)*5;if(s.drops.length<2){const m=map(s),middle=(s.fighters[0].x+s.fighters[1].x)/2,x=clamp(middle+(random(s)-.5)*650,240,m.width-240),kind=['boost','shield','heal'][Math.floor(random(s)*3)];s.drops.push({id:++s.dropId,kind,x,y:Math.min(...s.fighters.map(p=>p.y))-510,vy:75,landed:false,expires:s.time+28});}}
 for(const drop of s.drops){const floor=ground(s,drop.x).y-28;if(!drop.landed){drop.vy=Math.min(230,drop.vy+240*DT);drop.y+=drop.vy*DT;if(drop.y>=floor){drop.y=floor;drop.landed=true;}}for(let n=0;n<2;n++){const i=(n+drop.id)%2,p=s.fighters[i];if(!drop.taken&&!p.item&&!held(p)&&Math.abs(p.x-drop.x)<65&&Math.abs(p.y-42-drop.y)<125){p.item=drop.kind;drop.taken=true;s.lastItem={id:++s.itemId,kind:drop.kind,player:i,used:false,at:s.time};}}}
 s.drops=s.drops.filter(d=>!d.taken&&s.time<d.expires);
}
function result(s,winner,reason){s.roundWinner=winner;s.reason=reason;if(winner>=0)s.stars[winner]++;if(s.stars.some(n=>n>=5)){s.phase='finished';s.winner=winner;}else{s.phase='between';s.until=s.time+2.4;}}
function settle(s,p){const target=support(s,p);if(p.y>=target){p.y=target;p.vy=Math.min(p.vy,0);if(p.vy> -30)p.vy=0;p.grounded=true;}else p.grounded=false;}
function step(s){if(s.phase==='finished')return;s.time+=DT;if(s.phase==='between'){if(s.time>=s.until)resetRound(s);return;}if(s.phase==='countdown'){if(s.time<s.until)return;s.phase='playing';}
 supplies(s);
 const old=s.fighters.map(p=>({...geometry(p,s),facing:p.facing})),m=map(s);
 for(let i=0;i<2;i++){const p=s.fighters[i],q=s.fighters[1-i],recoiling=s.time<p.recoilUntil,d=!held(p)&&!recoiling&&s.time-p.inputAt<.75?p.dir:0,oldX=p.x,oldVx=p.vx,wasGrounded=p.grounded,fallSpeed=p.vy;
  const boosted=s.time<p.boostUntil&&!held(p),reversing=d&&d*p.vx<0;p.angle=0;p.vx+=d*(p.grounded?(reversing?2750:1650):520)*DT;if(boosted)p.vx+=p.boostDir*2300*DT;p.vx*=Math.exp(-(recoiling?.38:p.grounded?(d||boosted?1.65:3.2):.2)*DT);const speedLimit=recoiling?1100:boosted?940:580;p.vx=clamp(p.vx,-speedLimit,speedLimit);p.vy+=1550*DT;
  p.x=clamp(p.x+p.vx*DT,145,m.width-145);if(p.x===145&&p.vx<0||p.x===m.width-145&&p.vx>0)p.vx=0;
  const slope=(ground(s,p.x+39).y-ground(s,p.x-39).y)/78,targetAngle=p.grounded?Math.atan(slope):0;p.boardAngle+=(targetAngle-p.boardAngle)*Math.min(1,DT*16);p.y+=p.vy*DT;settle(s,p);
  if(p.grounded)p.vx+=ground(s,p.x).slope*460*DT;
  p.wheelAngle+=(p.x-oldX)*Math.sqrt(1+slope*slope)/WHEEL_RADIUS;
  if(held(p)){p.dir=0;p.wv=0;continue;}
  // Spring motion belongs to the rider only. It never feeds board forces back.
  if(!wasGrounded&&p.grounded)p.bodyVY+=clamp(fallSpeed*.75,0,420);
  const acceleration=(p.vx-oldVx)/DT,roadBob=Math.sin(p.wheelAngle*.30)*Math.min(1,Math.abs(p.vx)/180)*29;
  const sideBob=Math.sin(p.wheelAngle*.24)*Math.min(1,Math.abs(p.vx)/180)*34;
  p.bodyVX+=(50*(sideBob-p.bodyX)-2.8*p.bodyVX-acceleration*1.35)*DT;
  p.bodyVY+=(70*(roadBob-p.bodyY)-3.1*p.bodyVY)*DT;
  p.bodyX=clamp(p.bodyX+p.bodyVX*DT,-75,75);p.bodyY=clamp(p.bodyY+p.bodyVY*DT,-65,45);
  if(Math.abs(p.bodyX)>=75&&p.bodyX*p.bodyVX>0)p.bodyVX*=-.5;
  if((p.bodyY<=-65&&p.bodyVY<0)||(p.bodyY>=45&&p.bodyVY>0))p.bodyVY*=-.4;
  p.facing=q.x>=p.x?1:-1;p.weaponAngle=p.facing>0?-.26:Math.PI+.26;p.wv=0;

 }
 // Weapon heads use the same circular hit areas as body strikes.
 // Sweep their relative motion to catch fast boosts between simulation steps.
 const left=s.fighters[0],right=s.fighters[1],lg=geometry(left,s),rg=geometry(right,s),radius=weapons[s.weapon].radius*2;
 const relativeFrom={x:old[0].tip.x-old[1].tip.x,y:old[0].tip.y-old[1].tip.y},relativeTo={x:lg.tip.x-rg.tip.x,y:lg.tip.y-rg.tip.y};
 const distance=Math.hypot(relativeTo.x,relativeTo.y),stable=old[0].facing===left.facing&&old[1].facing===right.facing;
 let clashed=false;
 if(!held(left)&&!held(right)&&stable&&!s.clashContact&&s.time>=s.clashUntil&&relativeFrom.x*(relativeTo.x-relativeFrom.x)+relativeFrom.y*(relativeTo.y-relativeFrom.y)<-.001&&segmentDistance({x:0,y:0},relativeFrom,relativeTo)<=radius){
  const closing=Math.hypot(relativeTo.x-relativeFrom.x,relativeTo.y-relativeFrom.y)/DT,kick=clamp(760+closing*.20,760,1050),side=left.x<=right.x?-1:1;
  left.vx=side*kick;right.vx=-side*kick;left.bodyVX+=side*420;right.bodyVX-=side*420;left.bodyVY-=130;right.bodyVY-=130;left.recoilUntil=right.recoilUntil=s.time+.42;
  left.boostUntil=right.boostUntil=s.time;s.clashUntil=s.time+.20;clashed=true;
  const dx=relativeTo.x-relativeFrom.x,dy=relativeTo.y-relativeFrom.y,t=clamp(-(relativeFrom.x*dx+relativeFrom.y*dy)/(dx*dx+dy*dy||1),0,1);
  const ax=old[0].tip.x+(lg.tip.x-old[0].tip.x)*t,ay=old[0].tip.y+(lg.tip.y-old[0].tip.y)*t,bx=old[1].tip.x+(rg.tip.x-old[1].tip.x)*t,by=old[1].tip.y+(rg.tip.y-old[1].tip.y)*t;
  s.lastClash={id:++s.clashId,x:(ax+bx)/2,y:(ay+by)/2,at:s.time,power:clamp(closing/700,.5,1.4)};
 }
 s.clashContact=!held(left)&&!held(right)&&distance<=radius+6;
 // Fighters and boards may overlap: only terrain and weapon hits collide.
 const [a,b]=s.fighters;

 for(let i=0;i<2;i++){const p=s.fighters[i],q=s.fighters[1-i],g=geometry(p,s),h=geometry(q,s),w=weapons[s.weapon],hits=[{part:'head',v:h.head,r:22,m:1.3},{part:'shoulder',v:h.shoulder,r:28,m:1},{part:'hip',v:h.hip,r:25,m:.8}];
  if(clashed||s.time<s.clashUntil||held(p)||held(q)||old[i].facing!==p.facing||s.time<q.hurtUntil)continue;
  for(const hit of hits){const previous=old[1-i][hit.part],tx=hit.v.x-previous.x,ty=hit.v.y-previous.y,from={x:old[i].tip.x+tx,y:old[i].tip.y+ty},relativeSpeed=Math.hypot(g.tip.x-from.x,g.tip.y-from.y)/DT;
   if(relativeSpeed>65&&segmentDistance(hit.v,from,g.tip)<hit.r+w.radius){const shielded=s.time<q.shieldUntil,damage=clamp((7+relativeSpeed*.014)*w.power*hit.m,7,27)*.5*(shielded?.35:1);const dealt=Math.min(q.hp,damage);q.hp=Math.max(0,q.hp-damage);s.stats[i].hits++;s.stats[i].damage+=dealt;if(hit.part==='head')s.stats[i].headshots++;p.combo=s.time-p.lastAttackAt<1.6?p.combo+1:1;p.lastAttackAt=s.time;s.stats[i].bestCombo=Math.max(s.stats[i].bestCombo,p.combo);q.hurtUntil=s.time+(s.weapon===2?.64:s.weapon===1?.43:.51);q.flashUntil=s.time+.16;const sign=Math.sign(q.x-p.x)||1;q.vx=clamp(q.vx+sign*clamp(relativeSpeed*.24,85,245),-700,700);const grab=!shielded&&hit.part==='head'&&frontalHeadshot(p,q,from,g.tip,h.head);if(grab){s.stats[i].grabs++;q.grabbedBy=i;q.dir=0;q.wv=0;q.riderX=g.tip.x;q.riderY=g.tip.y+126;}else{q.bodyVX+=sign*340;q.bodyVY-=220;}s.hitId++;s.lastHit={id:s.hitId,x:g.tip.x,y:g.tip.y,damage:Math.round(damage),at:s.time,player:i,grab,headshot:hit.part==='head',shielded,combo:p.combo};break;}
  }
 }
 // A captured rider is detached from the board and anchored by the head.
 // Only the fixed server/simulation clock drains HP; clients cannot supply damage.
 for(let i=0;i<2;i++){const victim=s.fighters[i];if(!held(victim))continue;const captor=s.fighters[victim.grabbedBy];if(!captor||held(captor)){victim.grabbedBy=null;victim.riderX=null;victim.riderY=null;continue;}const tip=geometry(captor,s).tip;victim.riderX=tip.x;victim.riderY=tip.y+126;victim.dir=0;const drained=Math.min(victim.hp,10*DT);victim.hp=Math.max(0,victim.hp-drained);s.stats[victim.grabbedBy].drain+=drained;}
 if(a.hp<=0||b.hp<=0)result(s,a.hp===b.hp?-1:(a.hp>b.hp?0:1),'K. O.');else if(s.time-s.roundStarted>=90)result(s,Math.abs(a.hp-b.hp)<.01?-1:(a.hp>b.hp?0:1),'Zeit abgelaufen');
}
function frontalHeadshot(attacker,victim,from,tip,head){
 const dx=tip.x-from.x,dy=tip.y-from.y,forward=attacker.facing;
 return victim.facing===-forward&&dx*forward>0&&Math.abs(dy)<=Math.abs(dx)*.58&&Math.abs(Math.sin(attacker.weaponAngle))<=.42&&Math.cos(attacker.weaponAngle)*forward>.85&&Math.abs(tip.y-head.y)<=18&&(head.x-from.x)*forward>=0;
}
function segmentDistance(p,a,b){const dx=b.x-a.x,dy=b.y-a.y,t=clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/(dx*dx+dy*dy||1),0,1);return Math.hypot(p.x-a.x-t*dx,p.y-a.y-t*dy);}
function advance(s,seconds){const steps=Math.min(120,Math.floor(clamp(seconds,0,1)/DT+1e-7));for(let n=0;n<steps;n++)step(s);return steps*DT;}
function bot(s,i){
 const p=s.fighters[i],q=s.fighters[1-i];if(held(p)||s.phase!=='playing')return 0;
 const difficulty=s.options.difficulty,hard=difficulty==='hard',easy=difficulty==='easy';
 if(p.item==='heal'&&p.hp<75||p.item==='shield'&&Math.abs(q.x-p.x)<420||p.item==='boost'&&Math.abs(q.x-p.x)>380)useItem(s,i);
 if(s.time<p.aiNext)return p.aiDir;p.aiNext=s.time+(easy?.38:hard?.10:.22);
 const distance=q.x+q.vx*(hard?.26:.12)-p.x,side=Math.sign(distance)||p.facing,reach=weapons[s.weapon].length+45,closing=(p.vx-q.vx)*side;
 let dir=side;
 if(!p.item){const drop=s.drops.filter(d=>!d.taken&&Math.abs(d.x-p.x)<650&&Math.abs(d.x-q.x)>110).sort((a,b)=>Math.abs(a.x-p.x)-Math.abs(b.x-p.x))[0];if(drop&&Math.abs(distance)>250)dir=Math.abs(drop.x-p.x)<35?0:Math.sign(drop.x-p.x);}
 if(Math.abs(distance)<reach){dir=closing>80?-side:side;if(s.time<q.hurtUntil&&hard)dir=-side;}
 else if(Math.abs(distance)<reach+150&&closing>260)dir=hard?-side:0;
 if(easy&&Math.floor(s.time*1.4+i)%5===0)dir=0;
 if(p.x<220)dir=1;if(p.x>map(s).width-220)dir=-1;p.aiDir=dir;return dir;
}
return {W,H,DT,RULES_VERSION,WHEEL_RADIUS,held,frontalHeadshot,items,useItem,weapons,maps,terrains,map,ground,point,boardPoint,wheels,support,geometry,create,input,advance,bot};
});
