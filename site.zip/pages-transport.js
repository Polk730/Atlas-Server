/* GitHub Pages transport. No model/API credentials are stored in the frontend. */
(()=>{'use strict';if(window.AtlasPagesTransport)return;
const server='https://atlasbyoliver.com',key='atlas.pages.session.v1',rawFetch=window.fetch.bind(window);let token='',userId='guest';
try{const saved=JSON.parse(sessionStorage.getItem(key)||'{}');token=String(saved.token||'');userId=saved.userId||'guest';}catch{}
function remember(){sessionStorage.setItem(key,JSON.stringify({token,userId}));}
async function connect(){const response=await rawFetch(server+'/api/pages/session',{method:'POST',mode:'cors',credentials:'omit',headers:{'Content-Type':'application/json','X-Atlas-Client':'atlas-web',...(token?{Authorization:'Bearer '+token}:{})},body:'{}',signal:AbortSignal.timeout(15000)});const data=await response.json();if(!response.ok)throw new Error(data.error||'Atlas-Server nicht erreichbar.');token=data.token;userId=data.userId||'guest';remember();return data;}
const ready=connect();window.AtlasPagesTransport={server,ready,get userId(){return userId;}};
window.fetch=async(input,options={})=>{const url=new URL(typeof input==='string'?input:input.url||String(input),document.baseURI);if(![location.origin,server].includes(url.origin)||!url.pathname.startsWith('/api/'))return rawFetch(input,options);
await ready;const headers=new Headers(options.headers||{});headers.set('Authorization','Bearer '+token);headers.set('X-Atlas-Client','atlas-web');
const response=await rawFetch(server+url.pathname+url.search,{...options,headers,mode:'cors',credentials:'omit'});
if(response.status===401){sessionStorage.removeItem(key);throw new Error('Die Serversitzung ist abgelaufen. Lade die Seite neu und melde dich erneut an.');}
if(response.ok&&['/api/account/sign-in','/api/account/sign-up','/api/account/sign-out'].includes(url.pathname)){const data=await response.clone().json();if(!data.confirmationRequired){userId=data.signedIn?data.userId||'guest':'guest';remember();}}
return response;};
const meta=document.createElement('meta');meta.name='atlas-account-id';meta.content=userId;document.head.append(meta);
})();
