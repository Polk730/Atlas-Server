/* Only the public offline shell is cached. Account pages, API data and images are never cached here. */
const CACHE='atlas-ios-public-shell-v1';
const FILES=['/ios-offline.html','/ios-install.css','/ios-install.js','/icons/atlas-192.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('atlas-ios-public-shell-')&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(url.origin!==self.location.origin||event.request.method!=='GET')return;if(FILES.includes(url.pathname)){event.respondWith(fetch(event.request).catch(()=>caches.match(url.pathname)));return;}if(event.request.mode==='navigate'&&['/ios/app','/atlas','/ios','/login'].includes(url.pathname)){event.respondWith(fetch(event.request).then(async response=>response.status>=500?(await caches.match('/ios-offline.html'))||response:response).catch(()=>caches.match('/ios-offline.html')));}});
