(() => {
'use strict';
const apple=/iPad|iPhone|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1),standalone=window.matchMedia('(display-mode: standalone)').matches||navigator.standalone===true;
const server=document.querySelector('#ios-server');if(server)server.textContent=location.origin;
if(standalone&&['/ios','/download/ios'].includes(location.pathname)){location.replace('/ios/app');return;}
const note=document.querySelector('#ios-device-note');if(note&&apple)note.textContent='Du bist auf einem Apple-Gerät. Folge den Schritten in Safari, um Atlas hinzuzufügen.';
document.querySelector('#ios-copy')?.addEventListener('click',async()=>{const status=document.querySelector('#ios-status');try{await navigator.clipboard.writeText(location.origin+'/ios');status.textContent='Installationslink kopiert.';}catch{status.textContent=location.origin+'/ios';}});
document.querySelector('#ios-retry')?.addEventListener('click',()=>location.replace('/ios/app'));
if('serviceWorker' in navigator&&location.protocol==='https:')navigator.serviceWorker.register('/atlas-pwa-sw.js',{scope:'/'}).catch(()=>{});
})();
