/* Atlas Games: browser-local solo games and private server rooms. */
(() => {
  'use strict';
  if(document.querySelector('#games-view'))return;
  const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
  const btn=(text,fn,cls='secondary-button')=>{const n=el('button',cls,text);n.type='button';n.onclick=fn;return n;};
  const svg='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M7 7h10c3 0 5 9 3 11-1 1-3-1-5-3H9c-2 2-4 4-5 3-2-2 0-11 3-11Z"/><path d="M8 9v5M5.5 11.5h5M16 10h.01M18 13h.01"/></svg>';
  const view=el('section','atlas-games hidden');view.id='games-view';document.querySelector('main.main').append(view);
  const nav=btn('',()=>showView('games'),'nav-item');nav.innerHTML=svg+' Games';document.querySelector('.nav-item[data-view="learn"]')?.after(nav);
  let current='',stopGame=()=>{},onKey=null,visible=false,room=null,credential=null,networkBusy=false,poll=null,revision=0,signature='',inkQueue=[],drawing=null,roomRoot=null,scope='',netError='',frame=0,pendingAction=null;
  let stickDir=0,stickUse=0,stickSeq=0,stickDispose=()=>{},lastStickRequest=0;
  let gameFilter='single';try{if(localStorage.getItem('atlas.games.filter')==='multi')gameFilter='multi';}catch{}
  const newGames=window.AtlasNewGames;
  const soloIds=[...Object.keys(newGames.solo),'stick','clicker','snake','2048','reaction','mines','breakout','sudoku'];
  const gameTitles={stick:'Stick Battle',connect:'Vier gewinnt',draw:'Zeichnen & Raten',dino:'Dino Run',ttt:'Tic-Tac-Toe',ships:'Schiffe versenken',reflex:'Reaktionsduell'};
  Object.assign(gameTitles,Object.fromEntries(Object.entries(newGames.multi).map(([id,info])=>[id,info[0]])));
  const oldView=showView;showView=function(name){if(name!=='games'){if(document.fullscreenElement===view)document.exitFullscreen().catch(()=>{});view.classList.remove('games-fullscreen-fallback');visible=false;stickDispose();stickDispose=()=>{};stopGame();stopGame=()=>{};onKey=null;clearTimeout(poll);cancelAnimationFrame(frame);}oldView(name==='games'?'chat':name);if(name==='games')document.querySelector('#chat-view')?.classList.add('hidden');view.classList.toggle('hidden',name!=='games');nav.classList.toggle('active',name==='games');if(name==='games'){visible=true;hub();}};
  const oldVoice=openVoiceMode;openVoiceMode=function(...args){visible=false;view.classList.add('hidden');stickDispose();stickDispose=()=>{};stopGame();clearTimeout(poll);cancelAnimationFrame(frame);return oldVoice(...args);};
  const account=()=>document.querySelector('meta[name="atlas-account-id"]')?.content||document.querySelector('#account-current-email')?.textContent||'guest';
  function sound(kind){try{playUiSound(kind==='win'?'vocci-finish':kind==='point'?'vocci-correct':'vocci-step');}catch{}}
  function header(title,copy){
    view.replaceChildren();const h=el('header','games-heading'),text=el('div');text.append(el('p','eyebrow','ATLAS / GAMES'),el('h1','',title),el('p','games-muted',copy));
    const actions=el('div','games-heading-actions'),filter=el('select','games-mode-filter');filter.setAttribute('aria-label','Singleplayer oder Multiplayer auswählen');filter.add(new Option('Singleplayer','single'));filter.add(new Option('Multiplayer','multi'));filter.value=gameFilter;
    filter.onchange=()=>{gameFilter=filter.value;try{localStorage.setItem('atlas.games.filter',gameFilter);}catch{}hub();};actions.append(filter);if(current)actions.append(btn('Spieleübersicht',hub));h.append(text,actions);view.append(h);
  }
  const gameRules={
    stick:['Gewinne fünf Sterne mit deinem rollenden Stick-Fighter.',[
      'Spieler 1: A und D. Spieler 2 am gleichen Gerät: Pfeil links und rechts. Online steuert jeder seinen Fighter mit A/D oder den Pfeiltasten.',
      'Prallen die Trefferflächen zweier Waffen zusammen, werden beide Kämpfer zurückgestoßen. Der Clash verursacht keinen HP-Schaden und unterbricht einen Raketenboost.',
      'Versorgungsdrops fallen regelmäßig vom Himmel: Raketenboost (1,8 Sekunden), Schild (5 Sekunden, reduziert Schaden und verhindert neue Griffe), Heilung (+28 HP). Ein Item tragen, mit E einsetzen; Spieler 2 lokal mit Enter. Alternativ den Item-Knopf drücken. Gegenlenken bremst schneller.',
      'Spieler und Boards können durcheinander hindurchrollen, ohne sich zu blockieren. Waffentreffer zählen weiterhin. Nur links und rechts halten. Der Fahrer bleibt aufrecht; das Board folgt dem Boden und die Räder rollen. Die Waffe bleibt fest ausgerichtet und schwingt nicht automatisch. Nur der Stickman federt beim Rollen, Bremsen und bei Treffern; das Board bleibt stabil. Kein Angriffsknopf.',
      'Treffe Kopf oder Körper des Gegners mit deiner Waffe und leere seine Lebensleiste. Normaler Trefferschaden ist halbiert. Ein frontaler, fast waagrechter Kopftreffer hält den Gegner an der Waffe fest: ohne Board, Steuerung und Angriffe, mit 10 HP Verlust pro Sekunde bis zum Rundenende. Treffer von oben oder unten lösen das nicht aus. Ein Rundensieg gibt einen Stern; fünf Sterne gewinnen das Match.',
      'Sechs große Arenen mit Rampen, Wellen und Tälern wechseln zwischen den Runden. Kamera und Minikarte helfen bei der Orientierung. Auch die gemeinsame Waffenart wechselt. Nach 90 Sekunden entscheidet die verbleibende Gesundheit; Gleichstand gibt keinen Stern.',
      'Solo gegen CPU, lokal zu zweit oder Online-Party für zwei Geräte. Online teilen Freunde einen Raumcode oder eine Einladung und der Gastgeber startet.',
      'Touch: Richtungspfeile halten. Online braucht eine laufende Serververbindung; bei mehr als 20 Sekunden ohne Verbindung endet das Duell.'
    ]],
    snake:['Sammle Futter und mache die Schlange möglichst lang.',[
      'Pfeiltasten, WASD oder die Richtungstasten unter dem Feld steuern die Schlange. Eine direkte Kehrtwende ist nicht möglich.',
      'Jedes Futter bringt einen Punkt und verlängert die Schlange um ein Feld.',
      'Berührst du den Rand oder den eigenen Körper, endet die Runde. Ist das ganze Feld gefüllt, hast du es geschafft.',
      'Leertaste oder „Pause / Weiter“ pausiert das Spiel. „Neue Runde“ beginnt von vorn. Der Rekord bleibt auf diesem Gerät gespeichert.'
    ]],
    '2048':['Verbinde gleiche Zahlen und erreiche die Kachel 2048.',[
      'Pfeiltasten, Bildschirmtasten oder Wischen bewegen alle Kacheln in eine Richtung.',
      'Zwei gleiche Zahlen verschmelzen zu ihrer Summe. Eine Kachel kann pro Zug nur einmal verschmelzen.',
      'Nach jedem Zug, der etwas verändert, erscheint eine neue 2 oder 4. Zusammengeführte Zahlen werden als Punkte gutgeschrieben.',
      'Ohne freien Platz oder mögliche Verschmelzung endet das Spiel. Nach 2048 darfst du weiterspielen.',
      '„Ein Zug zurück“ nimmt den letzten Zug zurück. „Neustart“ setzt das Feld zurück. Dein Rekord bleibt auf diesem Gerät.'
    ]],
    reaction:['Reagiere erst, wenn die Fläche grün wird.',[
      'Klicke oder tippe auf „Runde starten“. Nach einer zufälligen Wartezeit wird die Fläche grün.',
      'Bei Grün sofort klicken, tippen oder Leertaste drücken. Deine Reaktionszeit wird in Millisekunden angezeigt; kleiner ist besser.',
      'Ein Klick vor Grün ist ein Fehlstart und zählt nicht als gemessene Runde.',
      'Du kannst mehrere Runden spielen. Durchschnitt und Bestzeit gelten für die aktuelle Spielsession.'
    ]],
    connect:['Bringe vier eigene Steine in eine Reihe.',[
      'Zwei Spieler treten über denselben Server und einen Raumcode gegeneinander an. Der Gastgeber startet.',
      'Klicke auf eine Spalte. Dein Stein fällt auf den untersten freien Platz. Danach ist der andere Spieler dran.',
      'Vier Steine waagrecht, senkrecht oder diagonal gewinnen die Runde. Ein volles Feld ohne Viererreihe ist unentschieden.',
      'Pro Zug hast du 45 Sekunden. Wer bis dahin keinen Zug macht, verliert automatisch; der Gegner gewinnt die Runde.',
      'Der Gewinner erhält einen Punkt. Der Gastgeber kann nach der Runde eine Revanche starten; dabei werden die Rundenpunkte zurückgesetzt.'
    ]],
    draw:['Erratet, was gerade gezeichnet wird.',[
      '2–8 Spieler treten mit Raumcode an. Jeder Spieler zeichnet einmal; alle anderen raten.',
      'Der Gastgeber wählt klassische Begriffe, Fantasiebegriffe oder einen Mix aus 4.000 Motiven. Nur der Zeichner sieht das geheime Wort. Zeichne mit Maus oder Finger; Farbe, Stiftstärke, Radierer und „Fläche leeren“ helfen dabei.',
      'Pro Zeichnung bleiben 60 Sekunden. Tippe dein geratenes Wort ins Antwortfeld und drücke „Raten“ oder Enter.',
      'Richtig geraten bringt 100 Punkte plus bis zu 20 Punkte Zeitbonus. Der Zeichner bekommt je richtiger Antwort 30 Punkte.',
      'Haben alle geraten oder ist die Zeit vorbei, wird das Wort aufgelöst. Nach einer kurzen Pause zeichnet der nächste Spieler.',
      'Wer am Ende die meisten Punkte hat, gewinnt. Fair spielen: das Wort nicht als Text aufs Bild schreiben.'
    ]],
    dino:['Weiche den Hindernissen aus und überlebe länger als deine Freunde.',[
      '2–8 Spieler laufen gleichzeitig auf derselben Hindernisstrecke. Der Gastgeber startet; danach gibt es drei Sekunden Vorlauf.',
      'Springe mit Leertaste, Pfeil nach oben, dem Sprungknopf oder einem Tipp auf die Rennstrecke. Ein weiterer Sprung geht erst wieder am Boden.',
      'Wenn du ein Hindernis berührst, scheidest du aus. Du kannst den anderen bis zum Ende zuschauen.',
      'Solange du überlebst, bekommst du 10 Punkte pro Sekunde. Die Strecke wird mit der Zeit schneller.',
      'Das Rennen endet nach 60 Sekunden oder sobald alle ausgeschieden sind. Die höchste Punktzahl gewinnt; Gleichstand ist möglich.',
      'Der Gastgeber kann danach eine Revanche starten.'
    ]]
  };
  Object.assign(gameRules,{
    mines:['Öffne alle sicheren Felder, ohne eine Mine zu treffen.',[
      'Das Feld hat 9 × 9 Kästchen und 10 Minen. Der erste geöffnete Bereich ist sicher.',
      'Eine Zahl zeigt, wie viele der acht Nachbarfelder Minen enthalten. Leere Bereiche öffnen sich automatisch.',
      'Rechtsklick setzt eine Flagge. Auf dem Handy schaltest du den Flaggenmodus ein und tippst auf das Feld.',
      'Flaggen verhindern versehentliches Öffnen, sind aber kein Beweis für eine Mine. Öffne alle 71 sicheren Felder, um zu gewinnen.'
    ]],
    breakout:['Halte den Ball mit deinem Paddle im Spiel und zerstöre alle Steine.',[
      'Start/Pause oder Leertaste startet und pausiert. Maus, Finger oder Pfeiltasten bewegen das Paddle; auf dem Handy gibt es Richtungstasten.',
      'Jeder zerstörte Stein bringt 10 Punkte. Berührt der Ball den Rand des Paddles, fliegt er schräger ab.',
      'Fällt der Ball unten heraus, verlierst du ein Leben. Du beginnst mit drei Leben.',
      'Sind alle 45 Steine weg, gewinnst du. Nach einem verlorenen Ball drückst du erneut Start.'
    ]],
    sudoku:['Fülle das Raster so, dass jede Zahl 1–9 einmal in jeder Zeile, Spalte und jedem 3×3-Block vorkommt.',[
      'Wähle ein Feld und danach eine Zahl auf der Bildschirmtastatur oder deiner Tastatur. Vorgegebene Zahlen sind nicht veränderbar.',
      'Notizen helfen beim Merken möglicher Zahlen. Mit Löschen, Backspace oder 0 entfernst du deinen Eintrag.',
      'Prüfen markiert falsche Einträge. Hinweis füllt ein ungelöstes Feld und zählt als verwendete Hilfe.',
      'Jedes erzeugte Rätsel hat genau eine Lösung. Neues Sudoku erzeugt ein neues Rätsel; die laufende Runde wird ersetzt.'
    ]],
    ttt:['Bringe drei eigene Zeichen in eine Reihe.',[
      'Zwei Spieler spielen abwechselnd X und O auf einem 3×3-Feld. Der Gastgeber beginnt.',
      'Tippe auf ein freies Feld. Drei Zeichen waagrecht, senkrecht oder diagonal gewinnen. Ein volles Feld ohne Gewinner ist unentschieden.',
      'Pro Zug hast du 45 Sekunden. Wer bis dahin keinen Zug macht, verliert automatisch. Der Gegner bekommt den Rundenpunkt.',
      'Nach der Runde kann der Gastgeber eine Revanche starten.'
    ]],
    ships:['Versenke alle drei Schiffe deines Gegners.',[
      'Zwei Spieler platzieren auf einem 8×8-Feld je ein Schiff mit Länge 4, 3 und 2. Tippe auf den Startpunkt; die Richtung bestimmt waagrecht oder senkrecht.',
      'Schiffe müssen gerade liegen und dürfen sich nicht überlappen. Berühren ist erlaubt. Alternativ kannst du deine Flotte zufällig setzen lassen.',
      'Nach Bereit bleibt deine Flotte geheim. Für die Aufstellung sind zwei Minuten vorgesehen.',
      'Beschiesse ein Feld im gegnerischen Raster. Ein Treffer gibt einen Punkt und du darfst noch einmal schiessen; bei Wasser wechselt der Zug.',
      'Jeder Zug hat 45 Sekunden. Wer zuerst alle neun gegnerischen Schiffsfelder getroffen hat, gewinnt.'
    ]],
    reflex:['Reagiere auf Grün und sammle über fünf Runden möglichst viele Punkte.',[
      '2–8 Spieler warten auf die grüne Fläche. Drücke dann die Fläche oder die Leertaste. Vorheriges Drücken ist ein Fehlstart und bringt null Punkte.',
      'Der schnellste gültige Teilnehmer bekommt 100 Punkte, der nächste 90 und so weiter. Gleich schnelle Antworten erhalten dieselbe Punktzahl.',
      'Nach vier Sekunden ohne Antwort gibt es für die Runde keine Punkte. Zwischen den Runden erscheint eine kurze Auswertung.',
      'Die Summe nach fünf Runden entscheidet. Netzwerklatenz beeinflusst die gemessenen Zeiten; die Runde ist ein Spassduell.'
    ]]
  });
  for(const [id,info]of Object.entries({...newGames.solo,...newGames.multi}))gameRules[id]=[info[2],info[3]];
  function showRules(id){
    const existing=view.querySelector('.games-rules');if(existing?.dataset.game===id)return;existing?.remove();const info=gameRules[id];if(!info)return;
    const details=el('details','games-rules');details.dataset.game=id;const summary=el('summary','','Regeln & Steuerung');details.append(summary,el('p','games-rules-goal',info[0]));const list=el('ul');info[1].forEach(text=>list.append(el('li','',text)));details.append(list);view.querySelector('.games-heading')?.after(details);
  }
  function begin(id,title,copy){stickDispose();stickDispose=()=>{};stopGame();stopGame=()=>{};onKey=null;clearTimeout(poll);cancelAnimationFrame(frame);current=id;window.AtlasArena?.begin(id);if(id)gameFilter=soloIds.includes(id)?'single':'multi';header(title,copy);showRules(id);window.AtlasArena?.decorate();window.AtlasLocalGames?.decorate(id);}
  function hub(){if(!visible)return;begin('','Einfach spielen.','Für eine kurze Pause oder eine Runde mit Freunden.');const catalog=[['stick','STICK BATTLE','1–2 Spieler','Stabile Boards, federnde Kämpfer und feste Waffen. CPU, ein Gerät oder Online-Party.'],['clicker','ATLAS CLICKER','Singleplayer','Endlose Energie. Upgrades. Prestige. Automatisch in der Cloud.'],['snake','SNAKE','Singleplayer','Wachsen, ausweichen, eigenen Rekord knacken.'],['2048','2048','Singleplayer','Gleiche Zahlen verbinden. Wie weit kommst du?'],['reaction','REAKTION','Singleplayer','Warte auf Grün und teste deine Reaktion.'],['mines','MINESWEEPER','Singleplayer','Finde sichere Felder und markiere versteckte Minen.'],['breakout','BREAKOUT','Singleplayer','Halte den Ball im Spiel und räume die Steine ab.'],['sudoku','SUDOKU','Singleplayer','Löse ein eindeutiges Zahlenrätsel mit Notizen und Hinweisen.'],['ttt','TIC-TAC-TOE','2 Spieler','Drei Zeichen in einer Reihe – klassisch gegen Freunde.'],['ships','SCHIFFE VERSENKEN','2 Spieler','Platziere deine Flotte und finde die gegnerischen Schiffe.'],['reflex','REAKTIONSDUELL','2–8 Spieler','Fünf schnelle Runden: bei Grün drücken, Fehlstarts vermeiden.'],['connect','VIER GEWINNT','2 Spieler','Vier in einer Reihe – mit Raumcode gegen Freunde.'],['draw','ZEICHNEN & RATEN','2–8 Spieler','Einer zeichnet. Die anderen erraten das Wort.'],['dino','DINO RUN','2–8 Spieler','Gleiche Strecke. Wer weicht am längsten aus?']];catalog.push(...Object.entries(newGames.solo).map(([id,a])=>[id,a[0],'Singleplayer',a[2]]),...Object.entries(newGames.multi).map(([id,a])=>[id,a[0],id==='uno'?'2–6 Spieler':'2 Spieler',a[2]]));if(credential)view.append(el('p','games-muted','Du hast einen gespeicherten Multiplayer-Raum. Über ein Multiplayer-Spiel kannst du ihn fortsetzen oder verlassen.'));const grid=el('div','games-catalog');for(const [id,title,type,copy]of catalog){if(id!=='stick'&&(soloIds.includes(id)?'single':'multi')!==gameFilter)continue;const card=btn('',()=>soloIds.includes(id)?solo(id):multiplayer(id),'games-card');card.append(el('small','',type),el('span','games-card-symbol',({stick:'⚔',clicker:'ϟ',snake:'↝','2048':'2048',reaction:'ϟ',connect:'● ●',draw:'✎',dino:'⌁',mines:'⚑',breakout:'▦',sudoku:'1·9',ttt:'X O',ships:'⚓',reflex:'ϟ ϟ'})[id]||newGames.solo[id]?.[1]||newGames.multi[id]?.[1]),el('h2','',title),el('p','',copy),el('b','','Spielen ↗'));grid.append(card);}view.append(grid);}
  function best(id,value){const k='atlas.games.best.'+id;try{const old=Number(localStorage.getItem(k))||0;if(value!==undefined&&value>old)localStorage.setItem(k,String(value));return Math.max(old,value||0);}catch{return value||0;}}
  function stickContext(){return {el,btn,view,begin,sound,online:()=>multiplayer('stick'),keys:fn=>onKey=fn,cleanup:fn=>stopGame=fn};}
  function solo(id){if(newGames.solo[id]){newGames.start(id,{el,btn,view,begin,sound,keys:fn=>onKey=fn,cleanup:fn=>stopGame=fn});}else if(id==='stick'){window.AtlasStick.start(stickContext());}else if(id==='clicker'){window.AtlasClicker.start({el,btn,view,begin,sound,keys:fn=>onKey=fn,cleanup:fn=>stopGame=fn});}else if(id==='snake')snake();else if(id==='2048')game2048();else if(id==='reaction')reaction();else if(window.AtlasExtraGames)window.AtlasExtraGames.start(id,{el,btn,view,begin,sound,best,keys:fn=>onKey=fn,cleanup:fn=>stopGame=fn});}
  function controls(labels,fn){const row=el('div','games-pad');for(const [label,value]of labels)row.append(btn(label,()=>fn(value)));view.append(row);}
  function snake(){
    begin('snake','Snake','Pfeiltasten oder WASD. Leertaste pausiert. Auf dem Handy nutze die Richtungstasten.');
    const bar=el('div','games-toolbar'),status=el('p','games-status'),canvas=el('canvas','games-canvas');canvas.width=600;canvas.height=600;const ctx=canvas.getContext('2d');bar.append(status,btn('Neue Runde',snake));view.append(bar,canvas);
    let body=[{x:10,y:10},{x:9,y:10},{x:8,y:10}],dir={x:1,y:0},next=dir,food={x:15,y:10},score=0,paused=false,dead=false,turned=false;
    const steer=key=>{if(dead)return;const d={up:{x:0,y:-1},down:{x:0,y:1},left:{x:-1,y:0},right:{x:1,y:0}}[key];if(d&&!turned&&(d.x!==-dir.x||d.y!==-dir.y)){next=d;turned=true;}};
    controls([['←','left'],['↑','up'],['↓','down'],['→','right']],steer);const pause=btn('Pause / Weiter',()=>{paused=!paused;draw();});view.append(pause);
    function draw(){ctx.fillStyle='#111827';ctx.fillRect(0,0,600,600);ctx.strokeStyle='#ffffff05';for(let i=0;i<20;i++){ctx.beginPath();ctx.moveTo(i*30,0);ctx.lineTo(i*30,600);ctx.moveTo(0,i*30);ctx.lineTo(600,i*30);ctx.stroke();}ctx.fillStyle='#ed8699';ctx.fillRect(food.x*30+5,food.y*30+5,20,20);body.forEach((p,i)=>{ctx.fillStyle=i?'#8a78db':'#b7f2db';ctx.fillRect(p.x*30+2,p.y*30+2,26,26);});status.textContent='Punkte '+score+' · Rekord '+best('snake')+(dead?' · Runde beendet':paused?' · Pause':'');}
    const timer=setInterval(()=>{if(!visible||paused||dead)return;dir=next;turned=false;const head={x:body[0].x+dir.x,y:body[0].y+dir.y},eating=head.x===food.x&&head.y===food.y;
      if(head.x<0||head.y<0||head.x>=20||head.y>=20||body.slice(0,eating?body.length:-1).some(p=>p.x===head.x&&p.y===head.y)){dead=true;best('snake',score);window.AtlasArena?.result('snake',score);draw();return;}
      body.unshift(head);if(!eating)body.pop();else{score++;best('snake',score);sound('point');const empty=[];for(let x=0;x<20;x++)for(let y=0;y<20;y++)if(!body.some(p=>p.x===x&&p.y===y))empty.push({x,y});if(!empty.length){dead=true;sound('win');window.AtlasArena?.result('snake',score);}else food=empty[Math.floor(Math.random()*empty.length)];}draw();},130);
    onKey=e=>{const k={ArrowUp:'up',w:'up',ArrowDown:'down',s:'down',ArrowLeft:'left',a:'left',ArrowRight:'right',d:'right'}[e.key];if(k){e.preventDefault();steer(k);}else if(e.code==='Space'){e.preventDefault();paused=!paused;draw();}};stopGame=()=>clearInterval(timer);draw();
  }
  function game2048(){
    begin('2048','2048','Pfeiltasten oder auf dem Spielfeld wischen. Jede Zahl darf pro Zug einmal zusammenrücken.');let board=Array(16).fill(0),score=0,previous=null,won=false;const bar=el('div','games-toolbar'),status=el('p','games-status'),grid=el('div','game-2048');grid.setAttribute('aria-label','2048 Spielfeld');bar.append(status,btn('Neustart',game2048),btn('Ein Zug zurück',()=>{if(previous){board=previous.board;score=previous.score;previous=null;draw();}}));view.append(bar,grid);
    function spawn(){const free=board.map((n,i)=>n?null:i).filter(i=>i!==null);if(free.length)board[free[Math.floor(Math.random()*free.length)]]=Math.random()<.9?2:4;}
    function possible(){return board.some(n=>!n)||board.some((n,i)=>i%4<3&&n===board[i+1]||i<12&&n===board[i+4]);}
    function draw(){grid.replaceChildren();for(const value of board){const tile=el('div','game-2048-tile',value||'');tile.style.setProperty('--power',String(value?Math.min(1,Math.log2(value)/12):0));tile.setAttribute('aria-label',value?String(value):'Leer');grid.append(tile);}best('2048',score);if(!possible()||won)window.AtlasArena?.result('2048',score);status.textContent='Punkte '+score+' · Rekord '+best('2048')+(!possible()?' · Keine Züge mehr':won?' · 2048 geschafft! Spiele weiter.':'');}
    function move(direction){const before=board.slice(),old=score;for(let line=0;line<4;line++){const ids=Array.from({length:4},(_,i)=>direction==='left'?line*4+i:direction==='right'?line*4+3-i:direction==='up'?i*4+line:(3-i)*4+line),values=ids.map(i=>board[i]).filter(Boolean),merged=[];for(let i=0;i<values.length;i++){if(values[i]===values[i+1]){merged.push(values[i]*2);score+=values[i]*2;i++;}else merged.push(values[i]);}ids.forEach((id,i)=>board[id]=merged[i]||0);}if(board.some((n,i)=>n!==before[i])){previous={board:before,score:old};spawn();if(!won&&board.includes(2048)){won=true;sound('win');}draw();}}
    controls([['←','left'],['↑','up'],['↓','down'],['→','right']],move);onKey=e=>{const d={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'up',ArrowDown:'down'}[e.key];if(d){e.preventDefault();if(!e.repeat)move(d);}};
    let start;grid.style.touchAction='none';grid.onpointerdown=e=>{start={x:e.clientX,y:e.clientY};grid.setPointerCapture(e.pointerId);};grid.onpointerup=e=>{if(!start)return;const dx=e.clientX-start.x,dy=e.clientY-start.y;start=null;if(Math.max(Math.abs(dx),Math.abs(dy))>30)move(Math.abs(dx)>Math.abs(dy)?dx>0?'right':'left':dy>0?'down':'up');};spawn();spawn();draw();
  }
  function reaction(){
    begin('reaction','Reaktionstest','Starte eine Runde. Sobald die Fläche grün wird: klicken, tippen oder Leertaste drücken.');let phase='idle',timer=null,start=0,results=[];
    const surface=btn('Runde starten',hit,'reaction-surface'),status=el('p','games-status');view.append(surface,status);
    function hit(){if(phase==='waiting'){clearTimeout(timer);phase='idle';surface.dataset.phase='early';surface.textContent='Zu früh! Noch einmal starten.';return;}if(phase==='go'){const ms=Math.round(performance.now()-start);results.push(ms);phase='idle';surface.dataset.phase='done';surface.textContent=ms+' ms · Nächste Runde';const mean=Math.round(results.reduce((a,b)=>a+b,0)/results.length);if(results.length>=5)window.AtlasArena?.result('reaction',Math.round(results.slice(-5).reduce((a,b)=>a+b,0)/5));status.textContent=results.length+' Runden · Durchschnitt '+mean+' ms · Bestzeit '+Math.min(...results)+' ms';return;}phase='waiting';surface.dataset.phase='wait';surface.textContent='Warten …';timer=setTimeout(()=>{phase='go';surface.dataset.phase='go';surface.textContent='JETZT!';start=performance.now();},1500+Math.random()*3500);}
    onKey=e=>{if(e.code==='Space'){e.preventDefault();if(!e.repeat)hit();}};stopGame=()=>clearTimeout(timer);
  }
  function multiplayer(id,resume=true){if(room&&scope===account())id=room.game;begin(id,gameTitles[id],'Mit Raumcode über deinen Atlas-Server spielen.');const nextScope=account();if(nextScope!==scope){revision++;networkBusy=false;pendingAction=null;scope=nextScope;credential=null;room=null;try{credential=JSON.parse(sessionStorage.getItem('atlas.games.room.'+scope)||'null');}catch{}}roomRoot=el('div','games-online');view.append(roomRoot);signature='';inkQueue=[];drawing=null;renderRoom();if(credential&&resume)api('state');}
  window.AtlasGamesSocial={async join(invite,name){
    if(networkBusy)throw new Error('Bitte kurz warten und erneut beitreten.');
    showView('games');multiplayer(invite.game,false);clearTimeout(poll);
    if(credential&&credential.code!==invite.code){if(!confirm('Aktuellen Spielraum verlassen und der Einladung folgen?'))return;await api('leave');}
    if(credential?.code===invite.code){await api('state');return;}
    await api('join',{code:invite.code,name:String(name).slice(0,24)});
  }};
  window.AtlasGamesAdmin={current(){return credential&&room&&scope===account()?{...credential,game:room.game,phase:room.phase,you:room.you,host:room.host,testMode:!!room.testMode}:null;},async command(action,payload={}){
    const saved=this.current();if(!saved)throw new Error('Öffne zuerst einen Multiplayer-Raum mit diesem Konto.');
    const result=await window.samuelDesktop.games(action,{code:saved.code,token:saved.token,...payload});if(scope!==account())throw new Error('Das Konto hat gewechselt.');room={...result,receivedAt:Date.now()};if(visible)renderRoom();return result;
  }};
  function store(){try{if(credential)sessionStorage.setItem('atlas.games.room.'+scope,JSON.stringify(credential));else sessionStorage.removeItem('atlas.games.room.'+scope);}catch{}}
  async function api(action,payload={}){
    if(networkBusy){if(['stick_input','jump','move','ttt','fire','react'].includes(action))pendingAction={action,payload};return;}clearTimeout(poll);networkBusy=true;if(action==='stick_input')lastStickRequest=performance.now();const rev=revision;const owner=scope;
    try{if(!window.samuelDesktop?.games)throw new Error('Bitte Atlas und deinen Server aktualisieren.');const result=await window.samuelDesktop.games(action,{...credential,...payload,stickRulesVersion:window.AtlasStickEngine?.RULES_VERSION});if(rev!==revision||owner!==account())return;
      if(result.token){credential={code:result.code,token:result.token};store();}if(result.left){credential=null;room=null;store();signature='';renderRoom();return;}
      room={...result,receivedAt:Date.now()};if(room.phase==='finished'&&room.game!=='stick'&&!room.testMode){const me=room.players.find(p=>p.id===room.you);if(me)window.AtlasArena?.result(room.game,['connect','ttt','ships'].includes(room.game)?(room.winner===room.you?1:0):me.score,room.code+':'+room.version+':'+(room.started||''));}if(visible&&roomRoot?.isConnected){current=room.game;gameFilter='multi';const filter=view.querySelector('.games-mode-filter');if(filter)filter.value='multi';showRules(room.game);const title=view.querySelector('.games-heading h1');if(title)title.textContent=gameTitles[room.game];}netError='';renderRoom();
    }catch(error){if(rev!==revision)return;netError=String(error.message||error).replace(/^Error invoking remote method .*?: Error: /,'');if(/Raum nicht gefunden|Platz ist nicht mehr gültig/.test(netError)){credential=null;room=null;store();signature='';renderRoom();}const notice=roomRoot?.querySelector('.games-network');if(notice)notice.textContent=netError;}
    finally{if(rev===revision){networkBusy=false;if(pendingAction){const next=pendingAction;pendingAction=null;api(next.action,next.payload);}else schedule();}}
  }
  function schedule(){clearTimeout(poll);if(visible&&roomRoot?.isConnected&&credential)poll=setTimeout(()=>{if(inkQueue.length){const stroke=inkQueue.shift();api('ink',stroke);}else if(room?.game==='stick'&&room.phase==='stick')api('stick_input',{direction:stickDir,sequence:++stickSeq,useSequence:stickUse});else api('state');},room?.game==='stick'&&room.phase==='stick'?(netError?1000:Math.max(20,70-(performance.now()-lastStickRequest))):(room?.game==='dino'&&room.phase==='racing'||room?.game==='reflex'&&['reflex-wait','reflex-go'].includes(room.phase))?300:650);}
  function field(parent,label,input){const n=el('label','games-field');n.append(el('span','',label),input);parent.append(n);return input;}
  function scores(host){host.replaceChildren();if(!room)return;for(const p of [...room.players].sort((a,b)=>b.score-a.score)){const row=el('div','games-player');row.style.setProperty('--player',String(room.players.findIndex(x=>x.id===p.id)));row.append(el('b','',p.name+(p.id===room.you?' (du)':'')),el('span','',room.phase==='lobby'?(p.id===room.host?'Gastgeber':p.online?'Bereit':'Offline'):p.score+' Punkte'+(p.online?'':' · Offline')));host.append(row);}}
  function serverNow(){return room.now+Date.now()-room.receivedAt;}
  function renderRoom(){
    if(!visible||!roomRoot?.isConnected)return;
    const next=room?String(!!room.testMode)+':'+room.game+':'+room.phase+':'+(room.round??'')+':'+(room.drawer??'')+(room.game==='ships'?':'+room.ready:'')+(room.game==='reflex'?':'+room.submitted:'')+(['lobby','finished'].includes(room.phase)?':'+room.host:''):'setup';
    if(signature===next&&room){updateRoom();return;}signature=next;inkQueue=inkQueue.filter(stroke=>room?.phase==='drawing'&&room.drawer===room.you&&stroke.round===room.round);drawing=null;stickDispose();stickDispose=()=>{};cancelAnimationFrame(frame);onKey=null;roomRoot.replaceChildren();
    if(!room){const setup=el('div','games-room-setup'),name=field(setup,'Dein Spielername',el('input'));name.maxLength=24;name.placeholder='Spielername';let wordMode=null;if(current==='draw'){wordMode=el('select');for(const [value,label]of [['mixed','Gemischt · 4.000 Begriffe'],['classic','Klassisch · 999 Begriffe'],['fantasy','Fantasie · 3.001 Begriffe']])wordMode.add(new Option(label,value));field(setup,'Zeichenbegriffe',wordMode);setup.append(el('p','games-muted','Fantasiebegriffe kombinieren sichtbare Motive, zum Beispiel Roboterhund oder Wolkenschloss. Das ganze angezeigte Wort wird erraten.'));}if(current==='stick')setup.append(btn('Gegen CPU oder zu zweit an diesem Gerät',()=>solo('stick')));if(window.AtlasLocalGames?.supported.includes(current))setup.append(btn('Zu zweit an diesem Gerät',()=>window.AtlasLocalGames.start(current,{el,btn,view,begin,sound,keys:fn=>onKey=fn,cleanup:fn=>stopGame=fn})));setup.append(btn('Raum erstellen',()=>api('create',{game:current,name:name.value,wordMode:wordMode?.value||'mixed'})));const code=field(setup,'Raumcode',el('input'));code.maxLength=6;code.placeholder='ABC234';setup.append(btn('Beitreten',()=>api('join',{code:code.value.trim().toUpperCase(),name:name.value})));if(credential)setup.append(btn('Gespeicherten Raum fortsetzen',()=>api('state')),btn('Raum vergessen',()=>{credential=null;store();signature='';renderRoom();}));setup.append(el('p','games-muted','Alle Spieler brauchen denselben Serverlink. Windows verwendet den Server aus den KI-Einstellungen. Räume werden nach längerer Inaktivität oder einem Serverneustart beendet.'));roomRoot.append(setup,el('p','games-network',netError));return;}
    if(room.testMode)roomRoot.append(el('p','games-admin-banner',room.adminNotice));
    const bar=el('div','games-toolbar');bar.append(el('b','','Raum '+room.code),btn('Code kopieren',async()=>{try{await navigator.clipboard.writeText(room.code);}catch{netError='Raumcode: '+room.code;updateRoom();}}),btn('Raum verlassen',()=>{inkQueue=[];api('leave');}));if(room.phase==='lobby')bar.append(btn('Freunde einladen',()=>window.AtlasSocial?.invite({service:'games',...credential}).catch(error=>{netError=error.message;updateRoom();})));roomRoot.append(bar,el('p','games-network',netError));
    if(room.phase==='lobby'){roomRoot.append(el('h2','',gameTitles[room.game]),el('p','games-muted','Teile den Raumcode. Der Gastgeber startet, sobald mindestens zwei Spieler verbunden sind.'));if(room.host===room.you)roomRoot.append(btn('Spiel starten',()=>api('start')));}
    else if(room.game==='stick'){stickDir=0;stickUse=Math.max(0,...room.battle.fighters.map(p=>p.useSeq||0));stickSeq=Math.max(stickSeq,...room.battle.fighters.map(p=>p.seq));stickDispose=window.AtlasStick.online(stickContext(),roomRoot,()=>room,d=>{stickDir=d;if(room?.phase==='stick')api('stick_input',{direction:d,sequence:++stickSeq,useSequence:stickUse});},()=>api('rematch'),()=>{stickUse++;if(room?.phase==='stick')api('stick_input',{direction:stickDir,sequence:++stickSeq,useSequence:stickUse});});}
    else if(newGames.multi[room.game]){newGames.renderMulti({el,btn},roomRoot,room,api,serverNow());}
    else if(room.game==='connect'){const board=el('div','connect-board');board.setAttribute('aria-label','Vier gewinnt Spielfeld');roomRoot.append(el('p','games-turn'),board);}
    else if(room.game==='draw'){setupDrawing();}
    else if(['ttt','ships','reflex'].includes(room.game)){setupExtraOnline();}
    else if(room.game==='dino'){const canvas=el('canvas','games-race');canvas.width=900;canvas.height=260;canvas.setAttribute('aria-label','Dino Run Rennstrecke');roomRoot.append(el('p','games-turn'),canvas);if(room.phase==='racing'){roomRoot.append(btn('Springen · Leertaste',()=>api('jump')));onKey=e=>{if(e.code==='Space'||e.key==='ArrowUp'){e.preventDefault();if(!e.repeat)api('jump');}};canvas.onpointerdown=()=>api('jump');}animateRace();}
    if(room.phase==='finished'&&room.game!=='stick'){roomRoot.append(el('h2','','Runde beendet'));if(room.host===room.you)roomRoot.append(btn('Revanche starten',()=>api('rematch')));else roomRoot.append(el('p','games-muted','Der Gastgeber kann eine Revanche starten.'));}
    const players=el('div','games-players');roomRoot.append(players);updateRoom();
  }
  function updateRoom(){if(!roomRoot?.isConnected||!room)return;scores(roomRoot.querySelector('.games-players'));const note=roomRoot.querySelector('.games-network');if(note)note.textContent=netError;
    if(newGames.multi[room.game]&&room.phase!=='lobby')newGames.renderMulti({el,btn},roomRoot,room,api,serverNow());
    if(room.game==='connect'&&room.phase!=='lobby'){const board=roomRoot.querySelector('.connect-board');board.replaceChildren();room.grid.forEach((mark,i)=>{const cell=btn('',()=>api('move',{column:i%7,version:room.version}),'connect-cell');cell.dataset.mark=String(mark);cell.disabled=room.phase!=='playing'||room.turn!==room.you;cell.setAttribute('aria-label','Spalte '+(i%7+1)+', Reihe '+(Math.floor(i/7)+1)+(mark?', Spieler '+mark:', frei'));board.append(cell);});const p=room.players.find(p=>p.id===room.turn),winner=room.players.find(p=>p.id===room.winner);roomRoot.querySelector('.games-turn').textContent=room.phase==='finished'?(winner?winner.name+' gewinnt!'+(room.reason?' '+room.reason:''):room.reason||'Unentschieden'):(p?.name||'')+' ist dran · '+Math.max(0,Math.ceil((room.deadline-serverNow())/1000))+' s'+(room.reason?' · '+room.reason:'');}
    if(['ttt','ships','reflex'].includes(room.game)&&room.phase!=='lobby')updateExtraOnline();
    if(room.game==='draw'&&room.phase!=='lobby')updateDrawing();
  }
  let reflexTapped=null;
  function setupExtraOnline(){
    roomRoot.append(el('p','games-turn'));
    if(room.game==='ttt'){const board=el('div','ttt-board');board.setAttribute('aria-label','Tic-Tac-Toe Spielfeld');roomRoot.append(board);}
    if(room.game==='ships'){
      if(room.phase==='ships-setup'&&!room.ready){const draft=[],directions=el('select'),status=el('p','games-fleet-status'),grid=el('div','ships-board');directions.add(new Option('Waagrecht','h'));directions.add(new Option('Senkrecht','v'));directions.setAttribute('aria-label','Schiffsrichtung');const tools=el('div','games-toolbar'),ready=btn('Flotte bereit',()=>{if(draft.length===3)api('fleet',{fleet:draft});});ready.disabled=true;tools.append(directions,btn('Letztes Schiff zurück',()=>{draft.pop();drawFleet();}),btn('Zufällig setzen & bereit',()=>api('fleet',{random:true})),ready);roomRoot.append(el('h3','','Deine Flotte aufstellen'),status,tools,grid);
        function drawFleet(){const occupied=new Set(draft.flat()),length=[4,3,2][draft.length];status.textContent=length?'Setze Schiff '+(draft.length+1)+' von 3 · Länge '+length:'Alle Schiffe gesetzt. Klicke auf Flotte bereit.';ready.disabled=draft.length!==3;grid.replaceChildren();for(let cell=0;cell<64;cell++){const b=btn(occupied.has(cell)?'■':'',()=>{if(!length)return;const row=Math.floor(cell/8),col=cell%8,cells=Array.from({length},(_,i)=>cell+(directions.value==='v'?i*8:i));if(cells.some(i=>i>=64||occupied.has(i))||directions.value==='h'&&col+length>8||directions.value==='v'&&row+length>8){status.textContent='Das Schiff passt hier nicht. Wähle einen anderen Startpunkt.';return;}draft.push(cells);drawFleet();},'ships-cell');b.classList.toggle('ship',occupied.has(cell));b.setAttribute('aria-label',String.fromCharCode(65+cell%8)+(Math.floor(cell/8)+1)+(occupied.has(cell)?', Schiff':''));grid.append(b);}}drawFleet();
      }else{const layout=el('div','ships-layout'),own=el('section'),enemy=el('section');own.append(el('h3','','Dein Meer'),el('div','ships-board ships-own'));enemy.append(el('h3','','Gegnerisches Meer'),el('div','ships-board ships-target'));layout.append(own,enemy);roomRoot.append(layout);}
    }
    if(room.game==='reflex'){
      if(room.round!==reflexTapped?.round)reflexTapped=null;
      const surface=btn('',()=>{if(room.submitted||reflexTapped?.round===room.round||!['reflex-wait','reflex-go'].includes(room.phase))return;reflexTapped={round:room.round};surface.disabled=true;surface.textContent='Abgegeben …';api('react',{round:room.round,cueToken:room.cueToken,early:room.phase==='reflex-wait'});},'reaction-surface reflex-surface');roomRoot.append(surface,el('div','reflex-results'));onKey=e=>{if(e.code==='Space'){e.preventDefault();if(!e.repeat)surface.click();}};
    }
  }
  function updateExtraOnline(){
    const turn=roomRoot.querySelector('.games-turn'),player=room.players.find(p=>p.id===room.turn),winner=room.players.find(p=>p.id===room.winner);
    if(room.game==='ttt'){const grid=roomRoot.querySelector('.ttt-board');grid.replaceChildren();room.grid.forEach((mark,cell)=>{const b=btn(mark===1?'X':mark===2?'O':'',()=>api('ttt',{cell,version:room.version}),'ttt-cell');b.disabled=room.phase!=='ttt-play'||room.turn!==room.you||!!mark;b.dataset.mark=String(mark);b.setAttribute('aria-label','Feld '+(cell+1)+(mark?', '+(mark===1?'X':'O'):', leer'));grid.append(b);});turn.textContent=room.phase==='finished'?(winner?winner.name+' gewinnt!'+(room.reason?' '+room.reason:''):room.reason||'Unentschieden'):(player?.name||'')+' ist dran · '+Math.max(0,Math.ceil((room.deadline-serverNow())/1000))+' s';}
    if(room.game==='ships'){
      if(room.phase==='ships-setup'){turn.textContent=(room.ready?'Deine Flotte ist bereit. ':'')+(room.enemyReady?'Gegner bereit.':'Gegner stellt auf.')+' · '+Math.max(0,Math.ceil((room.deadline-serverNow())/1000))+' s';}else turn.textContent=room.phase==='finished'?(winner?winner.name+' gewinnt!':room.reason||'Runde beendet'):(player?.name||'')+' schiesst · '+Math.max(0,Math.ceil((room.deadline-serverNow())/1000))+' s';
      const own=roomRoot.querySelector('.ships-own'),target=roomRoot.querySelector('.ships-target');if(own&&target){own.replaceChildren();target.replaceChildren();const fleet=new Set(room.ownFleet.flat()),enemyFleet=new Set((room.enemyFleet||[]).flat()),incoming=new Set(room.incoming),outgoing=new Map(room.outgoing.map(s=>[s.cell,s]));for(let cell=0;cell<64;cell++){const hit=incoming.has(cell),b=el('div','ships-cell',hit?(fleet.has(cell)?'×':'·'):fleet.has(cell)?'■':'');b.classList.toggle('ship',fleet.has(cell));b.classList.toggle('hit',hit&&fleet.has(cell));b.setAttribute('aria-label',String.fromCharCode(65+cell%8)+(Math.floor(cell/8)+1));own.append(b);const shot=outgoing.get(cell),t=btn(shot?(shot.hit?'×':'·'):enemyFleet.has(cell)?'■':'',()=>api('fire',{cell,version:room.version}),'ships-cell');t.disabled=room.phase!=='ships-play'||room.turn!==room.you||!!shot;t.classList.toggle('hit',!!shot?.hit);t.classList.toggle('sunk',!!shot?.sunk);t.classList.toggle('ship',enemyFleet.has(cell)&&!shot);t.setAttribute('aria-label',String.fromCharCode(65+cell%8)+(Math.floor(cell/8)+1)+(shot?shot.hit?', Treffer':', Wasser':', noch nicht beschossen'));target.append(t);}}
    }
    if(room.game==='reflex'){
      turn.textContent='Runde '+(room.round+1)+' / 5';const surface=roomRoot.querySelector('.reflex-surface'),done=room.submitted||reflexTapped?.round===room.round;surface.disabled=done||!['reflex-wait','reflex-go'].includes(room.phase);surface.dataset.phase=room.phase==='reflex-go'&&!done?'go':room.early?'early':'wait';surface.textContent=room.phase==='reflex-result'||room.phase==='finished'?'Runde ausgewertet':room.early?'Fehlstart – nächste Runde!':done?'Antwort abgegeben':room.phase==='reflex-go'?'JETZT DRÜCKEN!':'Warten …';const result=roomRoot.querySelector('.reflex-results');result.replaceChildren();for(const p of room.reactions||[])result.append(el('p','',p.name+': '+(p.early?'Fehlstart':p.missed?'Keine Antwort':p.ms+' ms · +'+p.points+' Punkte')));
    }
  }

  function setupDrawing(){
    roomRoot.append(el('p','games-turn'));const canvas=el('canvas','games-drawing');canvas.width=900;canvas.height=500;canvas.style.touchAction='none';roomRoot.append(canvas);
    if(room.drawer===room.you&&room.phase==='drawing'){const tools=el('div','games-toolbar'),colors=el('select'),width=el('select');for(const [value,label]of [['#171e2b','Schwarz'],['#7c63df','Violett'],['#e75d76','Rot'],['#32a88a','Grün'],['#e3a637','Gelb'],['#287ccc','Blau'],['#ffffff','Radierer']])colors.add(new Option(label,value));for(const n of [3,6,12])width.add(new Option(n+' px',String(n)));width.value='6';tools.append(colors,width,btn('Fläche leeren',()=>{if(networkBusy)return;inkQueue=[];drawing=null;api('clear',{round:room.round});}));roomRoot.append(tools);
      const point=e=>{const r=canvas.getBoundingClientRect();return [Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),Math.max(0,Math.min(1,(e.clientY-r.top)/r.height))];};
      canvas.onpointerdown=e=>{if(e.button!==0)return;canvas.setPointerCapture(e.pointerId);drawing={points:[point(e)],color:colors.value,width:Number(width.value),round:room.round};};
      canvas.onpointermove=e=>{if(!drawing)return;const p=point(e),last=drawing.points.at(-1);if(Math.hypot(p[0]-last[0],p[1]-last[1])<.003)return;drawing.points.push(p);paintStroke(canvas.getContext('2d'),{...drawing,points:[last,p]});if(drawing.points.length>=60){inkQueue.push({...drawing,points:drawing.points.slice()});drawing.points=[p];if(inkQueue.length>15){drawing=null;inkQueue=inkQueue.slice(0,15);netError='Bitte langsamer zeichnen – Verbindung holt auf.';}}};
      const finish=()=>{if(drawing){inkQueue.push(drawing);drawing=null;schedule();}};canvas.onpointerup=finish;canvas.onpointercancel=finish;
    }else if(room.phase==='drawing'&&!room.guessed.includes(room.you)){const form=el('form','games-guess'),input=el('input'),send=el('button','primary-button','Raten');input.maxLength=80;input.placeholder='Dein Tipp …';input.setAttribute('aria-label','Geratenes Wort');send.type='submit';form.append(input,send);form.onsubmit=e=>{e.preventDefault();if(!networkBusy&&input.value.trim()){api('guess',{text:input.value,round:room.round});input.value='';}};roomRoot.append(form);}
    roomRoot.append(el('div','games-guesses'));
  }
  function paintStroke(ctx,stroke){ctx.strokeStyle=stroke.color;ctx.fillStyle=stroke.color;ctx.lineWidth=stroke.width;ctx.lineJoin='round';ctx.lineCap='round';if(stroke.points.length===1){ctx.beginPath();ctx.arc(stroke.points[0][0]*900,stroke.points[0][1]*500,stroke.width/2,0,Math.PI*2);ctx.fill();return;}ctx.beginPath();stroke.points.forEach((p,i)=>i?ctx.lineTo(p[0]*900,p[1]*500):ctx.moveTo(p[0]*900,p[1]*500));ctx.stroke();}
  function updateDrawing(){const canvas=roomRoot.querySelector('.games-drawing');if(!canvas)return;const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,900,500);for(const stroke of room.ink||[])paintStroke(ctx,stroke);for(const stroke of inkQueue)if(stroke.round===room.round)paintStroke(ctx,stroke);if(drawing)paintStroke(ctx,drawing);
    const drawer=room.players.find(p=>p.id===room.drawer)?.name||'Spieler',left=Math.max(0,Math.ceil(((room.phase==='reveal'?room.nextAt:room.deadline)-serverNow())/1000));roomRoot.querySelector('.games-turn').textContent='Runde '+(room.round+1)+' / '+room.total+' · '+drawer+' zeichnet · '+(room.word?'Wort: '+room.word:room.clue)+(room.phase==='finished'?'':' · '+left+' s');
    const guesses=roomRoot.querySelector('.games-guesses');guesses.replaceChildren();for(const m of room.messages||[])guesses.append(el('p',m.correct?'guessed':'',m.name+': '+m.text));if(room.guessed?.includes(room.you))roomRoot.querySelector('.games-guess')?.remove();
  }
  function animateRace(){cancelAnimationFrame(frame);const canvas=roomRoot?.querySelector('.games-race');if(!canvas||!visible)return;const ctx=canvas.getContext('2d'),now=serverNow(),elapsed=Math.max(0,Math.min(.5,(now-room.now)/1000)),running=room.phase==='racing'&&now>=room.started;
    ctx.fillStyle='#141c2c';ctx.fillRect(0,0,900,260);ctx.fillStyle='#293750';ctx.fillRect(0,211,900,2);ctx.fillStyle='#7c8ba5';ctx.font='14px sans-serif';ctx.fillText('DINO RUN · '+(now<room.started?'Start in '+Math.ceil((room.started-now)/1000)+' s':Math.max(0,Math.ceil((room.started+room.duration-now)/1000))+' s'),20,30);
    for(const o of room.obstacles||[]){ctx.fillStyle='#ec91a4';ctx.fillRect(o.x-(running?elapsed*room.speed:0),210-o.height,o.width,o.height);}
    room.players.forEach((p,i)=>{const height=running?Math.max(0,p.height+p.velocity*elapsed-900*elapsed*elapsed):p.height,local=p.id===room.you;ctx.globalAlpha=(p.alive||room.phase==='finished')?.85:.25;ctx.fillStyle=local?'#c5b2ff':['#61dcb4','#7fb5ff','#f7ce73','#ed91b1'][i%4];const x=80+i*3;ctx.fillRect(x,210-height-32,27,32);ctx.fillRect(x+15,210-height-42,22,21);ctx.fillStyle='#121826';ctx.fillRect(x+30,210-height-38,3,3);ctx.globalAlpha=1;if(local){ctx.fillStyle='#e9e3ff';ctx.fillText('DU',x-1,210-height-52);}});
    const label=roomRoot.querySelector('.games-turn'),me=room.players.find(p=>p.id===room.you);if(label)label.textContent=room.phase==='finished'?'Rennen beendet – Ergebnis unten':me?.alive?'Springe mit Leertaste, ↑ oder Tippen.':'Ausgeschieden – schau den anderen zu.';frame=requestAnimationFrame(animateRace);
  }
  document.addEventListener('keydown',e=>{if(visible&&!e.target.matches('input,textarea,select')&&!e.target.closest('.games-rules')&&onKey)onKey(e);});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){if(current==='stick'){stickDir=0;return;}stopGame();if(['snake','reaction'].includes(current)&&visible){onKey=null;view.append(btn('Spiel nach Pause neu starten',()=>solo(current)));}}});
})();
