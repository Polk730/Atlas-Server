/* Natural server-generated speech; never silently falls back to browser voices. */
(() => {
  const KEY='atlas.web.speech.v1';let preferences={auto:false};
  try{preferences={...preferences,...JSON.parse(localStorage.getItem(KEY)||'{}')};}catch{}
  let playback=0,activeButton=null,rendering=false;
  const settings=document.querySelector('#ai-settings-dialog');
  const tab=document.createElement('button');tab.type='button';tab.dataset.group='natural-voice';tab.textContent='Stimme';settings.querySelector('.settings-tabs').append(tab);
  const card=document.createElement('div');card.className='setting-card hidden';card.dataset.settingsGroup='natural-voice';
  card.innerHTML='<h3>Atlas Neural · natürliche Stimme</h3><p>Atlas erzeugt die Stimme auf deinem Server. Deutsch: Thorsten · Englisch: Ryan. Kein kostenpflichtiger Sprachdienst erforderlich.</p><label class="preference-toggle"><input id="web-speech-auto" type="checkbox"> Neue Chat-Antworten automatisch vorlesen</label><label for="web-speech-rate">Sprechtempo</label><input id="web-speech-rate" type="range" min="0.7" max="1.3" step="0.05"><p id="web-speech-state" role="status">Stimme wird geprüft …</p><div class="account-actions"><button type="button" id="web-speech-test" class="primary-button">▶ Stimme anhören</button><button type="button" id="web-speech-stop" class="secondary-button">■ Stoppen</button></div><small>Bei langen Antworten liest Atlas abschnittsweise vor. Falls der Browser die Wiedergabe blockiert, klicke direkt unter einer Antwort auf „Vorlesen“.</small>';
  settings.querySelector('.settings-content').append(card);
  const status=card.querySelector('#web-speech-state'),auto=card.querySelector('#web-speech-auto'),rate=card.querySelector('#web-speech-rate');
  auto.checked=Boolean(preferences.auto);rate.value=uiPreferences.speechRate||1;
  function store(){try{localStorage.setItem(KEY,JSON.stringify(preferences));}catch{toast('Die Vorlese-Einstellung konnte nicht gespeichert werden.',{error:true});}}
  function stop(){playback++;stopGeneratedSpeech();if(activeButton){activeButton.disabled=false;activeButton.textContent='▶ Vorlesen';activeButton.setAttribute('aria-pressed','false');activeButton=null;}}
  function chunks(value){let text=String(value||'').trim().slice(0,12000),result=[];while(text){let length=Math.min(1600,text.length);if(length<text.length){const breakAt=Math.max(text.lastIndexOf('. ',length),text.lastIndexOf('! ',length),text.lastIndexOf('? ',length),text.lastIndexOf('\n',length));if(breakAt>500)length=breakAt+1;else{const space=text.lastIndexOf(' ',length);if(space>500)length=space;}}result.push(text.slice(0,length));text=text.slice(length).trim();}return result;}
  async function play(text,button){
    if(activeButton===button&&button){stop();status.textContent='Vorlesen gestoppt.';return;}
    stop();const generation=playback;activeButton=button||null;
    if(button){button.textContent='■ Vorlesen stoppen';button.setAttribute('aria-pressed','true');}
    uiPreferences.audioVoiceURI='atlas-neural';
    status.textContent='Natürliche Stimme wird auf dem Server vorbereitet …';
    try{
      for(const part of chunks(text)){
        if(generation!==playback)return;
        const language=uiPreferences.audioLanguage==='en'?'en':uiPreferences.audioLanguage==='de'?'de':detectReplyLanguage(part);
        const played=await playLocalSpeech(part,language,()=>{status.textContent='Atlas spricht …';});
        if(generation!==playback||!played)return;
      }
      status.textContent='Fertig. Atlas Neural ist bereit.';
    }catch(error){if(generation!==playback)return;const message=error?.name==='NotAllowedError'?'Der Browser hat die Wiedergabe blockiert. Klicke auf „Vorlesen“, um die Stimme zu starten.':error.message||'Die natürliche Stimme ist gerade nicht erreichbar.';status.textContent=message;toast(message,{error:true});}
    finally{if(generation===playback){if(button){button.disabled=false;button.textContent='▶ Vorlesen';button.setAttribute('aria-pressed','false');}activeButton=null;}}
  }
  auto.addEventListener('change',()=>{preferences.auto=auto.checked;store();if(preferences.auto)play('Die natürliche Stimme ist aktiviert. Ich lese neue Antworten für dich vor.');else stop();});
  rate.addEventListener('input',()=>{uiPreferences.speechRate=Number(rate.value);saveUIPreferences();});
  card.querySelector('#web-speech-test').onclick=()=>play('Hallo. Ich bin Atlas. Was möchtest du heute machen?');
  card.querySelector('#web-speech-stop').onclick=()=>{stop();status.textContent='Vorlesen gestoppt.';};
  const originalAdd=addBubble;
  addBubble=function(item){const bubble=originalAdd(item);if(item.role==='assistant'&&item.text?.trim()){
    const button=document.createElement('button');button.type='button';button.className='secondary-button web-read-aloud';button.textContent='▶ Vorlesen';button.setAttribute('aria-pressed','false');button.onclick=()=>play(item.text,button);bubble.append(button);
    if(!rendering&&preferences.auto&&!/^Ich suche nach /i.test(item.text))queueMicrotask(()=>play(item.text,button));
  }return bubble;};
  const originalRender=renderChat;renderChat=function(...args){rendering=true;try{return originalRender(...args);}finally{rendering=false;}};
  renderChat();
  window.samuelDesktop.getSpeechStatus().then(value=>{status.textContent=value.available?'Atlas Neural ist bereit.':'Die Stimmdateien fehlen auf dem Server. Bitte das aktualisierte SSD-Paket verwenden.';}).catch(()=>{status.textContent='Der Stimmserver ist noch nicht erreichbar. Bitte den aktualisierten Server starten.';});
  window.addEventListener('pagehide',()=>stop());
})();
