/* Polling notifications while Atlas is running; never marks messages as read. */
(()=>{'use strict';
if(typeof uiPreferences==='undefined'||!window.samuelDesktop?.social)return;
uiPreferences.chatNotifications=uiPreferences.chatNotifications!==false;
uiPreferences.chatNotificationPreview=uiPreferences.chatNotificationPreview===true;
const native=typeof window.samuelDesktop.notifyChat==='function',el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
const host=el('div','atlas-notice-stack');host.setAttribute('aria-live','polite');host.setAttribute('aria-label','Neue Nachrichten');document.body.append(host);
const settings=document.querySelector('.personal-settings');const section=el('div','chat-notification-settings'),heading=el('h3','','Nachrichtenbenachrichtigungen'),copy=el('p','','Meldungen für neue private Nachrichten und Gruppenchats, solange Atlas geöffnet ist.');section.append(heading,copy);
const enabled=el('input'),preview=el('input');enabled.type=preview.type='checkbox';enabled.checked=uiPreferences.chatNotifications;preview.checked=uiPreferences.chatNotificationPreview;
for(const [input,label]of [[enabled,'Neue Nachrichten melden'],[preview,'Nachrichtentext in der Meldung zeigen']]){const row=el('label','chat-notification-option');row.append(input,el('span','',label));section.append(row);}
const permission=el('button','secondary-button','Systemmeldungen erlauben'),status=el('p','preference-status');permission.type='button';section.append(permission,status);settings?.append(section);
function sync(){enabled.checked=uiPreferences.chatNotifications!==false;preview.checked=uiPreferences.chatNotificationPreview===true;
permission.hidden=native;permission.disabled=!('Notification' in window)||Notification.permission==='denied'||Notification.permission==='granted';
status.textContent=native?'Windows-Meldungen sind verfügbar. Windows kann sie über „Nicht stören“ stummschalten.':!('Notification' in window)?'Dieses Gerät zeigt Meldungen innerhalb von Atlas.':Notification.permission==='granted'?'Systemmeldungen erlaubt. Atlas muss im Browser geöffnet bleiben.':Notification.permission==='denied'?'Systemmeldungen im Browser blockiert. Du kannst sie in den Website-Berechtigungen erlauben.':'In Atlas aktiv. Für Browser-Systemmeldungen einmal „Systemmeldungen erlauben“ drücken.';
}
enabled.onchange=()=>{uiPreferences.chatNotifications=enabled.checked;saveUIPreferences();if(!enabled.checked){host.replaceChildren();for(const n of browserNotices)n.close();browserNotices.clear();window.samuelDesktop.clearChatNotifications?.();}sync();};preview.onchange=()=>{uiPreferences.chatNotificationPreview=preview.checked;saveUIPreferences();};
permission.onclick=async()=>{if('Notification' in window){await Notification.requestPermission();sync();}};
const startedAt=new Date().toISOString();
let account=null,email='',cursors=new Map(),timer=null,working=false,failures=0;const browserNotices=new Set();
function clear(){account=null;cursors.clear();host.replaceChildren();for(const n of browserNotices)n.close();browserNotices.clear();window.samuelDesktop.clearChatNotifications?.();}
const open=(threadId)=>{window.focus();window.AtlasSocial?.openThread(threadId);};
window.samuelDesktop.onChatNotification?.(payload=>{if(payload?.accountId===account)open(payload.threadId);});
function alreadySeen(id){try{const key='atlas.chat.notices.v1:'+account,ids=JSON.parse(localStorage.getItem(key)||'[]');if(Array.isArray(ids)&&ids.includes(id))return true;localStorage.setItem(key,JSON.stringify([...(Array.isArray(ids)?ids:[]),id].slice(-150)));}catch{}return false;}
async function notify(thread,message,me){if(uiPreferences.chatNotifications===false||window.AtlasSocial?.isThreadOpen(thread.id)||alreadySeen(message.id))return;
const title=thread.kind==='group'?(thread.title||'Gruppenchat'):message.name||'Neue Nachricht';const body=uiPreferences.chatNotificationPreview===true?(message.kind==='image'?'Bild gesendet':message.kind==='invite'?'Spieleinladung':String(message.body||'Neue Nachricht').slice(0,160)):'Neue Nachricht'+(thread.kind==='group'?' von '+(message.name||'einem Mitglied'):'');
if(native){try{if(await window.samuelDesktop.notifyChat({accountId:me,threadId:thread.id,title,body}))return;}catch{}}
if('Notification' in window&&Notification.permission==='granted'&&document.hidden){try{const n=new Notification(title,{body,tag:'atlas-chat-'+thread.id});browserNotices.add(n);n.onclick=()=>{n.close();browserNotices.delete(n);open(thread.id);};n.onclose=()=>browserNotices.delete(n);return;}catch{}}
const card=el('div','atlas-chat-notice'),link=el('button','atlas-notice-open'),close=el('button','atlas-notice-close','×');link.type=close.type='button';link.append(el('strong','',title),el('span','',body));link.onclick=()=>{card.remove();open(thread.id);};close.setAttribute('aria-label','Benachrichtigung schließen');close.onclick=()=>card.remove();card.append(link,close);host.append(card);while(host.children.length>3)host.firstChild.remove();setTimeout(()=>card.remove(),10000);
}
async function poll(){if(working)return;working=true;try{
 const signed=await window.samuelDesktop.getAccountStatus();if(!signed.signedIn){clear();email='';return;}if(email&&email!==signed.email)clear();email=signed.email;
 const result=await window.samuelDesktop.social('bootstrap',{}),next=result.data;if(!next?.me){clear();return;}
 const initial=account!==result.accountId;if(initial){clear();account=result.accountId;}
 let fetched=0;
 for(const t of next.threads||[]){const at=t.last?.at||'',before=cursors.get(t.id)||startedAt;if(initial||!at||at===before||!t.unread){cursors.set(t.id,at);continue;}if(fetched>=5)continue;
 if(uiPreferences.chatNotifications===false||window.AtlasSocial?.isThreadOpen(t.id)){cursors.set(t.id,at);continue;}
 fetched++;const history=await window.samuelDesktop.social('history',{threadId:t.id,markRead:false},account);if(history.accountId!==account)continue;
 const messages=(history.data?.messages||[]).filter(m=>m.senderId!==next.me.id&&Date.parse(m.at)>Date.parse(before));
 const latest=messages.at(-1);if(latest)await notify(t,latest,account);cursors.set(t.id,at);
 }
 failures=0;sync();
 }catch{failures=Math.min(5,failures+1);}finally{working=false;clearTimeout(timer);timer=setTimeout(poll,Math.min(60000,8000*(1+failures)));}}
document.addEventListener('visibilitychange',()=>{if(!document.hidden){clearTimeout(timer);poll();sync();}});
const oldTheme=applyTheme;applyTheme=function(...args){const result=oldTheme(...args);sync();return result;};
sync();timer=setTimeout(poll,1200);
})();
