/* Vocci: local vocabulary sets, photo import and offline learning activities. */
(() => {
  const KEY='atlas-vocci-v1';
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const uid=()=>crypto.randomUUID();
  const shuffle=list=>{const copy=[...list];for(let i=copy.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[copy[i],copy[j]]=[copy[j],copy[i]];}return copy;};
  const normal=value=>String(value).normalize('NFC').trim().toLocaleLowerCase().replace(/[.!?]+$/,'').replace(/\s+/g,' ');
  // Ignore sentence punctuation, but preserve decimal separators and meaningful word spelling.
  const answerKey=value=>String(value).normalize('NFC').toLocaleLowerCase().replace(/[’‘ʼ]/g,"'").replace(/(?<!\d)[.,]|[.,](?!\d)|[!?…，。！？]/gu,' ').replace(/\s+/g,' ').trim();
  const accepted=(given,expected)=>{const key=answerKey(given);return !!key&&expected.split(/\s*[;|]\s*/).some(answer=>answerKey(answer)===key);};
  let baseline=AtlasLearningSync.read(),decks=baseline.decks;
  baseline=JSON.parse(JSON.stringify(baseline));
  let selected=decks[0]?.id||null,mode='overview',draft=null,session=null,job=null,timer=null,readTimer=null,memoryTimer=null;
  let memorySize=0,swipe=null,suppressFlipUntil=0;
  let sourceImage=null,sourceName='',busy=false,sourcePhotos=[],choosingPhotos=false,cancelRequested=false;
  const panel=document.createElement('section');panel.id='learn-view';panel.className='hidden';
  panel.innerHTML=`<div class="vocci-shell"><header class="vocci-header"><div><p class="eyebrow">LERNEN / VOCCI</p><h1>Wörter, die bleiben.</h1><p>Deine Vokabeln. Dein Tempo. Vom Foto bis zum kleinen Erfolg.</p></div><span class="vocci-badge">✦ VOCCI</span></header><div class="vocci-layout"><aside class="vocci-library"><div class="vocci-library-head"><b>Meine Lernsets</b><button type="button" data-vocci="new" aria-label="Lernset erstellen">＋</button></div><div id="vocci-decks"></div><small>Lokal verfügbar · mit Atlas-Konto automatisch in der Cloud.</small></aside><div class="vocci-content"><div id="vocci-tabs" class="vocci-tabs"></div><div id="vocci-stage" aria-live="polite"></div></div></div><input id="vocci-file" type="file" multiple accept="image/png,image/jpeg,image/webp" hidden></div>`;
  document.querySelector('main.main').append(panel);
  const nav=document.createElement('button');nav.type='button';nav.className='nav-item';nav.dataset.view='learn';nav.innerHTML='<span>▱</span> Lernen';
  const grades=document.querySelector('.nav-item[data-view="grades"]');
  (grades||document.querySelector('.nav-item[data-view="research"]')).after(nav);
  const sub=document.createElement('button');sub.type='button';sub.className='vocci-subnav hidden';sub.textContent='Vocci';nav.after(sub);
  nav.onclick=sub.onclick=()=>{showView('learn');render();};
  const originalView=showView;
  showView=function(view){if(view!=='learn')leaveMemoryFullscreen();originalView(view);panel.classList.toggle('hidden',view!=='learn');sub.classList.toggle('hidden',view!=='learn');};
  const originalVoice=openVoiceMode;
  openVoiceMode=function(...args){leaveMemoryFullscreen();panel.classList.add('hidden');sub.classList.add('hidden');return originalVoice(...args);};
  const stage=panel.querySelector('#vocci-stage');
  const current=()=>decks.find(deck=>deck.id===selected);
  const cards=()=>current()?.cards||[];
  function persist(){
    try{const saved=AtlasLearningSync.commit(decks,baseline);baseline=JSON.parse(JSON.stringify(saved));decks=saved.decks;
      if(session){const byId=new Map((current()?.cards||[]).map(card=>[card.id,card]));for(const key of ['order','retry'])if(Array.isArray(session[key]))session[key]=session[key].map(card=>byId.get(card.id)||card);}
      scheduleCloudSave();return true;}
    catch{toast('Der Lernstand konnte nicht gespeichert werden. Bitte exportiere deine Lernsets und prüfe den freien Speicher.',{error:true});return false;}
  }
  window.addEventListener('atlas-learning-updated',()=>{
    const incoming=AtlasLearningSync.read().decks;
    // Keep an open editor or practice session intact; refresh the library from storage on exit.
    if(draft||session||busy){library();return;}
    decks=incoming;baseline=JSON.parse(JSON.stringify(AtlasLearningSync.read()));if(!decks.some(d=>d.id===selected))selected=decks[0]?.id||null;
    if(!panel.classList.contains('hidden'))render();else library();
  });
  const originalSoundPattern=uiSoundPattern;
  const vocciSounds={
    flip:[[520,0,.045,.009,'triangle'],[780,.035,.075,.006]],
    step:[[392,0,.045,.006,'triangle'],[523,.025,.055,.004]],
    correct:[[523.25,0,.09,.011],[659.25,.055,.13,.009],[783.99,.105,.17,.005]],
    again:[[349.23,0,.09,.007],[392,.06,.12,.005]],
    match:[[659.25,0,.1,.01],[987.77,.065,.19,.007]],
    miss:[[392,0,.07,.006],[329.63,.05,.1,.004]],
    finish:[[392,0,.15,.01],[523.25,.07,.18,.01],[659.25,.15,.22,.008],[1046.5,.24,.32,.004]],
    reveal:[[440,0,.09,.006],[659.25,.045,.14,.005]]
  };
  uiSoundPattern=function(kind){const notes=vocciSounds[kind.replace(/^vocci-/,'')];if(kind.startsWith('vocci-')&&notes){notes.forEach(note=>uiTone(...note));return;}originalSoundPattern(kind);};
  function sound(kind){try{playUiSound('vocci-'+(kind==='complete'?'finish':kind==='click'?'step':kind));}catch{}}
  const calm=()=>uiPreferences.reduceMotion||window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function animate(element,frames,options={}){if(calm()||!element?.animate)return null;return element.animate(frames,{duration:240,easing:'cubic-bezier(.2,.7,.25,1)',...options});}
  function enter(direction=1){animate(stage,[{opacity:.2,transform:`translateX(${direction*14}px)`},{opacity:1,transform:'translateX(0)'}]);}
  function celebrate(){
    if(calm())return;
    const host=stage.querySelector('.vocci-result')||stage;
    const sparks=document.createElement('div');sparks.className='vocci-sparks';sparks.setAttribute('aria-hidden','true');
    for(let i=0;i<12;i++){const spark=document.createElement('i');spark.style.setProperty('--i',i);sparks.append(spark);}
    host.append(sparks);setTimeout(()=>sparks.remove(),1000);
  }
  async function flipCard(){
    if(!session||session.flipping)return;const captured=session,index=session.index;session.flipping=true;sound('flip');
    const animation=animate(stage.querySelector('.vocci-flash'),[{transform:'perspective(900px) rotateY(0deg)'},{transform:'perspective(900px) rotateY(90deg)'}],{duration:110,easing:'ease-in'});
    if(animation)await animation.finished.catch(()=>{});
    if(session!==captured||mode!=='cards'||session.index!==index||panel.classList.contains('hidden')){captured.flipping=false;return;}
    session.flipped=!session.flipped;session.flipping=false;flashcards();
    animate(stage.querySelector('.vocci-flash'),[{transform:'perspective(900px) rotateY(-90deg)'},{transform:'perspective(900px) rotateY(0deg)'}],{duration:160,easing:'ease-out'});
  }
  function library(){
    panel.querySelector('#vocci-decks').innerHTML=decks.length?decks.map(deck=>`<button type="button" data-vocci="select" data-id="${esc(deck.id)}" class="vocci-deck ${selected===deck.id?'selected':''}"><span>▤</span><div><b>${esc(deck.title)}</b><small>${deck.cards.length} Wörter · ${deck.cards.filter(card=>card.due&&card.due>Date.now()).length} geübt</small></div></button>`).join(''):'<p class="vocci-muted">Hier warten bald deine ersten Wörter.</p>';
  }
  function setMode(next){
    window.AtlasMemorySplit?.stop();
    leaveMemoryFullscreen();
    clearTimeout(memoryTimer);memoryTimer=null;
    mode=next;session=null;memorySize=0;decks=AtlasLearningSync.read().decks;baseline=JSON.parse(JSON.stringify(AtlasLearningSync.read()));if(!decks.some(d=>d.id===selected))selected=decks[0]?.id||null;render();sound('step');enter();
  }
  function render(){
    library();
    const choices=[['overview','Übersicht'],['cards','Karteikarten'],['learn','Lernen'],['write','Schreibtrainer'],['progress','Fortschritt'],['multiplayer','Multiplayer'],['memory','Memory'],['test','Test']];
    panel.querySelector('#vocci-tabs').innerHTML=choices.map(([id,label])=>`<button type="button" data-vocci="mode" data-mode="${id}" class="${mode===id?'active':''}" ${!current()&&!['overview','multiplayer'].includes(id)?'disabled':''}>${label}</button>`).join('');
    if(mode==='overview'){overview();return;}
    if(mode==='multiplayer'){if(window.AtlasMultiplayer)window.AtlasMultiplayer.render(stage,current());else stage.textContent='Bitte Atlas vollständig aktualisieren.';return;}
    if(!current()){mode='overview';overview();return;}
    if(mode==='cards')flashcards();
    if(mode==='learn')learn();
    if(mode==='write')writing();
    if(mode==='progress')progress();
    if(mode==='memory')memory();
    if(mode==='test')test();
  }
  function overview(){
    if(draft){editor();return;}
    const deck=current();
    stage.innerHTML=`<section class="vocci-import"><div class="vocci-orbit">✧</div><div><p class="eyebrow">DEIN NÄCHSTES LERNSET</p><h2>Mehrere Fotos. Ein Lernset.</h2><p>Fotografiere beide Spalten deiner Vokabelliste. Atlas macht Wortpaare daraus, die du vor dem Lernen prüfen kannst.</p></div><div class="vocci-actions"><button type="button" class="primary-button" data-vocci="photo">＋ Fotos hochladen</button><button type="button" class="secondary-button" data-vocci="manual">Selbst eingeben</button><button type="button" class="secondary-button" data-vocci="import-set">Set importieren</button></div><p class="vocci-muted">PNG, JPG oder WebP · Foto bleibt nur für das Einlesen im Speicher. Im Gemini-Modus wird es an Google gesendet.</p></section>${deck?`<section class="vocci-set-header"><div><p class="eyebrow">AKTUELLES LERNSET</p><h2>${esc(deck.title)}</h2><p>${esc(deck.sourceLanguage||'Vorderseite')} → ${esc(deck.targetLanguage||'Rückseite')} · ${deck.cards.length} Wortpaare</p></div><div class="vocci-actions"><button type="button" class="secondary-button" data-vocci="edit">Bearbeiten</button><button type="button" class="secondary-button" data-vocci="copy-set">Set kopieren</button><button type="button" class="secondary-button" data-vocci="export">Exportieren</button><button type="button" class="secondary-button" data-vocci="delete">Löschen</button></div></section><section class="vocci-daily"><div><p class="eyebrow">KLEINE RUNDE · GROSSER FORTSCHRITT</p><h3>Deine nächsten 10 Wörter</h3><p>Fällige Wörter zuerst. Neue Wörter kommen in kleinen Portionen dazu.</p></div><button type="button" class="primary-button" data-vocci="mode" data-mode="learn">Tagesrunde starten →</button></section><div class="vocci-mode-grid">${[['cards','▤','Karteikarten','Umdrehen, wiederholen, sicher werden.'],['learn','↗','Gezielt lernen','Fällige und schwierige Wörter zuerst.'],['write','✎','Schreibtrainer','Selbst schreiben, Hinweise bekommen, Fehler verbessern.'],['progress','↗','Fortschritt','Sichere Wörter und schwierige Richtungen erkennen.'],['memory','◈','Memory','Finde die passenden Wortpaare.'],['test','✓','Wissen testen','Schreibe die Übersetzung ohne Hilfe.']].map(([id,icon,title,text])=>`<button type="button" class="vocci-mode-card" data-vocci="mode" data-mode="${id}"><span>${icon}</span><h3>${title}</h3><p>${text}</p><b>Loslegen ↗</b></button>`).join('')}</div><div class="vocci-stats"><span><b>${deck.cards.filter(card=>card.level>0).length}</b> schon geübt</span><span><b>${deck.cards.filter(card=>!card.due||card.due<=Date.now()).length}</b> heute fällig</span><span><b>${deck.lastTest?Math.round(deck.lastTest.correct/deck.lastTest.total*100)+' %':'—'}</b> letzter Test</span></div>`:'<div class="vocci-empty"><span>▤ ◈ ✓</span><h3>Dein erstes Lernset beginnt hier.</h3><p>Ein Bild reicht zum Start. Du kannst Wörter auch ohne KI von Hand eingeben.</p></div>'}`;
  }
  function newDraft(){draft={id:uid(),title:'Meine Vokabeln',sourceLanguage:'',targetLanguage:'',items:[]};mode='overview';session=null;sourceImage=null;sourcePhotos=[];sourceName='';}
  function editor(){
    stage.innerHTML=`<section class="vocci-editor"><div class="vocci-set-header"><div><p class="eyebrow">ERKENNEN · PRÜFEN · LERNEN</p><h2>Deine Wortpaare</h2><p>Kontrolliere besonders Artikel, Akzente und markierte Stellen.</p></div><button type="button" class="secondary-button" data-vocci="cancel-edit">Schliessen</button></div><div class="vocci-fields"><label>Name des Lernsets<input id="vocci-title" maxlength="80" value="${esc(draft.title)}"></label><label>Vorderseite / Sprache<input id="vocci-source" maxlength="60" placeholder="z. B. Französisch" value="${esc(draft.sourceLanguage)}"></label><label>Rückseite / Sprache<input id="vocci-target" maxlength="60" placeholder="z. B. Deutsch" value="${esc(draft.targetLanguage)}"></label></div><div class="vocci-photo-row">${sourcePhotos.map(photo=>`<div class="vocci-photo-item"><img src="${photo.url}" alt="${esc(photo.name)}" class="vocci-photo"><small>${photo.read?'✓ Gelesen':esc(photo.name)}</small><button type="button" data-vocci="remove-photo" data-id="${photo.id}" aria-label="Foto entfernen" ${busy?'disabled':''}>×</button></div>`).join('')}<div><button type="button" class="secondary-button" data-vocci="choose-photo" ${busy?'disabled':''}>${sourcePhotos.length?'Weitere Fotos':'Fotos auswählen'}</button> <button type="button" class="primary-button" data-vocci="extract" ${!sourcePhotos.some(p=>!p.read)||busy?'disabled':''}>Alle ungelesenen Fotos auslesen</button><p class="vocci-muted">${sourcePhotos.length?sourcePhotos.length+' / 8 Fotos · werden nacheinander in dasselbe Lernset übernommen.':'Bis zu 8 Fotos auswählen. Jedes Foto sollte beide Spalten zeigen.'}</p></div></div><div id="vocci-import-status" role="status">${busy?'Atlas liest die Wortpaare …':''}</div><button type="button" class="secondary-button ${busy?'':'hidden'}" data-vocci="cancel-import">Einlesen abbrechen</button><div class="vocci-table-head"><span>Vorderseite</span><span>Übersetzung</span><span></span></div><div id="vocci-rows">${draft.items.map((item,index)=>`<div class="vocci-word-row ${item.uncertain?'uncertain':''}"><input aria-label="Wort ${index+1}" data-row="${index}" data-field="front" maxlength="300" value="${esc(item.front)}"><input aria-label="Übersetzung ${index+1}" data-row="${index}" data-field="back" maxlength="300" value="${esc(item.back)}"><button type="button" data-vocci="remove-row" data-index="${index}" aria-label="Wortpaar entfernen">×</button>${item.uncertain?'<small>Bitte prüfen</small>':''}</div>`).join('')}</div><div class="vocci-actions"><button type="button" class="secondary-button" data-vocci="add-row">＋ Wortpaar</button><button type="button" class="primary-button" data-vocci="save">Speichern & lernen</button></div><details><summary>Mehrere Wörter als Text einfügen</summary><p class="vocci-muted">Ein Paar pro Zeile, getrennt mit Tabulator, Semikolon oder =.</p><textarea id="vocci-bulk" rows="4" placeholder="bonjour = guten Tag&#10;merci = danke"></textarea><button type="button" class="secondary-button" data-vocci="bulk">Wörter übernehmen</button></details></section>`;
    if(busy)stage.querySelectorAll('input,textarea').forEach(input=>input.disabled=true);
  }
  function rememberFields(){if(!draft)return;for(const [id,key]of [['vocci-title','title'],['vocci-source','sourceLanguage'],['vocci-target','targetLanguage']]){const input=panel.querySelector('#'+id);if(input)draft[key]=input.value;}}
  function saveDraft(){
    rememberFields();
    const nonempty=draft.items.filter(item=>item.front.trim()||item.back.trim());
    if(!nonempty.length){toast('Füge zuerst mindestens ein Wortpaar hinzu.',{error:true});return;}
    if(nonempty.some(item=>!item.front.trim()||!item.back.trim())){toast('Bitte ergänze die fehlenden Wörter oder Übersetzungen.',{error:true});return;}
    const previous=decks.slice(),old=decks.find(item=>item.id===draft.id),seen=new Set();
    const next={id:draft.id,title:draft.title.trim()||'Meine Vokabeln',sourceLanguage:draft.sourceLanguage.trim(),targetLanguage:draft.targetLanguage.trim(),lastTest:old?.lastTest,practiceDirections:old?.practiceDirections||{},cards:nonempty.flatMap(item=>{const key=normal(item.front)+'\0'+normal(item.back);if(seen.has(key))return [];seen.add(key);const existing=old?.cards.find(card=>card.front===item.front.trim()&&card.back===item.back.trim());return [{id:existing?.id||uid(),front:item.front.trim(),back:item.back.trim(),level:existing?.level||0,due:existing?.due||0,study:existing?.study||{}}];})};
    if(old)decks=decks.map(item=>item.id===next.id?next:item);else decks.unshift(next);
    if(!persist()){decks=previous;return;}
    selected=next.id;draft=null;sourceImage=null;sourcePhotos=[];sourceName='';sound('complete');toast('Lernset gespeichert. Bereit für die erste Runde?');render();
  }
  async function choosePhoto(file){
    if(!file||busy)return;if(sourcePhotos.length>=8){toast('Maximal 8 Fotos pro Durchgang.',{error:true});return;}
    if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>15*1024*1024){toast('Bitte PNG, JPG oder WebP unter 15 MB verwenden.',{error:true});return;}
    if(!draft)newDraft();rememberFields();const targetDraft=draft;
    let bitmap;
    try{
      bitmap=await createImageBitmap(file,{imageOrientation:'from-image'});if(draft!==targetDraft)return;
      if(bitmap.width*bitmap.height>40000000)throw new Error('Bitte verkleinere dieses Foto.');
      const scale=Math.min(1,2048/Math.max(bitmap.width,bitmap.height));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));
      const context=canvas.getContext('2d');context.fillStyle='white';context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(bitmap,0,0,canvas.width,canvas.height);const url=canvas.toDataURL('image/jpeg',.88);
      if(url.length>2800000)throw new Error('Bitte einen kleineren Bildausschnitt verwenden.');
      sourcePhotos.push({id:uid(),url,name:file.name,read:false});sourceImage=sourcePhotos[0].url;sourceName=file.name;if(draft.title==='Meine Vokabeln')draft.title=file.name.replace(/\.[^.]+$/,'').slice(0,80);render();
    }catch(error){toast(error.message||'Foto konnte nicht geöffnet werden.',{error:true});}finally{bitmap?.close();}
  }
  async function extract(){
    if(busy||choosingPhotos||!sourcePhotos.some(p=>!p.read))return;
    if(!desktop?.extractVocabulary){toast('Foto-Erkennung benötigt die aktuelle Atlas-App oder verbundene Webseite.',{error:true});return;}
    rememberFields();busy=true;cancelRequested=false;const batch=sourcePhotos.filter(p=>!p.read),started=Date.now();let index=0,total=0;const errors=[];editor();
    const progress=()=>{const status=panel.querySelector('#vocci-import-status');if(status)status.textContent=`Foto ${Math.min(index+1,batch.length)} von ${batch.length} · ${total} neue Wortpaare · ${Math.floor((Date.now()-started)/1000)} s`};
    readTimer=setInterval(progress,1000);
    try{
      for(index=0;index<batch.length;index++){
        if(cancelRequested)break;const photo=batch[index];job=uid();progress();
        try{
          const result=await desktop.extractVocabulary({requestId:job,image:{mimeType:'image/jpeg',data:photo.url.split(',')[1]},sourceLanguage:draft.sourceLanguage,targetLanguage:draft.targetLanguage});
          if(cancelRequested)break;
          const seen=new Set(draft.items.map(item=>normal(item.front)+'\0'+normal(item.back)));
          const fresh=result.items.filter(item=>{const key=normal(item.front)+'\0'+normal(item.back);if(seen.has(key))return false;seen.add(key);return true;});
          if(draft.items.filter(item=>item.front.trim()||item.back.trim()).length+fresh.length>200){errors.push(photo.name+': Das Lernset würde mehr als 200 Wortpaare enthalten.');break;}
          draft.items.push(...fresh);total+=fresh.length;photo.read=true;
        }catch(error){if(cancelRequested)break;errors.push(photo.name+': '+(error.message||'Foto konnte nicht gelesen werden.'));}
        finally{job=null;}
      }
      if(total)sound('complete');
      toast(`${total} neue Wortpaare übernommen.${cancelRequested?' Einlesen gestoppt.':''} Bitte vor dem Speichern prüfen.`);
      if(errors.length)toast(errors.join('\n'),{error:true});
    }finally{clearInterval(readTimer);readTimer=null;busy=false;job=null;if(draft&&mode==='overview')render();}
  }
  const reversedFor=activity=>current()?.practiceDirections?.[activity]==='back';
  function directionControl(){if(mode==='memory'||mode==='progress')return '';return `<label class="vocci-direction">Lernrichtung<select id="vocci-direction"><option value="front" ${!reversedFor(mode)?'selected':''}>Vorderseite → Rückseite</option><option value="back" ${reversedFor(mode)?'selected':''}>Rückseite → Vorderseite</option></select></label>`;}
  function commonHeader(title,description){return `<div class="vocci-set-header"><div><p class="eyebrow">${esc(current().title)}</p><h2>${title}</h2><p>${description}</p></div><button type="button" class="secondary-button" data-vocci="mode" data-mode="overview">Zur Übersicht</button></div>`+directionControl();}
  function record(card,reversed=reversedFor(mode)){
    const entry=card.study?.[reversed?'back':'front'];
    // Legacy progress belonged to the old front-to-back trainer only.
    return entry||{level:reversed?0:(Number(card.level)||0),due:reversed?0:(Number(card.due)||0),correct:0,wrong:0,lastAt:0,lastSuccess:0};
  }
  function weightedOrder(list){return list.map(card=>{const r=record(card),overdue=r.due&&r.due<Date.now()?Math.min(4,(Date.now()-r.due)/86400000):0;return {card,rank:-Math.log(Math.max(Number.EPSILON,Math.random()))/(1+5-Math.min(5,Math.max(0,r.level))+Math.min(5,r.wrong||0)+overdue)};}).sort((a,b)=>a.rank-b.rank).map(item=>item.card);}
  function dailyCards(reversed,limit=10){
    const available=cards(),due=available.filter(c=>record(c,reversed).lastAt&&record(c,reversed).due<=Date.now()),fresh=available.filter(c=>!record(c,reversed).lastAt);
    const review=weightedOrder(due).slice(0,limit),newWords=shuffle(fresh).slice(0,Math.min(limit-review.length,due.length?3:limit));
    return [...review,...newWords].length?[...review,...newWords]:weightedOrder(available).slice(0,limit);
  }
  function updateProgress(card,known){
    const reversed=session?.reversed??reversedFor(mode),side=reversed?'back':'front',previous=record(card,reversed),now=Date.now();
    const r={...previous,correct:Math.max(0,Number(previous.correct)||0),wrong:Math.max(0,Number(previous.wrong)||0)};
    if(known){r.correct++;if(now-(r.lastSuccess||0)>600000)r.level=Math.min(5,Math.max(0,Number(r.level)||0)+1);r.lastSuccess=now;r.due=Math.max(r.due||0,now+[1,3,7,14,30][Math.max(0,r.level-1)]*86400000);}
    else{r.wrong++;r.level=0;r.due=now+600000;r.lastSuccess=0;}
    r.lastAt=now;r.lastCorrect=known;card.study={...(card.study||{}),[side]:r};
    if(!reversed){card.level=r.level;card.due=r.due;}
  }
  function flashcards(){
    session ||= {type:'cards',order:weightedOrder(cards()),index:0,flipped:false,reversed:reversedFor('cards'),reviewed:0,attempts:{}};
    if(session.finished){stage.innerHTML=commonHeader('Kartenrunde geschafft','Dein Fortschritt ist gespeichert.')+`<div class="vocci-result"><h2>${session.reviewed} Karten bewertet</h2><p>Unsichere Wörter hast du bis zu dreimal gesehen. Du kannst eine Pause machen oder eine neue Runde starten.</p><button type="button" class="primary-button" data-vocci="restart">Neue Runde</button><button type="button" class="secondary-button" data-vocci="mode" data-mode="progress">Fortschritt ansehen</button></div>`;return;}
    const card=session.order[session.index];if(!card)return;
    stage.innerHTML=commonHeader('Karteikarten','Nach links wischen: nicht gewusst. Nach rechts: gewusst. Tippen dreht die Karte um.')+`<div class="vocci-practice-toolbar"><span>${session.order.length-session.index} Karten in der Runde · ${session.reviewed||0} bewertet</span><button type="button" data-vocci="shuffle" class="secondary-button">Mischen ⤨</button></div><button type="button" class="vocci-flash ${session.flipped?'flipped':''}" data-vocci="flip"><span>${session.flipped?'ANTWORT':'WORT'}</span><strong>${esc(session.flipped?(session.reversed?card.front:card.back):(session.reversed?card.back:card.front))}</strong><small>← Nicht gewusst · Tippen zum Umdrehen · Gewusst →</small></button><div class="vocci-actions vocci-centered"><button type="button" class="secondary-button" data-vocci="card-again">← Nicht gewusst</button><button type="button" class="primary-button" data-vocci="card-known">Gewusst →</button></div><p class="vocci-muted">Unsichere Karten kommen nach einigen anderen Karten erneut. Sichere Karten erhalten längere Wiederholungsabstände.</p>`;
  }
  function rateCard(known){
    if(session?.type!=='cards'||session.flipping||session.finished)return;
    const card=session.order[session.index];if(!card)return;
    updateProgress(card,known);persist();
    const remaining=session.order.slice(session.index+1);
    session.attempts||={};session.attempts[card.id]=(session.attempts[card.id]||0)+1;
    if(!known&&session.attempts[card.id]<3)remaining.splice(Math.min(2,remaining.length),0,cards().find(item=>item.id===card.id)||card);
    session.finished=!remaining.length;session.order=remaining;session.index=0;session.reviewed=(session.reviewed||0)+1;session.flipped=false;
    flashcards();library();sound(known?'correct':'again');enter(known?1:-1);
  }
  function learn(){
    if(!session){session={type:'learn',order:dailyCards(reversedFor('learn')),index:0,reversed:reversedFor('learn'),revealed:false,known:0,retry:[],round:0};}
    const card=session.order[session.index];
    if(!card){stage.innerHTML=commonHeader('Runde geschafft!','Kleine Wiederholungen machen den Unterschied.')+`<div class="vocci-result"><span>✦</span><h2>${session.known} sicher gewusst</h2><p>${session.retry.length} Wörter kannst du direkt nochmals üben. Gewusste Karten werden für einen späteren Tag vorgemerkt.</p><div class="vocci-actions vocci-centered">${session.retry.length?'<button type="button" class="primary-button" data-vocci="retry-learn">Schwierige Wörter wiederholen</button>':''}<button type="button" class="secondary-button" data-vocci="restart">Neue Runde</button></div></div>`;return;}
    stage.innerHTML=commonHeader('Gezielt lernen','Kurze Runde: fällige Wiederholungen und wenige neue Wörter. Sind keine fällig, übst du freiwillig weiter.')+`<div class="vocci-progress"><span style="width:${session.index/session.order.length*100}%"></span></div><p class="vocci-muted">${session.index+1} / ${session.order.length}</p><div class="vocci-learning-word"><span>WAS HEISST …</span><h2>${esc(session.reversed?card.back:card.front)}</h2>${session.revealed?`<div class="vocci-answer">${esc(session.reversed?card.front:card.back)}</div>`:'<p>Erinnere dich zuerst selbst an die Übersetzung.</p>'}</div><div class="vocci-actions vocci-centered">${session.revealed?'<button type="button" class="secondary-button" data-vocci="rate-again">Noch unsicher</button><button type="button" class="primary-button" data-vocci="rate-known">Gewusst ✓</button>':'<button type="button" class="primary-button" data-vocci="reveal">Antwort zeigen</button>'}</div>`;
  }
  function rate(known){
    if(!session?.revealed)return;const card=session.order[session.index];
    updateProgress(card,known);if(known)session.known++;else session.retry.push(card);
    persist();session.index++;session.revealed=false;library();learn();enter();
    if(session.index===session.order.length){sound('finish');celebrate();}else sound(known?'correct':'again');
  }
  const memoryOverlay=document.createElement('dialog');memoryOverlay.className='vocci-memory-overlay';memoryOverlay.setAttribute('aria-label','Memory Vollbild');document.body.append(memoryOverlay);
  let memoryHome=null,memoryNative=false,memoryOpening=false;
  memoryOverlay.addEventListener('click',handleVocciClick);
  memoryOverlay.addEventListener('cancel',event=>{event.preventDefault();leaveMemoryFullscreen();});
  async function enterMemoryFullscreen(){
    if(!['memory','memory-split'].includes(session?.type)||memoryHome)return;
    memoryHome=document.createComment('Memory position');stage.before(memoryHome);memoryOverlay.append(stage);
    stage.classList.add('vocci-memory-fullscreen');memoryOverlay.showModal();
    stage.querySelector('.vocci-memory-exit')?.focus({preventScroll:true});
    memoryOpening=true;
    try{if(memoryOverlay.requestFullscreen){await memoryOverlay.requestFullscreen();memoryNative=document.fullscreenElement===memoryOverlay;}}
    catch{/* The modal already fills the app when native fullscreen is unavailable. */}
    finally{memoryOpening=false;if(!memoryHome&&document.fullscreenElement===memoryOverlay)document.exitFullscreen().catch(()=>{});}
  }
  function leaveMemoryFullscreen(){
    if(!memoryHome)return;
    const native=document.fullscreenElement===memoryOverlay;
    memoryHome.replaceWith(stage);memoryHome=null;memoryNative=false;stage.classList.remove('vocci-memory-fullscreen');memoryOverlay.close();
    if(native)document.exitFullscreen().catch(()=>{});
    stage.querySelector('[data-vocci="memory-fullscreen"]')?.focus({preventScroll:true});
  }
  document.addEventListener('fullscreenchange',()=>{if(memoryNative&&!memoryOpening&&document.fullscreenElement!==memoryOverlay)leaveMemoryFullscreen();});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&memoryHome){event.preventDefault();leaveMemoryFullscreen();}});
  function memory(){
    if(session?.type==='memory-split'){if(stage.querySelector('.memory-split-shell'))return;session=null;}
    if(!session){
      leaveMemoryFullscreen();
      const unique=cards().filter((card,index,list)=>list.findIndex(other=>normal(other.front)===normal(card.front)||normal(other.back)===normal(card.back))===index);
      if(unique.length<2){stage.innerHTML=commonHeader('Memory','Mindestens zwei unterschiedliche Wortpaare benötigt.')+'<p class="vocci-muted">Ergänze dein Lernset mit weiteren Wörtern.</p>';return;}
      if(!memorySize){const sizes=[4,8,12,16,24,32,unique.length].filter((n,i,list)=>n<=unique.length&&list.indexOf(n)===i).sort((a,b)=>a-b);stage.innerHTML=commonHeader('Memory','Wähle die Grösse deiner Runde. Doppelte Wörter werden für eindeutige Paare ausgelassen.')+`<div class="vocci-test-setup"><label>Wie viele Paare?<select id="vocci-memory-count">${sizes.map(n=>`<option value="${n}" ${n===Math.min(8,unique.length)?'selected':''}>${n} Paare${n===unique.length?' (alle)':''}</option>`).join('')}</select></label><button type="button" class="primary-button" data-vocci="start-memory">Memory starten</button><button type="button" class="secondary-button" data-vocci="memory-split">Zu zweit · Splitscreen</button></div>`;return;}
      const pairs=shuffle(unique).slice(0,memorySize),first=reversedFor('memory')?'back':'front',second=first==='front'?'back':'front';session={type:'memory',first,tiles:shuffle(pairs.flatMap(card=>[{pair:card.id,text:card[first],side:first},{pair:card.id,text:card[second],side:second}])),open:[],matched:[],attempts:0,locked:false};
    }
    const won=session.matched.length===session.tiles.length/2;
    stage.innerHTML=commonHeader('Memory','Decke ein Wort und seine passende Übersetzung auf.')+`<div class="vocci-practice-toolbar"><span>${session.matched.length} / ${session.tiles.length/2} Paare</span><span>${session.attempts} Versuche</span><button type="button" class="secondary-button" data-vocci="memory-fullscreen">⛶ Spielfeld Vollbild</button></div><button type="button" class="vocci-memory-exit" data-vocci="memory-exit" aria-label="Vollbild verlassen" title="Vollbild verlassen (Esc)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M3 3l7 7M10 4v6H4M21 21l-7-7M14 20v-6h6"/></svg></button><div class="vocci-memory">${session.tiles.map((tile,index)=>{const match=session.matched.includes(tile.pair),open=session.open.includes(index);return `<button type="button" data-vocci="tile" data-index="${index}" class="${match?'matched':open?'open':''}" ${match||session.locked||open?'disabled':''} aria-label="${match||open?esc(tile.text):'Verdeckte Karte '+(index+1)}">${match||open?esc(tile.text):'<span>✧</span>'}</button>`;}).join('')}</div>${won?'<div class="vocci-result"><h2>Alle Paare gefunden! ✦</h2><button type="button" class="primary-button" data-vocci="restart">Noch eine Runde</button></div>':''}`;
  }
  function tile(index){
    if(!session||session.type!=='memory'||session.locked||session.open.includes(index)||session.matched.includes(session.tiles[index]?.pair))return;
    session.open.push(index);const chosen=[...session.open];let matched=false,missed=false;
    if(session.open.length===2){session.attempts++;const [a,b]=session.open.map(i=>session.tiles[i]);
      if(a.pair===b.pair&&a.side!==b.side){session.matched.push(a.pair);session.open=[];matched=true;}
      else{missed=true;session.locked=true;const captured=session;memoryTimer=setTimeout(()=>{if(session!==captured)return;session.open=[];session.locked=false;memory();},1000);}}
    memory();
    const complete=matched&&session.matched.length===session.tiles.length/2;
    sound(complete?'finish':matched?'match':missed?'miss':'flip');
    for(const i of chosen)animate(stage.querySelector(`[data-vocci="tile"][data-index="${i}"]`),matched?[{transform:'scale(.94)'},{transform:'scale(1.05)',boxShadow:'0 0 20px #52d6ae44'},{transform:'scale(1)'}]:missed?[{transform:'translateX(0)'},{transform:'translateX(-3px)'},{transform:'translateX(3px)'},{transform:'translateX(0)'}]:[{transform:'perspective(600px) rotateY(-65deg)',opacity:.4},{transform:'perspective(600px) rotateY(0deg)',opacity:1}],{duration:matched?350:220});
    if(complete)celebrate();
  }
  function writing(){
    session ||= {type:'write',order:dailyCards(reversedFor('write')),index:0,reversed:reversedFor('write'),feedback:null,correct:0,attempts:{},hinted:false,retries:0};
    const card=session.order[session.index];
    if(!card){stage.innerHTML=commonHeader('Schreibrunde geschafft','Deine Antworten wurden für diese Lernrichtung gespeichert.')+`<div class="vocci-result"><h2>${session.correct} / ${session.index} ohne Hilfe richtig</h2><p>${session.retries} Wiederholungen schwieriger Wörter waren dabei. Fehler sind dein nächster Lernschritt.</p><button type="button" class="primary-button" data-vocci="restart">Nächste kurze Runde</button></div>`;return;}
    const question=session.reversed?card.back:card.front,answer=session.reversed?card.front:card.back;
    stage.innerHTML=commonHeader('Schreibtrainer','Gross-/Kleinschreibung, Kommas und Satzpunkte sind egal. Wörter, Artikel und Akzente zählen. Mit Hinweis bleibt das Wort unsicher.')+`<div class="vocci-progress"><span style="width:${session.index/session.order.length*100}%"></span></div><p class="vocci-muted">${session.index+1} / ${session.order.length}</p><div class="vocci-learning-word"><span>ÜBERSETZE</span><h2>${esc(question)}</h2></div>${session.feedback?`<div class="vocci-write-feedback ${session.feedback.correct?'correct':'wrong'}"><b>${session.feedback.correct?'Richtig ✓':session.feedback.near?'Fast – prüfe Akzente und Schreibweise.':'Noch einmal anschauen und merken.'}</b><p>Deine Antwort: ${esc(session.feedback.given||'—')}</p><p>Lösung: <strong>${esc(answer)}</strong></p>${session.hinted?'<small>Mit Hilfe geübt – wird wiederholt.</small>':''}</div><button type="button" class="primary-button" data-vocci="write-next">Weiter →</button>`:`<form id="vocci-write-form"><label>Deine Übersetzung<input id="vocci-write-answer" maxlength="600" autocomplete="off" spellcheck="false" placeholder="Schreibe deine Antwort …"></label><div class="vocci-actions"><button type="submit" class="primary-button">Prüfen</button><button type="button" class="secondary-button" data-vocci="write-hint">Hinweis</button><button type="button" class="secondary-button" data-vocci="write-reveal">Weiss ich nicht</button></div><p id="vocci-write-hint" class="vocci-muted" role="status"></p></form>`}`;
    if(!session.feedback){stage.querySelector('#vocci-write-form').onsubmit=event=>{event.preventDefault();checkWriting();};stage.querySelector('#vocci-write-answer').focus();}else stage.querySelector('[data-vocci="write-next"]').focus();
  }
  function checkWriting(reveal=false){
    if(session?.type!=='write'||session.feedback)return;const card=session.order[session.index],answer=session.reversed?card.front:card.back,given=stage.querySelector('#vocci-write-answer').value.trim();
    if(!given&&!reveal){toast('Schreibe eine Antwort oder wähle „Weiss ich nicht“.');return;}
    const correct=!reveal&&accepted(given,answer),known=correct&&!session.hinted;
    const plain=t=>answerKey(t).normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    session.feedback={correct,given,near:!correct&&answer.split(/\s*[;|]\s*/).some(a=>plain(a)===plain(given))};
    session.attempts[card.id]=(session.attempts[card.id]||0)+1;
    if(known)session.correct++;else if(session.attempts[card.id]<2){session.order.splice(Math.min(session.order.length,session.index+3),0,card);session.retries++;}
    updateProgress(card,known);persist();writing();sound(known?'correct':'again');
  }
  function progress(){
    const list=cards(),entries=list.flatMap(card=>[record(card,false),record(card,true)]),reviewed=entries.filter(r=>r.lastAt),correct=entries.reduce((n,r)=>n+(r.correct||0),0),wrong=entries.reduce((n,r)=>n+(r.wrong||0),0),secure=list.filter(c=>record(c,false).level>=3&&record(c,true).level>=3).length;
    const midnight=new Date();midnight.setHours(0,0,0,0);
    stage.innerHTML=commonHeader('Dein Lernfortschritt','Beide Richtungen werden getrennt gelernt. Sicher bedeutet: mindestens Stufe 3 in beiden Richtungen.')+`<div class="vocci-stats"><span><b>${secure} / ${list.length}</b> in beiden Richtungen sicher</span><span><b>${correct+wrong?Math.round(correct/(correct+wrong)*100)+' %':'—'}</b> ohne Hilfe sicher bewertet</span><span><b>${reviewed.filter(r=>r.lastAt>=midnight.getTime()).length}</b> Richtungen heute geübt</span></div><div class="vocci-progress-tools"><input id="vocci-progress-search" placeholder="Wort suchen …" aria-label="Wörter durchsuchen"><select id="vocci-progress-filter" aria-label="Fortschritt filtern"><option value="all">Alle Wörter</option><option value="weak">Zuletzt unsicher</option><option value="due">Fällig oder neu</option><option value="secure">Beide Richtungen sicher</option></select><select id="vocci-weak-direction" aria-label="Richtung für Fehlerwiederholung"><option value="front">Vorder → Rück üben</option><option value="back">Rück → Vorder üben</option></select><button type="button" class="secondary-button" data-vocci="weak-round">Unsichere Wörter üben</button></div><div id="vocci-progress-list"></div><p class="vocci-muted">Die Wiederholung nutzt deine Bewertungen, Fehler und Fälligkeiten. Häufiges Wiederholen direkt hintereinander erhöht die Stufe nicht mehrfach. Ältere Lernstände ohne Verlaufsdaten zählen nicht in die Trefferquote.</p>`;
    const draw=()=>{const query=normal(stage.querySelector('#vocci-progress-search').value),filter=stage.querySelector('#vocci-progress-filter').value;const items=list.filter(c=>{const a=record(c,false),b=record(c,true);return normal(c.front+' '+c.back).includes(query)&&(filter==='all'||filter==='weak'&&(a.lastCorrect===false||b.lastCorrect===false)||filter==='due'&&(!a.due||a.due<=Date.now()||!b.due||b.due<=Date.now())||filter==='secure'&&a.level>=3&&b.level>=3);});stage.querySelector('#vocci-progress-list').innerHTML=items.length?items.map(c=>`<article class="vocci-progress-word"><div><b>${esc(c.front)}</b><p>${esc(c.back)}</p></div><div>${[false,true].map(reverse=>{const r=record(c,reverse),label=reverse?'Rück → Vorder':'Vorder → Rück';return `<span>${label} · Stufe ${r.level}/5 <small>${!r.due?'Neu':r.due<=Date.now()?'Fällig':new Date(r.due).toLocaleDateString('de-CH')}</small></span>`;}).join('')}</div></article>`).join(''):'<p class="vocci-muted">Keine passenden Wörter.</p>';};
    stage.querySelector('#vocci-progress-search').oninput=draw;stage.querySelector('#vocci-progress-filter').onchange=draw;draw();
  }
  function test(){
    if(!session){stage.innerHTML=commonHeader('Dein Vokabeltest','Ohne Vorschau antworten. Am Ende bekommst du die Auflösung.')+`<div class="vocci-test-setup"><label>Wie viele Wörter?<select id="vocci-test-count">${[5,10,20,cards().length].filter((n,i,a)=>n<=cards().length&&a.indexOf(n)===i).sort((a,b)=>a-b).map(n=>`<option value="${n}">${n} Wörter</option>`).join('')}</select></label><button type="button" class="primary-button" data-vocci="start-test">Test starten</button><p class="vocci-muted">Gross-/Kleinschreibung, Kommas und Satzpunkte zählen nicht. Wörter, Akzente und Artikel schon. Alternative Antworten kannst du mit ; oder | trennen.</p></div>`;return;}
    if(session.finished){
      const correct=session.answers.filter(answer=>answer.correct).length;
      stage.innerHTML=commonHeader('Dein Ergebnis',`${correct} von ${session.order.length} richtig · ${Math.round(correct/session.order.length*100)} %`)+`<div class="vocci-result-list">${session.answers.map(answer=>`<div class="${answer.correct?'correct':'wrong'}"><span>${answer.correct?'✓':'↻'}</span><div><b>${esc(answer.question)}</b><p>Deine Antwort: ${esc(answer.given||'—')}</p>${!answer.correct?`<p>Richtig: <strong>${esc(answer.expected)}</strong></p>`:''}</div></div>`).join('')}</div><div class="vocci-actions"><button type="button" class="primary-button" data-vocci="restart">Neuer Test</button><button type="button" class="secondary-button" data-vocci="test-mistakes">Fehler als Karteikarten</button></div>`;return;
    }
    const card=session.order[session.index],question=session.reversed?card.back:card.front;
    stage.innerHTML=commonHeader('Vokabeltest',`Frage ${session.index+1} von ${session.order.length}`)+`<div class="vocci-progress"><span style="width:${session.index/session.order.length*100}%"></span></div><form id="vocci-test-form"><div class="vocci-learning-word"><span>ÜBERSETZE</span><h2>${esc(question)}</h2></div><label>Deine Antwort<input id="vocci-test-answer" autocomplete="off" spellcheck="false" maxlength="600" placeholder="Übersetzung eingeben …"></label><button type="submit" class="primary-button">${session.index===session.order.length-1?'Test abschliessen':'Nächste Frage →'}</button></form>`;
    stage.querySelector('#vocci-test-form').onsubmit=event=>{event.preventDefault();submitAnswer();};stage.querySelector('#vocci-test-answer').focus();
  }
  function submitAnswer(){
    if(!session||session.finished)return;
    const card=session.order[session.index],given=stage.querySelector('#vocci-test-answer').value.trim(),expected=session.reversed?card.front:card.back;
    const correct=accepted(given,expected);updateProgress(card,correct);persist();session.answers.push({cardId:card.id,question:session.reversed?card.back:card.front,given,expected,correct});
    session.index++;if(session.index===session.order.length){session.finished=true;current().lastTest={correct:session.answers.filter(a=>a.correct).length,total:session.order.length,date:Date.now()};persist();sound('finish');}else sound('step');test();enter();
    if(session.finished){animate(stage.querySelector('.vocci-result-list'),[{opacity:0,transform:'translateY(10px)'},{opacity:1,transform:'translateY(0)'}],{duration:350});if(session.answers.every(answer=>answer.correct))celebrate();}
  }
  function downloadDeck(){
    const deck=current();if(!deck)return;const blob=new Blob([JSON.stringify({title:deck.title,sourceLanguage:deck.sourceLanguage,targetLanguage:deck.targetLanguage,cards:deck.cards.map(({front,back})=>({front,back}))},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=deck.title.replace(/[^\p{L}\p{N} _-]/gu,'').slice(0,60)+'.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  panel.addEventListener('input',event=>{const index=Number(event.target.dataset.row),field=event.target.dataset.field;if(draft&&Number.isInteger(index)&&['front','back'].includes(field)&&draft.items[index]){draft.items[index][field]=event.target.value;}});
  async function handleVocciClick(event){
    const button=event.target.closest('[data-vocci]');if(!button||button.disabled)return;
    const action=button.dataset.vocci;
    if(session?.flipping&&['prev','next','reverse','shuffle'].includes(action))return;
    if((busy||choosingPhotos)&&!['cancel-import'].includes(action)){toast('Bitte warte auf das Einlesen oder brich es ab.');return;}
    if(action==='cancel-import'){cancelRequested=true;if(job)await desktop.cancelVocabulary(job);return;}
    if(action==='remove-photo'){rememberFields();sourcePhotos=sourcePhotos.filter(p=>p.id!==button.dataset.id);sourceImage=sourcePhotos[0]?.url||null;render();return;}
    if(action==='select'){selected=button.dataset.id;draft=null;sourceImage=null;sourcePhotos=[];setMode('overview');}
    if(action==='new'||action==='manual'){newDraft();draft.items=[{front:'',back:'',uncertain:false}];render();}
    if(action==='photo'){newDraft();render();panel.querySelector('#vocci-file').click();}
    if(action==='choose-photo'){rememberFields();panel.querySelector('#vocci-file').click();}
    if(action==='extract')await extract();
    if(action==='mode')setMode(button.dataset.mode);
    if(action==='edit'){const deck=current();draft={...deck,items:deck.cards.map(card=>({front:card.front,back:card.back,uncertain:false}))};mode='overview';sourceImage=null;sourcePhotos=[];render();}
    if(action==='cancel-edit'){draft=null;sourceImage=null;sourcePhotos=[];render();}
    if(action==='add-row'){rememberFields();if(draft.items.length>=200){toast('Pro Lernset sind bis zu 200 Wörter möglich.');return;}draft.items.push({front:'',back:'',uncertain:false});editor();stage.querySelector('#vocci-rows .vocci-word-row:last-child input')?.focus();}
    if(action==='remove-row'){rememberFields();draft.items.splice(Number(button.dataset.index),1);editor();}
    if(action==='save')saveDraft();
    if(action==='bulk'){rememberFields();const text=stage.querySelector('#vocci-bulk').value;const pairs=text.split(/\r?\n/).filter(line=>line.trim()).map(line=>line.split(/\t|\s*=\s*|;/));if(!pairs.length||pairs.some(parts=>parts.length<2)){toast('Bitte ein Wortpaar je Zeile eingeben, z. B. bonjour = guten Tag.',{error:true});return;}draft.items=draft.items.filter(item=>item.front.trim()||item.back.trim());draft.items.push(...pairs.map(parts=>({front:parts[0].trim().slice(0,300),back:parts.slice(1).join('; ').trim().slice(0,300),uncertain:false})));draft.items=draft.items.slice(0,200);editor();}
    if(action==='export')downloadDeck();
    if(action==='import-set'){if(draft&&!confirm('Ungespeicherte Bearbeitung verwerfen und ein Set importieren?'))return;setFile.click();}
    if(action==='copy-set'){const original=current();if(!original)return;const previous=decks.slice(),copy={id:uid(),title:(original.title+' (Kopie)').slice(0,80),sourceLanguage:original.sourceLanguage,targetLanguage:original.targetLanguage,cards:original.cards.map(c=>({id:uid(),front:c.front,back:c.back,level:0,due:0}))};decks.unshift(copy);if(!persist()){decks=previous;return;}selected=copy.id;session=null;render();toast('Eigene Kopie erstellt – Lernfortschritt startet neu.');}
    if(action==='delete'){const previous=decks.slice(),removed=current();decks=decks.filter(deck=>deck.id!==selected);if(!persist()){decks=previous;return;}selected=decks[0]?.id||null;session=null;render();toast('Lernset gelöscht.',{undo:()=>{decks=previous;selected=removed.id;persist();render();}});}
    if(action==='flip'&&Date.now()>=suppressFlipUntil)await flipCard();
    if(action==='card-known'||action==='card-again')rateCard(action==='card-known');
    if(action==='prev'||action==='next'){session.index=(session.index+(action==='next'?1:-1)+session.order.length)%session.order.length;session.flipped=false;session.flipping=false;flashcards();sound('step');enter(action==='next'?1:-1);}
    if(action==='reverse'){session.reversed=!session.reversed;session.flipped=false;flashcards();sound('flip');enter();}
    if(action==='shuffle'){session.order=shuffle(session.order);session.index=0;session.flipped=false;flashcards();sound('step');enter();}
    if(action==='reveal'){session.revealed=true;learn();sound('reveal');animate(stage.querySelector('.vocci-answer'),[{opacity:0,transform:'translateY(8px)'},{opacity:1,transform:'translateY(0)'}]);}
    if(action==='rate-known'||action==='rate-again')rate(action==='rate-known');
    if(action==='retry-learn'){session={...session,order:shuffle(session.retry),retry:[],index:0,known:0,revealed:false};learn();}
    if(action==='write-hint'){const card=session.order[session.index],answer=(session.reversed?card.front:card.back).split(/[;|]/)[0].trim();session.hinted=true;stage.querySelector('#vocci-write-hint').textContent='Anfang: '+[...answer].slice(0,2).join('')+'… · '+[...answer].length+' Zeichen';stage.querySelector('#vocci-write-answer').focus();}
    if(action==='write-reveal')checkWriting(true);
    if(action==='write-next'){session.index++;session.feedback=null;session.hinted=false;writing();enter();if(session.index>=session.order.length){sound('finish');celebrate();}}
    if(action==='weak-round'){const reversed=stage.querySelector('#vocci-weak-direction').value==='back',weak=cards().filter(c=>record(c,reversed).lastCorrect===false);if(!weak.length){toast('In dieser Richtung gibt es keine zuletzt unsicheren Wörter.');return;}current().practiceDirections={...(current().practiceDirections||{}),learn:reversed?'back':'front'};persist();setMode('learn');session={type:'learn',order:weightedOrder(weak).slice(0,10),index:0,reversed,revealed:false,known:0,retry:[]};learn();}
    if(action==='tile')tile(Number(button.dataset.index));
    if(action==='memory-split'){session={type:'memory-split'};window.AtlasMemorySplit.start(stage,cards(),()=>memoryHome?leaveMemoryFullscreen():enterMemoryFullscreen(),()=>{leaveMemoryFullscreen();session=null;memorySize=0;memory();});return;}
    if(action==='memory-fullscreen'){await enterMemoryFullscreen();return;}
    if(action==='memory-exit'){leaveMemoryFullscreen();return;}
    if(action==='start-memory'){memorySize=Number(stage.querySelector('#vocci-memory-count').value);session=null;memory();}
    if(action==='restart'){session=null;memorySize=0;render();}
    if(action==='start-test'){const count=Number(stage.querySelector('#vocci-test-count').value);session={type:'test',order:shuffle(cards()).slice(0,count),index:0,reversed:reversedFor('test'),answers:[],finished:false};test();}
    if(action==='test-mistakes'){const ids=new Set(session.answers.filter(answer=>!answer.correct).map(answer=>answer.cardId));if(!ids.size){toast('Keine Fehler – alle Wörter richtig!');return;}session={type:'cards',order:cards().filter(card=>ids.has(card.id)),index:0,flipped:false,reversed:reversedFor('cards'),reviewed:0};mode='cards';render();}
  }
  panel.addEventListener('click',handleVocciClick);
  async function choosePhotos(files){
    if(choosingPhotos||busy)return;choosingPhotos=true;let target=draft;
    try{for(const file of [...files]){if(target&&draft!==target)break;if(sourcePhotos.length>=8){toast('Maximal 8 Fotos. Weitere Bilder bitte in einem weiteren Lernset verwenden.');break;}await choosePhoto(file);target=draft;}}
    finally{choosingPhotos=false;}
  }
  panel.querySelector('#vocci-file').onchange=async event=>{try{await choosePhotos(event.target.files);}finally{event.target.value='';}};
  panel.addEventListener('dragover',event=>{if(!panel.querySelector('.vocci-shell').classList.contains('hidden')&&event.dataTransfer?.types.includes('Files'))event.preventDefault();});
  panel.addEventListener('drop',event=>{if(panel.querySelector('.vocci-shell').classList.contains('hidden'))return;if(event.dataTransfer?.files?.length){event.preventDefault();choosePhotos(event.dataTransfer.files);}});
  panel.addEventListener('paste',event=>{if(panel.querySelector('.vocci-shell').classList.contains('hidden')||event.target.matches('input,textarea'))return;const files=[...(event.clipboardData?.items||[])].filter(item=>item.type.startsWith('image/')).map(item=>item.getAsFile()).filter(Boolean);if(files.length){event.preventDefault();choosePhotos(files);}});
  document.addEventListener('keydown',event=>{if(panel.classList.contains('hidden')||event.target.matches('input,textarea,select')||mode!=='cards'||!session)return;if(event.key==='ArrowRight'||event.key==='ArrowLeft'){event.preventDefault();if(!event.repeat)rateCard(event.key==='ArrowRight');}});

  panel.addEventListener('change',event=>{
    if(event.target.id!=='vocci-direction'||!current())return;
    if(session?.type==='test'&&!session.finished&&session.index>0&&!confirm('Richtung wechseln und den laufenden Test neu starten?')){event.target.value=session.reversed?'back':'front';return;}
    current().practiceDirections={...(current().practiceDirections||{}),[mode]:event.target.value};persist();session=null;clearTimeout(memoryTimer);memoryTimer=null;render();
  });
  stage.addEventListener('pointerdown',event=>{const card=event.target.closest('.vocci-flash');if(!card||session?.flipping||event.button!==0)return;swipe={id:event.pointerId,x:event.clientX,y:event.clientY,card,session};card.setPointerCapture(event.pointerId);});
  stage.addEventListener('pointermove',event=>{if(!swipe||swipe.id!==event.pointerId)return;const dx=event.clientX-swipe.x,dy=event.clientY-swipe.y;if(Math.abs(dx)>12&&Math.abs(dx)>Math.abs(dy)){swipe.card.style.transform=`translateX(${Math.max(-160,Math.min(160,dx))}px) rotate(${dx/35}deg)`;swipe.card.style.borderColor=dx>0?'#52d6ae':'#ef8995';}});
  function endSwipe(event,cancelled=false){if(!swipe||swipe.id!==event.pointerId)return;const drag=swipe;swipe=null;drag.card.style.transform='';drag.card.style.borderColor='';const dx=event.clientX-drag.x,dy=event.clientY-drag.y;if(!cancelled&&Math.abs(dx)>70&&Math.abs(dx)>Math.abs(dy)*1.3&&session===drag.session){suppressFlipUntil=Date.now()+500;rateCard(dx>0);}}
  stage.addEventListener('pointerup',event=>endSwipe(event));stage.addEventListener('pointercancel',event=>endSwipe(event,true));
  const setFile=document.createElement('input');setFile.type='file';setFile.accept='.json,.csv,.tsv,.txt';setFile.hidden=true;panel.append(setFile);
  function parsePairs(text){
    const first=text.split(/\r?\n/).find(line=>line.trim())||'';const delimiter=first.includes('\t')?'\t':first.includes(';')?';':first.includes('=')?'=':',';
    const rows=[];let row=[],cell='',quoted=false;
    for(let i=0;i<text.length;i++){const ch=text[i];if(ch==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;}else if(!quoted&&(ch===delimiter||ch==='\n')){row.push(cell.trim());cell='';if(ch==='\n'){if(row.some(Boolean))rows.push(row);row=[];}}else if(ch!=='\r')cell+=ch;}
    if(quoted)throw new Error('Ein Anführungszeichen in der Datei ist nicht geschlossen.');row.push(cell.trim());if(row.some(Boolean))rows.push(row);
    if(rows.length&&/^(front|vorderseite|wort)$/i.test(rows[0][0])&&/^(back|rückseite|übersetzung)$/i.test(rows[0][1]))rows.shift();
    if(rows.some(row=>row.length!==2))throw new Error('Bitte genau zwei Spalten verwenden: Wort und Übersetzung.');return rows.map(([front,back])=>({front,back}));
  }
  setFile.onchange=async()=>{
    const file=setFile.files[0];if(!file)return;if(busy||choosingPhotos){setFile.value='';return;}choosingPhotos=true;
    const account=document.querySelector('meta[name="atlas-account-id"]')?.content||document.querySelector('#account-current-email')?.textContent||'guest';
    try{if(file.size>2*1024*1024)throw new Error('Die Set-Datei darf höchstens 2 MB gross sein.');const text=(await file.text()).replace(/^\uFEFF/,'');let data;
      if(file.name.toLowerCase().endsWith('.json'))data=JSON.parse(text);else data={title:file.name.replace(/\.[^.]+$/,''),cards:parsePairs(text)};
      const entries=Array.isArray(data)?data:data?.cards;if(!Array.isArray(entries)||!entries.length||entries.length>200)throw new Error('Die Datei muss 1 bis 200 Wortpaare enthalten.');
      if(entries.some(c=>!c||typeof c.front!=='string'||typeof c.back!=='string'||!c.front.trim()||!c.back.trim()||c.front.length>300||c.back.length>300))throw new Error('Jedes Wortpaar braucht Vorder- und Rückseite mit höchstens 300 Zeichen.');
      if(account!==(document.querySelector('meta[name="atlas-account-id"]')?.content||document.querySelector('#account-current-email')?.textContent||'guest'))throw new Error('Das Konto wurde gewechselt. Bitte erneut importieren.');
      choosingPhotos=false;newDraft();draft.title=String(data.title||file.name.replace(/\.[^.]+$/,'')).slice(0,80);draft.sourceLanguage=String(data.sourceLanguage||'').slice(0,60);draft.targetLanguage=String(data.targetLanguage||'').slice(0,60);draft.items=entries.map(c=>({front:c.front.trim(),back:c.back.trim(),uncertain:false}));render();toast('Import bereit. Prüfe die Wortpaare und klicke auf Speichern.');
    }catch(error){toast('Import fehlgeschlagen: '+error.message,{error:true});}finally{choosingPhotos=false;setFile.value='';}
  };
  window.AtlasVocciImport=(title,items)=>{if(busy||choosingPhotos){toast('Bitte zuerst den laufenden Import beenden.');return;}newDraft();draft.title=String(title).slice(0,80);draft.items=items.slice(0,200).map(item=>({front:String(item.front).slice(0,300),back:String(item.back).slice(0,300),uncertain:false}));showView('learn');render();toast('Prüfe die Wortpaare und speichere dein Fehler-Lernset.');};
  library();
})();
