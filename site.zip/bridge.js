/* Browser adapter: only the explicitly exposed web API is accessible. */
(() => {
  const jobs=new Map(),statusListeners=new Set();
  let speechRequest=null;
  let accountUserId=document.querySelector('meta[name="atlas-account-id"]')?.content||'guest';
  function setAccountScope(next){
    const marker='atlas.web.active-account.v1',keys=['jarvis.chats.v1','jarvis.calendar.v1','atlas.ui.preferences.v1','atlas.gradebook.v1','atlas-vocci-v1','atlas.web.speech.v1'];
    const previous=localStorage.getItem(marker)||'guest';if(previous===next){localStorage.setItem(marker,next);return;}
    const snapshot=Object.fromEntries(keys.map(key=>[key,localStorage.getItem(key)]));
    localStorage.setItem('atlas.web.account-cache.'+previous,JSON.stringify(snapshot));
    const saved=JSON.parse(localStorage.getItem('atlas.web.account-cache.'+next)||'{}');
    for(const key of keys){if(typeof saved[key]==='string')localStorage.setItem(key,saved[key]);else localStorage.removeItem(key);}
    localStorage.setItem(marker,next);
  }
  try{setAccountScope(accountUserId);}catch{throw new Error('Kontodaten konnten nicht sicher getrennt werden. Bitte prüfe den Browserspeicher.');}
  const unavailable=async()=>{throw new Error('Diese Funktion ist nur direkt in der Atlas-Windows-App verfügbar.');};
  async function request(route,payload,signal){
    const response=await fetch(route,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-Atlas-Client':'atlas-web'},body:JSON.stringify(payload),signal});
    if(response.status===401){location.replace('/');throw new Error('Bitte erneut mit deinem Zugangscode anmelden.');}
    const data=await response.json();if(!response.ok)throw new Error(data.error||'Die Anfrage konnte nicht verarbeitet werden.');return data;
  }
  // Keep text conversations from the first web release; never overwrite existing data.
  try{
    if(accountUserId==='guest'&&!localStorage.getItem('jarvis.chats.v1')){
      const saved=JSON.parse(localStorage.getItem('atlas-web-chats-v1')||'[]');
      if(Array.isArray(saved)&&saved.length)localStorage.setItem('jarvis.chats.v1',JSON.stringify(saved.map(chat=>({...chat,messages:chat.messages.map(item=>({...item,...(item.imageRef?{attachments:[{id:item.imageRef,name:'Bild aus bisherigem Webchat',mimeType:'image/jpeg'}]}:{})}))}))));
    }
    const prefs=JSON.parse(localStorage.getItem('atlas.ui.preferences.v1')||'{}');prefs.autoVoice=false;localStorage.setItem('atlas.ui.preferences.v1',JSON.stringify(prefs));
  }catch{}
  window.atlasWebImageMigration=(async()=>{
    const open=(name,create)=>new Promise((resolve,reject)=>{const req=indexedDB.open(name,1);req.onupgradeneeded=()=>{if(create&&!req.result.objectStoreNames.contains('images'))req.result.createObjectStore('images',{keyPath:'id'});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
    const old=await open('atlas-web-images',false);if(!old.objectStoreNames.contains('images')){old.close();return;}
    const images=await new Promise((resolve,reject)=>{const req=old.transaction('images').objectStore('images').getAll();req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});old.close();
    if(!images.length)return;const next=await open('atlas-image-attachments',true);
    await new Promise((resolve,reject)=>{const tx=next.transaction('images','readwrite');for(const image of images)if(image?.id&&image?.url){const store=tx.objectStore('images');const check=store.get(image.id);check.onsuccess=()=>{if(!check.result)store.put({...image,mimeType:'image/jpeg'});};}tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});next.close();
  })().catch(()=>{});
  window.samuelDesktop={
    serverOnly:true,
    socialInvite:(input,expectedUserId)=>request('/api/social-invite',{input,expectedUserId},AbortSignal.timeout(20000)),
    social:(action,payload,expectedUserId)=>request('/api/social',{action,payload,expectedUserId},AbortSignal.timeout(20000)),
    games:(action,payload)=>request('/api/games',{action,payload},AbortSignal.timeout(15000)),
    multiplayer:(action,payload)=>request('/api/vocci-multiplayer',{action,payload},AbortSignal.timeout(15000)),
    synthesizeSpeech:async options=>{
      const job={id:crypto.randomUUID(),controller:new AbortController()};speechRequest=job;
      try{return await request('/api/speech/synthesize',{...options,requestId:job.id},job.controller.signal);}finally{if(speechRequest===job)speechRequest=null;}
    },
    cancelSpeech:async()=>{const job=speechRequest;if(!job)return;job.controller.abort();speechRequest=null;try{await request('/api/speech/cancel',{requestId:job.id});}catch{}},
    getSpeechStatus:()=>request('/api/speech/status',{}),
    isWeb:true,launchContext:{startedByWindows:false},
    getAccountStatus:async()=>{const status=await request('/api/account/status',{});const next=status.userId||'guest';if(next!==accountUserId){location.reload();return new Promise(()=>{});}return status;},
    signIn:async(email,password)=>changeAccount('/api/account/sign-in',{email,password}),
    createAccount:async(email,password)=>changeAccount('/api/account/sign-up',{email,password}),
    signOut:async()=>changeAccount('/api/account/sign-out',{}),
    cloudLoad:()=>request('/api/account/load',{expectedUserId:accountUserId}),
    cloudSave:payload=>request('/api/account/save',{expectedUserId:accountUserId,payload}),
    getAISettings:async()=>({provider:'server',serverOnly:true,server:{url:(window.AtlasPagesTransport?.server||location.origin),configured:true,requiresKey:false}}),
    getServerSettings:async()=>({url:(window.AtlasPagesTransport?.server||location.origin),configured:true,serverOnly:true,requiresKey:false}),
    getServerStatus:async()=>{const response=await fetch('/api/models',{credentials:'same-origin'});const data=await response.json();if(!response.ok)throw new Error(data.error||'Atlas-Server nicht erreichbar.');return data;},
    transcribeAudio:async audio=>{const result=await request('/api/transcribe',audio);return result.text;},
    openApp:unavailable,
    onLocalProgress:()=>()=>{},onAskChunk:()=>()=>{},
    onAskStatus:listener=>{statusListeners.add(listener);return ()=>statusListeners.delete(listener);},
    ask:async(messages,requestId,personalization)=>{
      const controller=new AbortController();jobs.set(requestId,controller);
      statusListeners.forEach(listener=>listener({requestId,text:'Atlas antwortet über deinen Server-PC …'}));
      try{const response=await request('/api/chat',{messages,personalization},controller.signal);return {ok:true,text:response.reply,sources:response.sources||[],web:response.web};}
      catch(error){return {ok:false,message:controller.signal.aborted?'Antwort gestoppt.':error.message};}
      finally{jobs.delete(requestId);}
    },
    cancelAsk:async id=>{jobs.get(id)?.abort();return true;},
    extractVocabulary:async options=>{const controller=new AbortController();jobs.set(options.requestId,controller);try{return await request('/api/vocabulary',options,controller.signal);}finally{jobs.delete(options.requestId);}},
    cancelVocabulary:async id=>{jobs.get(id)?.abort();return true;},
    setVoiceState:()=>{},onAutoStart:()=>()=>{},onPushToTalk:()=>()=>{},onVoiceCommand:()=>()=>{}
  };
  async function changeAccount(route,data){
    const ready=cloudSyncReady,paused=cloudSyncPaused;cloudSyncReady=false;cloudSyncPaused=true;clearTimeout(cloudSaveTimer);
    try{
      const result=await request(route,data);
      if(result.confirmationRequired){cloudSyncReady=ready;cloudSyncPaused=paused;return result;}
      location.reload();return new Promise(()=>{});
    }catch(error){cloudSyncReady=ready;cloudSyncPaused=paused;throw error;}
  }
})();
