document.querySelector('#download-form').addEventListener('submit',async event=>{
  event.preventDefault();const form=event.target,button=form.querySelector('button'),error=document.querySelector('#download-error'),status=document.querySelector('#download-status'),input=document.querySelector('#download-code');
  button.disabled=true;button.textContent='Wird freigeschaltet …';error.textContent='';status.textContent='';
  try{const response=await fetch('/api/download/unlock',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-Atlas-Client':'atlas-web'},body:JSON.stringify({platform:form.dataset.platform,code:input.value})});input.value='';const result=await response.json();if(!response.ok)throw new Error(result.error||'Der Download konnte nicht freigeschaltet werden.');status.textContent='Der Download wird gestartet. Du findest die Datei anschließend in deinen Downloads.';location.assign(result.url);}
  catch(failure){error.textContent=failure.message||'Keine Verbindung zu Atlas.';}
  finally{button.disabled=false;button.textContent='Freischalten & herunterladen ↓';}
});
