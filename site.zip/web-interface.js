(() => {
  const settings=document.querySelector('#ai-settings-dialog');
  function closeSettings(){if(settings.open)settings.close();settings.removeAttribute('open');}
  function openSettings(){if(!settings.open)settings.showModal();}
  function selectGroup(group){
    settings.querySelectorAll('.settings-content > .setting-card').forEach(card=>card.classList.toggle('hidden',card.dataset.settingsGroup!==group));
    settings.querySelectorAll('.settings-tabs button').forEach(tab=>tab.classList.toggle('active',tab.dataset.group===group));
  }
  // Keep navigation independent of desktop event handlers and modal state.
  showView=function(view){
    if(!['chat','calendar','research','grades','learn'].includes(view))return;
    closeSettings();
    for(const id of ['chat','calendar','research','grades','learn','voice'])document.querySelector('#'+id+'-view')?.classList.toggle('hidden',id!==view);
    document.querySelector('.vocci-subnav')?.classList.toggle('hidden',view!=='learn');
    document.querySelectorAll('.sidebar .nav-item').forEach(item=>item.classList.toggle('active',item.dataset.view===view));
  };
  document.addEventListener('click',event=>{
    const target=event.target.closest('button');if(!target)return;
    if(target.id==='ai-settings-close'){event.preventDefault();event.stopImmediatePropagation();closeSettings();return;}
    if(target.id==='ai-settings-button'||target.dataset.view==='web-settings'){event.preventDefault();event.stopImmediatePropagation();openSettings();return;}
    if(target.closest('.settings-tabs')&&target.dataset.group){event.preventDefault();event.stopImmediatePropagation();selectGroup(target.dataset.group);return;}
    if(target.closest('.sidebar')&&target.matches('.nav-item[data-view]')){
      const view=target.dataset.view;if(!['chat','calendar','research','grades','learn'].includes(view))return;
      event.preventDefault();event.stopImmediatePropagation();
      try{
        if(view==='learn'&&target.onclick){target.onclick.call(target,event);return;}
        showView(view);if(view==='calendar')renderCalendar();if(view==='grades')renderGradebook();
      }catch(error){console.error('Atlas-Navigation:',error);showView(view);toast('Der Bereich wurde geöffnet. Falls Inhalte fehlen, lade die Seite neu.',{error:true});}
    }
  },true);
  settings.addEventListener('cancel',event=>{event.preventDefault();closeSettings();});
  const button=document.createElement('button');button.type='button';button.className='nav-item';button.dataset.view='web-settings';button.innerHTML='<span>⚙</span> Einstellungen';button.onclick=()=>settings.showModal();document.querySelector('.nav-item[data-view="learn"]').after(button);
  document.querySelector('.sidebar-bottom').innerHTML='<span class="status-dot"></span> Atlas Web · Dein PC als Server';
  document.querySelector('.privacy').textContent='Lokal gespeichert · Mit Atlas-Konto: Chats, Kalender und Noten synchronisieren';
  document.querySelector('.disclaimer').textContent='Atlas läuft auf deinem Server-PC. Unter Einstellungen → Konto kannst du dich anmelden.';
  const status=document.querySelector('#provider-status');if(status)status.textContent='Serverbetrieb · '+location.host;
  for(const input of ['voice-autostart','windows-autostart'])document.querySelector('#'+input)?.closest('label')?.classList.add('web-only-hidden');
  const voice=document.querySelector('#voice-entry');if(voice){voice.disabled=true;voice.title='Sprachmodus ist weiterhin in der Windows-App verfügbar.';voice.setAttribute('aria-label','Atlas');}
  document.querySelector('#mic')?.classList.add('web-only-hidden');
  document.querySelector('[data-pie-action="voice"]')?.classList.add('web-only-hidden');
  document.querySelector('.settings-tabs button[data-group="audio"]')?.classList.add('web-only-hidden');
  const account=document.createElement('div');account.className='setting-card';account.dataset.settingsGroup='account';account.innerHTML='<h3>Zugang zur Webseite</h3><p>Mit deinem Atlas-Konto oben kannst du Chats, Kalender, Wochenplan, Noten und Vocci-Lernsets samt Lernfortschritt synchronisieren. Lokale Daten bleiben pro Konto getrennt. Bilddateien bleiben auf diesem Gerät.</p><button type="button" class="secondary-button" id="web-logout">Web-Zugang abmelden</button>';
  account.classList.add('hidden');document.querySelector('.settings-content').append(account);
  account.querySelector('button').onclick=async()=>{await fetch('/api/logout',{method:'POST',headers:{'Content-Type':'application/json','X-Atlas-Client':'atlas-web'},body:'{}'});location.replace('/');};
  const security=settings.querySelector('.account-security');if(security)security.textContent='Dein Atlas-Konto bleibt auf diesem Gerät bis zu 180 Tage angemeldet, auch nach einem Server-Neustart. „Abmelden“ entfernt die gemerkte Kontoanmeldung. Dein Passwort wird nicht gespeichert.';
  const accountGroup=settings.querySelector('.settings-tabs button[data-group="account"]');if(accountGroup)accountGroup.textContent='Konto / Anmelden';
  window.atlasWebImageMigration?.then(()=>renderChat());
})();
