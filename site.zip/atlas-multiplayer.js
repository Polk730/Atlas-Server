/* Multiplayer UI: the server owns questions, deadlines and scoring. */
(() => {
  let root=null,deck=null,credentials=null,state=null,poll=null,inflight=false,revision=0,signature='',scope='';
  const node=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
  const button=(label,fn)=>{const n=node('button','secondary-button',label);n.type='button';n.onclick=fn;return n;};
  const accountScope=()=>document.querySelector('meta[name="atlas-account-id"]')?.content||document.querySelector('#account-current-email')?.textContent||'guest';
  const storageKey=()=> 'atlas.vocci.duel.v1:'+scope;
  function remember(){try{if(credentials)sessionStorage.setItem(storageKey(),JSON.stringify(credentials));else sessionStorage.removeItem(storageKey());}catch{}}
  function notice(message){if(root?.isConnected){let n=root.querySelector('.duel-notice');if(!n){n=node('p','duel-notice');n.setAttribute('role','status');root.append(n);}n.textContent=message;}}
  async function call(action,payload={}){
    if(inflight)return;inflight=true;const version=revision;
    root?.querySelectorAll('button').forEach(b=>b.disabled=true);
    try{
      if(!window.samuelDesktop?.multiplayer)throw new Error('Bitte Atlas und deinen Server aktualisieren.');
      const result=await window.samuelDesktop.multiplayer(action,{...credentials,...payload});
      if(version!==revision||scope!==accountScope())return;
      if(result.token){credentials={code:result.code,token:result.token};remember();}
      if(result.left){credentials=null;state=null;remember();signature='';draw();return;}
      state=result;state.receivedAt=Date.now();draw();notice('');
    }catch(error){if(version!==revision)return;const message=String(error.message||error).replace(/^Error invoking remote method .*?: Error: /,'');if(/Raum nicht gefunden|Platz ist nicht mehr gültig/.test(message)){credentials=null;state=null;remember();signature='';draw();}notice(message);}
    finally{if(version===revision){inflight=false;root?.querySelectorAll('button').forEach(b=>b.disabled=b.dataset.locked==='true');schedule();}}
  }
  function schedule(){clearTimeout(poll);if(credentials&&root?.isConnected)poll=setTimeout(()=>call('state'),1300);}
  function select(values){const n=node('select');for(const [value,label] of values)n.add(new Option(label,String(value)));return n;}
  function field(parent,label,input){const n=node('label','duel-field');n.append(node('span','',label),input);parent.append(n);return input;}
  function scoreboard(container){container.replaceChildren();for(const p of [...state.players].sort((a,b)=>state.phase==='question'?0:b.score-a.score)){const row=node('div','duel-player');row.append(node('b','',p.name+(p.id===state.you?' (du)':'')),node('span','',state.phase==='lobby'?(p.id===state.host?'Gastgeber':p.online?'Bereit':'Verbindung fehlt'):state.phase==='question'?(p.answered?'Abgegeben':'Überlegt …'):p.score+' Punkte'));container.append(row);}}
  function draw(){
    if(!root?.isConnected)return;
    const next=state?state.phase+':'+state.index+':'+Boolean(state.submitted):'setup';
    if(state?.phase==='question'&&signature===next&&root.querySelector('#duel-answer')){scoreboard(root.querySelector('.duel-scores'));return;}
    signature=next;root.replaceChildren();const header=node('div','duel-heading');header.append(node('p','eyebrow','VOCCI / MULTIPLAYER'),node('h2','','Vokabel-Duell'),node('p','vocci-muted','2–8 Spieler · gleicher Atlas-Server · richtige Antworten zählen am meisten'));const full=button('Vollbild ↗',async()=>{if(document.fullscreenElement===root){await document.exitFullscreen();return;}if(root.classList.contains('duel-fullscreen-fallback')){root.classList.remove('duel-fullscreen-fallback');return;}try{await root.requestFullscreen();}catch{root.classList.add('duel-fullscreen-fallback');}});header.append(full);root.append(header);
    if(!state){
      const setup=node('div','duel-setup'),name=field(setup,'Dein Spielername',node('input'));name.maxLength=24;name.placeholder='Zum Beispiel: Polk';
      const direction=field(setup,'Richtung für deinen Raum',select([['front','Vorderseite → Rückseite'],['back','Rückseite → Vorderseite']]));
      const count=field(setup,'Fragen',select([[5,'5 Fragen'],[10,'10 Fragen'],[15,'15 Fragen'],[20,'20 Fragen']]));count.value='10';
      const seconds=field(setup,'Zeit pro Frage',select([[20,'20 Sekunden'],[30,'30 Sekunden'],[45,'45 Sekunden'],[60,'60 Sekunden']]));seconds.value='30';
      setup.append(node('p','vocci-muted','Nur das ausgewählte Set wird für die Runde auf deinem Server geteilt. Räume verfallen spätestens nach zwei Stunden; ein Serverneustart beendet sie.'));
      const create=button('Raum mit „'+(deck?.title||'Lernset')+'“ erstellen',()=>call('create',{name:name.value,title:deck?.title,cards:deck?.cards?.map(c=>({front:c.front,back:c.back})),reversed:direction.value==='back',count:Number(count.value),seconds:Number(seconds.value)}));if(!deck?.cards?.length){create.disabled=true;create.dataset.locked='true';}setup.append(create);
      const code=field(setup,'Oder Raumcode eingeben',node('input'));code.maxLength=6;code.placeholder='ABC234';code.autocomplete='off';setup.append(button('Beitreten',()=>call('join',{name:name.value,code:code.value.trim().toUpperCase()})));
      if(credentials)setup.append(button('Gespeichertes Spiel fortsetzen',()=>call('state')),button('Gespeicherten Raum vergessen',()=>{credentials=null;remember();draw();}));
      setup.append(node('p','vocci-muted','Windows: Deinen Server unter Einstellungen → KI-Anbieter einrichten. Freunde öffnen dieselbe Atlas-Webseite und melden sich dort wie gewohnt an. Der Raumcode ersetzt nicht den Webseitenzugang.'));
      root.append(setup);return;
    }
    const bar=node('div','duel-bar');bar.append(node('b','','Raum '+state.code+' · '+state.title),button('Raum verlassen',()=>call('leave')));root.append(bar);
    const scores=node('div','duel-scores');scoreboard(scores);
    if(state.phase==='lobby'){
      root.append(node('h3','','Code teilen: '+state.code),node('p','vocci-muted',state.players.length+' / 8 Spieler · '+state.total+' Fragen · '+state.seconds+' Sekunden'),scores);
      const copy=button('Raumcode kopieren',async()=>{try{await navigator.clipboard.writeText(state.code);notice('Raumcode kopiert.');}catch{notice('Raumcode: '+state.code);}});root.append(copy,button('Freunde einladen',()=>window.AtlasSocial?.invite({service:'vocci',...credentials}).catch(error=>notice(error.message))));
      if(state.host===state.you){const start=button('Duell starten',()=>call('start'));start.dataset.locked=String(state.players.filter(p=>p.online).length<2);start.disabled=start.dataset.locked==='true';root.append(start);}else root.append(node('p','vocci-muted','Warte auf den Gastgeber …'));
    }else if(state.phase==='question'){
      root.append(node('p','eyebrow','FRAGE '+(state.index+1)+' / '+state.total),node('p','duel-clock'),node('h3','duel-question',state.question));
      if(state.submitted)root.append(node('p','duel-feedback','Antwort abgegeben. Die Lösung kommt nach Ende der Frage.'));
      else{const form=node('form','duel-answer-form'),input=node('input');input.id='duel-answer';input.maxLength=600;input.autocomplete='off';input.spellcheck=false;input.placeholder='Deine Übersetzung …';input.setAttribute('aria-label','Deine Übersetzung');const submit=node('button','primary-button','Antwort abgeben');submit.type='submit';form.append(input,submit);form.onsubmit=event=>{event.preventDefault();if(input.value.trim())call('answer',{index:state.index,answer:input.value});};root.append(form);input.focus();}
      root.append(node('p','vocci-muted','Kommas, Satzpunkte, Gross-/Kleinschreibung und Akzente sind egal: e zählt auch für é oder è. Artikel zählen.'),scores);updateClock();
    }else if(state.phase==='reveal'){
      root.append(node('p','eyebrow','AUFLÖSUNG '+(state.index+1)+' / '+state.total),node('h3','duel-question',state.question),node('p','duel-solution',state.solution),node('p','',state.yourAnswer?(state.yourAnswer.correct?'Richtig · +'+state.yourAnswer.points+' Punkte':'Deine Antwort: '+state.yourAnswer.given):'Keine Antwort abgegeben.'),node('p','duel-clock'),scores);updateClock();
    }else{
      root.append(node('h3','','Runde beendet'),scores,node('h3','','Deine Fehler zum Wiederholen'));
      const mistakes=state.review.filter(r=>!r.correct);if(!mistakes.length)root.append(node('p','duel-solution','Alles richtig – stark!'));
      for(const item of mistakes){const row=node('article','duel-review');row.append(node('b','',item.question),node('p','','Deine Antwort: '+(item.given||'—')),node('p','','Richtig: '+item.solution));root.append(row);}
      if(mistakes.length)root.append(button('Fehler als Lernset vorbereiten',()=>{window.AtlasVocciImport?.('Duell: '+state.title,mistakes.map(x=>({front:x.question,back:x.solution})));}));
    }
  }
  function updateClock(){if(!state||!root?.isConnected)return;const clock=root.querySelector('.duel-clock');if(!clock)return;const now=state.now+Date.now()-state.receivedAt,start=state.startsAt||0,waiting=state.phase==='question'&&now<start;const end=waiting?start:state.phase==='question'?state.deadline:state.nextAt;clock.textContent=(waiting?'Start in ':state.phase==='question'?'Noch ':'Weiter in ')+Math.max(0,Math.ceil((end-now)/1000))+' s';const submit=root.querySelector('.duel-answer-form button');if(submit){submit.dataset.locked=String(waiting||now>=state.deadline);submit.disabled=inflight||submit.dataset.locked==='true';}}
  setInterval(updateClock,250);
  window.AtlasMultiplayer={async joinInvite(invite,name){
 if(inflight)throw new Error('Bitte kurz warten und erneut beitreten.');
 const dialog=node('dialog','social-dialog'),stage=node('div');dialog.append(button('Schliessen',()=>dialog.close()),stage);document.body.append(dialog);dialog.onclose=()=>{clearTimeout(poll);dialog.remove();};dialog.showModal();
 this.render(stage,null,false);clearTimeout(poll);if(credentials&&credentials.code!==invite.code){if(!confirm('Aktuelles Vokabel-Duell verlassen?')){dialog.close();return;}await call('leave');}if(credentials?.code===invite.code)await call('state');else await call('join',{code:invite.code,name:String(name).slice(0,24)});
 },render(stage,current,resume=true){clearTimeout(poll);revision++;inflight=false;deck=current;const nextScope=accountScope();if(nextScope!==scope){scope=nextScope;state=null;credentials=null;try{credentials=JSON.parse(sessionStorage.getItem(storageKey())||'null');}catch{}}root=node('section','duel');stage.replaceChildren(root);signature='';draw();if(credentials&&resume)call('state');}};
})();
