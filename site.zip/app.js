'use strict';
const $=selector=>document.querySelector(selector);
const CHAT_KEY='atlas-web-chats-v1',PREF_KEY='atlas-web-preferences-v1';
let chats=[],preferences={theme:'violet',sounds:true,motion:false},activeId=null,pending=null,controller=null,preparing=false,audio=null,toastTimer;
try{const saved=JSON.parse(localStorage.getItem(CHAT_KEY)||'[]');if(Array.isArray(saved))chats=saved.filter(chat=>chat&&typeof chat.id==='string'&&Array.isArray(chat.messages));preferences={...preferences,...JSON.parse(localStorage.getItem(PREF_KEY)||'{}')};}catch{}
function toast(text){$('#toast').textContent=text;$('#toast').classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.add('hidden'),5500);}
function save(){try{localStorage.setItem(CHAT_KEY,JSON.stringify(chats));return true;}catch{toast('Der Browser konnte das Gespräch nicht speichern. Exportiere deine Chats in den Einstellungen.');return false;}}
function applyPreferences(){document.body.dataset.theme=['violet','ocean','emerald'].includes(preferences.theme)?preferences.theme:'violet';document.body.dataset.motion=preferences.motion?'reduced':'full';$('#theme').value=document.body.dataset.theme;$('#sounds').checked=preferences.sounds;$('#motion').checked=preferences.motion;}
function sound(kind){
  if(!preferences.sounds)return;
  try{audio ||= new (window.AudioContext||window.webkitAudioContext)();audio.resume().then(()=>{const notes=kind==='reply'?[523,659]:[440];notes.forEach((frequency,index)=>{const start=audio.currentTime+index*.065,osc=audio.createOscillator(),gain=audio.createGain();osc.frequency.value=frequency;gain.gain.setValueAtTime(.0001,start);gain.gain.exponentialRampToValueAtTime(.012,start+.012);gain.gain.exponentialRampToValueAtTime(.0001,start+.16);osc.connect(gain);gain.connect(audio.destination);osc.onended=()=>{osc.disconnect();gain.disconnect();};osc.start(start);osc.stop(start+.18);});});}catch{}
}
let imageDB;
function db(){imageDB ||= new Promise((resolve,reject)=>{const request=indexedDB.open('atlas-web-images',1);request.onupgradeneeded=()=>request.result.createObjectStore('images');request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(new Error('Der Bildspeicher ist nicht verfügbar.'));});return imageDB;}
async function imageStore(method,key,value){const database=await db();return new Promise((resolve,reject)=>{const tx=database.transaction('images',method==='get'?'readonly':'readwrite');const store=tx.objectStore('images');const request=method==='put'?store.put(value,key):store[method](key);tx.oncomplete=()=>resolve(request.result);tx.onerror=()=>reject(new Error('Das Bild konnte nicht gespeichert werden.'));});}
async function api(endpoint,data,signal){const response=await fetch(endpoint,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-Atlas-Client':'atlas-web'},body:JSON.stringify(data),signal});const result=await response.json();if(!response.ok){if(response.status===401)showLogin();throw new Error(result.error||'Die Anfrage ist fehlgeschlagen.');}return result;}
function showLogin(){$('#login').classList.remove('hidden');$('#app').classList.add('hidden');}
function showApp(){location.replace('/atlas');return;$('#login').classList.add('hidden');$('#app').classList.remove('hidden');renderList();renderChat();}
function current(){return chats.find(chat=>chat.id===activeId);}
function shortTitle(text){return text.trim().replace(/[.!?,;:]+/g,'').split(/\s+/).slice(0,3).join(' ').slice(0,28)||'Neuer Chat';}
function home(){if(controller){toast('Stoppe zuerst die laufende Antwort.');return;}activeId=null;pending=null;renderAttachment();renderChat();renderList();$('#sidebar').classList.remove('open');}
function renderList(){
  const list=$('#chat-list');list.replaceChildren();$('#chat-count').textContent=chats.length;
  if(!chats.length){const empty=document.createElement('p');empty.className='history-empty';empty.textContent='Noch ganz viel Platz für deine Gedanken.';list.append(empty);}
  for(const chat of chats){
    const row=document.createElement('div');row.className='history-item'+(chat.id===activeId?' active':'');
    const open=document.createElement('button');open.textContent=chat.title||'Neuer Chat';open.title=chat.title;open.onclick=()=>{if(controller){toast('Stoppe zuerst die laufende Antwort.');return;}activeId=chat.id;pending=null;renderAttachment();renderList();renderChat();$('#sidebar').classList.remove('open');};
    const menu=document.createElement('button');menu.textContent='⋯';menu.title='Gespräch umbenennen oder löschen';menu.setAttribute('aria-label','Gespräch verwalten');
    menu.onclick=()=>{const choice=window.prompt('Neuer Chatname – oder „LÖSCHEN“, um das Gespräch zu entfernen:',chat.title);if(choice===null)return;if(choice==='LÖSCHEN'){if(controller&&chat.id===activeId){toast('Bitte zuerst die Antwort stoppen.');return;}chats=chats.filter(item=>item.id!==chat.id);if(activeId===chat.id)activeId=null;for(const item of chat.messages)if(item.imageRef)imageStore('delete',item.imageRef).catch(()=>{});renderChat();}else if(choice.trim())chat.title=choice.trim().slice(0,60);save();renderList();};
    row.append(open,menu);list.append(row);
  }
}
function appendText(host,text){
  const chunks=String(text).split(/```([^\n`]*)\n?([\s\S]*?)```/g);
  for(let i=0;i<chunks.length;i++){if(i%3===1)continue;const node=document.createElement(i%3===2?'pre':'span');node.textContent=chunks[i];host.append(node);}
}
function bubble(message){
  const element=document.createElement('article');element.className='message '+message.role;
  const meta=document.createElement('div');meta.className='meta';
  if(message.role==='assistant'){const logo=document.createElement('img');logo.src='/atlas.png';logo.alt='';meta.append(logo);}meta.append(document.createTextNode(message.role==='assistant'?'ATLAS':'DU'));
  const text=document.createElement('div');text.className='text';appendText(text,message.text);element.append(meta,text);
  if(message.imageRef){const image=document.createElement('img');image.className='message-photo';image.alt='Angehängtes Bild';imageStore('get',message.imageRef).then(value=>{if(value){image.src=value.url;element.append(image);}}).catch(()=>{});}
  if(message.role==='assistant'){const copy=document.createElement('button');copy.className='copy';copy.textContent='Kopieren';copy.onclick=()=>navigator.clipboard.writeText(message.text).then(()=>toast('Antwort kopiert.')).catch(()=>toast('Kopieren wird in diesem Browser nicht unterstützt.'));element.append(copy);}
  return element;
}
function renderChat(){const chat=current();$('#welcome').classList.toggle('hidden',Boolean(chat?.messages.length));$('#messages').classList.toggle('hidden',!chat?.messages.length);$('#current-title').textContent=chat?.title||'Startseite';$('#messages').replaceChildren(...(chat?.messages||[]).map(bubble));$('#messages').scrollTop=$('#messages').scrollHeight;}
function renderAttachment(){const host=$('#attachment');host.replaceChildren();host.classList.toggle('hidden',!pending);if(!pending)return;const img=document.createElement('img');img.src=pending.url;img.alt='Bildvorschau';const name=document.createElement('span');name.textContent=pending.name;const remove=document.createElement('button');remove.type='button';remove.textContent='×';remove.setAttribute('aria-label','Bild entfernen');remove.onclick=()=>{pending=null;renderAttachment();};host.append(img,name,remove);$('#model-label').textContent='Gemma3 · Bildanalyse';}
async function prepareImage(file){
  if(controller||preparing)return;
  if(!file||!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>15*1024*1024){toast('Bitte ein JPG-, PNG- oder WebP-Bild unter 15 MB wählen.');return;}
  preparing=true;$('#attach').disabled=true;let bitmap;
  try{bitmap=await createImageBitmap(file,{imageOrientation:'from-image'});if(bitmap.width*bitmap.height>40000000)throw new Error('Bitte einen kleineren Bildausschnitt verwenden.');const scale=Math.min(1,2048/Math.max(bitmap.width,bitmap.height));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));const context=canvas.getContext('2d');context.fillStyle='white';context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(bitmap,0,0,canvas.width,canvas.height);const url=canvas.toDataURL('image/jpeg',.85);if(url.length>2800000)throw new Error('Bitte einen kleineren Bildausschnitt verwenden.');pending={id:crypto.randomUUID(),url,name:file.name||'Eingefügtes Bild'};renderAttachment();$('#prompt').focus();}catch(error){toast(error.message||'Das Bild konnte nicht gelesen werden.');}finally{bitmap?.close();preparing=false;$('#attach').disabled=false;}
}
async function context(messages){
  const kept=[];let size=0,imageCount=0;
  for(const message of [...messages].reverse()){
    if(size+message.text.length>22000||kept.length>=20)break;size+=message.text.length;
    const entry={role:message.role,text:message.text};
    if(message.imageRef&&imageCount<4){const image=await imageStore('get',message.imageRef);if(image){entry.images=[{mimeType:'image/jpeg',data:image.url.split(',')[1]}];imageCount++;}else entry.text+='\n[Das ältere Bild ist nicht mehr verfügbar.]';}
    kept.unshift(entry);
  }
  while(kept[0]?.role==='assistant')kept.shift();return kept;
}
async function send(){
  if(controller||preparing)return;
  const text=$('#prompt').value.trim()||(pending?'Was ist auf diesem Bild zu sehen?':'');if(!text)return;
  const selectedImage=pending;
  controller=new AbortController();const request=controller;
  $('#send').classList.add('hidden');$('#stop').classList.remove('hidden');$('#attach').disabled=true;
  let typing,interval,chat;
  try{
    if(selectedImage)await imageStore('put',selectedImage.id,selectedImage);
    if(!current()){chat={id:crypto.randomUUID(),title:shortTitle(text),messages:[]};chats.unshift(chat);activeId=chat.id;}else chat=current();
    const message={role:'user',text,...(selectedImage?{imageRef:selectedImage.id}:{})};chat.messages.push(message);save();pending=null;renderAttachment();$('#prompt').value='';$('#prompt').style.height='auto';renderList();renderChat();sound('send');
    typing=document.createElement('div');typing.className='thinking';typing.innerHTML='<i></i><i></i><i></i><span>Atlas schaut nach …</span>';$('#messages').append(typing);$('#messages').scrollTop=$('#messages').scrollHeight;const start=Date.now();interval=setInterval(()=>{typing.querySelector('span').textContent=(selectedImage?'Atlas schaut sich dein Bild an':'Atlas formuliert deine Antwort')+` · ${Math.floor((Date.now()-start)/1000)} s`;},1000);
    const result=await api('/api/chat',{messages:await context(chat.messages)},request.signal);
    chat.messages.push({role:'assistant',text:result.reply});save();$('#model-label').textContent=result.model.startsWith('gemma')?'Gemma3 · Bildanalyse':'Qwen3 · 4B';renderChat();sound('reply');
  }catch(error){if(error.name==='AbortError')toast('Antwort gestoppt.');else{toast(error.message||'Die Verbindung zum Server ist unterbrochen.');if(chat){const notice=document.createElement('p');notice.className='error';notice.textContent=error.message;$('#messages').append(notice);}}}
  finally{typing?.remove();clearInterval(interval);controller=null;$('#send').classList.remove('hidden');$('#stop').classList.add('hidden');$('#attach').disabled=false;$('#prompt').focus();}
}
$('#login-form').onsubmit=async event=>{event.preventDefault();const button=event.currentTarget.querySelector('button');button.disabled=true;$('#login-error').textContent='';try{await api('/api/login',{code:$('#code').value});$('#code').value='';showApp();sound('send');}catch(error){$('#login-error').textContent=error.message;}finally{button.disabled=false;}};
$('#chat-form').onsubmit=event=>{event.preventDefault();send();};
$('#prompt').addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){event.preventDefault();send();}});
$('#prompt').addEventListener('input',()=>{const field=$('#prompt');field.style.height='auto';field.style.height=Math.min(150,field.scrollHeight)+'px';});
$('#prompt').addEventListener('paste',event=>{const item=[...(event.clipboardData?.items||[])].find(item=>item.type.startsWith('image/'));if(item){event.preventDefault();prepareImage(item.getAsFile());}});
$('#attach').onclick=$('#picture-suggestion').onclick=()=>$('#file').click();$('#file').onchange=event=>{prepareImage(event.target.files?.[0]);event.target.value='';};
document.addEventListener('dragover',event=>{if(event.dataTransfer?.types.includes('Files')){event.preventDefault();$('#chat-form').classList.add('drag');}});
document.addEventListener('dragleave',event=>{if(!event.relatedTarget)$('#chat-form').classList.remove('drag');});
document.addEventListener('drop',event=>{if(event.dataTransfer?.files?.length){event.preventDefault();$('#chat-form').classList.remove('drag');prepareImage(event.dataTransfer.files[0]);}});
$('#stop').onclick=()=>controller?.abort();$('#new-chat').onclick=$('#home').onclick=home;
$('.brand').onclick=event=>{event.preventDefault();home();};$('#about').onclick=()=>$('#about-dialog').showModal();$('#menu-toggle').onclick=()=>$('#sidebar').classList.toggle('open');
document.querySelectorAll('[data-prompt]').forEach(button=>button.onclick=()=>{$('#prompt').value=button.dataset.prompt;send();});
$('#settings-button').onclick=()=>$('#settings').showModal();
for(const id of ['theme','sounds','motion'])$('#'+id).onchange=()=>{preferences={theme:$('#theme').value,sounds:$('#sounds').checked,motion:$('#motion').checked};applyPreferences();try{localStorage.setItem(PREF_KEY,JSON.stringify(preferences));}catch{}sound('send');};
$('#logout').onclick=async()=>{controller?.abort();try{await api('/api/logout',{});$('#settings').close();showLogin();}catch(error){toast(error.message);}};
$('#export').onclick=()=>{const data=new Blob([JSON.stringify({version:1,chats:chats.map(chat=>({...chat,messages:chat.messages.map(({role,text})=>({role,text}))}))},null,2)],{type:'application/json'});const link=document.createElement('a');link.href=URL.createObjectURL(data);link.download='Atlas-Gespraeche.json';link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);toast('Textverläufe exportiert. Bilder sind nicht im Export enthalten.');};
document.addEventListener('keydown',event=>{if(event.altKey&&event.key.toLowerCase()==='n'){event.preventDefault();home();$('#prompt').focus();}});
applyPreferences();
fetch('/api/session').then(response=>response.json()).then(result=>{if(result.authenticated)showApp();else showLogin();}).catch(()=>{$('#login-error').textContent='Der PC-Server ist gerade nicht erreichbar.';});
