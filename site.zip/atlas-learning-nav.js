/* Persistent learning navigation shared by all learning workspaces. */
(() => {
'use strict';
const tabs=document.querySelector('.learning-hub-tabs'),root=document.querySelector('#learn-view');if(!tabs||!root)return;
root.before(tabs);tabs.classList.add('atlas-learning-navigation','hidden');let selected='learn';
const entries=[...tabs.querySelectorAll('button')];for(const button of entries){const label=button.textContent;button.dataset.learnSection=button.dataset.learning||(/Übungsblätter/.test(label)?'worksheets':/Prüfungssimulation/.test(label)?'exams':/Lernradar/.test(label)?'radar':'rescue');if(button.dataset.learnSection==='rescue'){button.setAttribute('aria-haspopup','dialog');button.setAttribute('role','button');}else button.setAttribute('role','tab');}
function mark(){const mode=selected==='learn'?(root.classList.contains('math-active')?'math':'vocci'):selected;for(const button of entries){const active=button.dataset.learnSection===mode;button.classList.toggle('active',active);if(button.dataset.learnSection!=='rescue')button.setAttribute('aria-selected',String(active));}document.querySelector('.nav-item[data-view="learn"]')?.classList.toggle('active',['learn','worksheets','exams','radar'].includes(selected));}
const old=showView;showView=function(name){selected=name;old(name);const active=['learn','worksheets','exams','radar'].includes(name);tabs.classList.toggle('hidden',!active);if(active&&name!=='learn')document.querySelectorAll('.vocci-subnav').forEach(n=>n.classList.add('hidden'));mark();};
tabs.addEventListener('click',event=>{const target=event.target.closest('button');if(!target)return;if(target.dataset.learning&&selected!=='learn')showView('learn');},true);
tabs.addEventListener('click',()=>queueMicrotask(mark));new MutationObserver(()=>{if(selected==='learn')mark();}).observe(root,{attributes:true,attributeFilter:['class']});
})();
