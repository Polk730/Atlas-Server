/* Shared learning-set format for browser storage and account synchronization. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.AtlasLearningSync=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
  const KEY='atlas-vocci-v1';
  function normalize(value){
    const source=Array.isArray(value)?{decks:value}:value||{};
    const decks=Array.isArray(source.decks)?source.decks.filter(d=>d&&typeof d.id==='string'&&Array.isArray(d.cards)).map(d=>({...d,updatedAt:Number(d.updatedAt)||1,cards:d.cards.filter(c=>c&&typeof c.front==='string'&&typeof c.back==='string')})):[];
    const deleted={};for(const [id,time]of Object.entries(source.deleted||{}))if(Number.isFinite(time)&&time>0)deleted[id]=time;
    return {version:1,decks,deleted};
  }
  function merge(left,right){
    left=normalize(left);right=normalize(right);
    const deleted={...left.deleted};for(const [id,time]of Object.entries(right.deleted))deleted[id]=Math.max(deleted[id]||0,time);
    const byId=new Map();for(const deck of [...left.decks,...right.decks])if(!byId.has(deck.id)||deck.updatedAt>byId.get(deck.id).updatedAt)byId.set(deck.id,deck);
    return {version:1,decks:[...byId.values()].filter(d=>d.updatedAt>(deleted[d.id]||0)).sort((a,b)=>b.updatedAt-a.updatedAt),deleted};
  }
  function read(){try{return normalize(JSON.parse(localStorage.getItem(KEY)||'[]'));}catch{return normalize(null);}}
  function write(value,notify=true){value=normalize(value);localStorage.setItem(KEY,JSON.stringify(value));if(notify)window.dispatchEvent(new CustomEvent('atlas-learning-updated'));return value;}
  function same(a,b){const strip=d=>{const {updatedAt,...rest}=d;return JSON.stringify(rest);};return strip(a)===strip(b);}
  function commit(decks,baseline){
    const stored=read(),previous=normalize(baseline||stored),old=new Map(previous.decks.map(d=>[d.id,d]));
    const now=Math.max(Date.now(),...stored.decks.map(d=>d.updatedAt+1),...Object.values(stored.deleted).map(t=>t+1));
    const deleted={},ids=new Set(decks.map(d=>d.id));
    for(const deck of previous.decks)if(!ids.has(deck.id))deleted[deck.id]=now;
    const changed=decks.filter(deck=>!old.has(deck.id)||!same(deck,old.get(deck.id))).map(deck=>({...deck,updatedAt:now}));
    return write(merge(stored,{version:1,decks:changed,deleted}),false);
  }
  function apply(remote){return write(merge(read(),remote));}
  return {normalize,merge,read,commit,apply};
});
