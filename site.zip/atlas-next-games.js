(()=>{'use strict';const g=window.AtlasNewGames;if(!g)return;
g.solo.wordle=['Wordle · Deutsch','▤','Ein Wort, fünf Buchstaben, sechs Versuche.',['Errate das gesuchte deutsche Wort mit fünf Buchstaben. Sechs Versuche.','Grün: richtiger Buchstabe am richtigen Platz. Gelb: enthalten, aber an anderer Stelle. Grau: nicht mehr im Wort vorhanden.','Doppelte Buchstaben werden nur so oft markiert, wie sie im Zielwort vorkommen. Eingaben brauchen fünf Buchstaben A–Z; es gibt keine vollständige Wörterbuchprüfung.']];
g.solo.blocks=['Block Blast','▦','Platziere Blöcke und räume ganze Reihen ab.',['Wähle einen der drei Blöcke und tippe auf sein linkes oberes Zielfeld. Am PC kannst du ihn auch ziehen.','Vollständige Reihen und Spalten verschwinden gleichzeitig. Nach drei verbrauchten Blöcken kommen drei neue. Drehen ist nicht möglich.','Jedes Feld gibt zehn Punkte, jede geräumte Linie 100. Aufeinanderfolgende Abräumzüge erhöhen den Bonus. Die Runde endet, wenn kein verbleibender Block mehr passt.']];
g.multi.uno=['UNO · Kartenduell','▱','Farben wechseln, Aktionskarten spielen, Hand leeren.',['2–6 Spieler online, jeder auf seinem Gerät. Sieben Karten pro Person. Gleiche Farbe, gleiche Zahl bzw. gleiches Symbol oder eine Wunschkarte legen.','Aussetzen überspringt den nächsten Spieler. Richtungswechsel dreht die Reihenfolge; zu zweit wirkt er wie Aussetzen. +2 und +4 lassen den nächsten Spieler ziehen und aussetzen. Stapeln und +4-Anfechten sind nicht enthalten.','Wunschkarten benötigen eine Farbauswahl. +4 ist nur erlaubt, wenn du keine Karte in der aktuellen Farbe besitzt.','Du kannst eine Karte ziehen und danach nur diese spielen oder passen. Vor deiner vorletzten Karte „UNO!“ aktivieren; sonst gibt es zwei Strafkarten. Wer zuerst keine Karten mehr hat, gewinnt.','45 Sekunden ohne Aktion: automatisch eine Karte ziehen und Zug weiter. Kein lokaler Splitscreen.']];
const originalStart=g.start;g.start=(id,c)=>id==='wordle'?wordle(c):id==='blocks'?blocks(c):originalStart(id,c);
const originalRender=g.renderMulti;g.renderMulti=(c,root,r,api,now)=>r.game==='uno'?uno(c,root,r,api,now):originalRender(c,root,r,api,now);
function wordle(c){c.begin('wordle','Wordle · Deutsch','Fünf Buchstaben. Sechs Chancen.');const words='APFEL AMPEL ANGST ATLAS AUGEN BAUCH BAUER BERGE BIENE BIRNE BLATT BLUME BOHNE BRIEF BRUST BUCHT DACHS DAMPF DANKE DATUM DECKE DIEBE DRAHT DURST EIMER ENGEL ERNTE FADEN FALKE FARBE FEDER FEIER FEILE FELGE FERNE FEUER FISCH FLUSS FOTOS FRAGE FROST FUCHS GABEL GARBE GEIST GENAU GLEIS GRUND GURKE HAFEN HALLE HALME HANDY HASEL HECKE HEFTE HERDE HEUTE HILFE HITZE HONIG HOTEL HUNDE INSEL JACKE JAHRE KABEL KAKAO KAMIN KANTE KARTE KASSE KATZE KEGEL KERNE KETTE KIOSK KISTE KLANG KLEID KNALL KNOPF KOHLE KRAFT KRONE KUGEL LACHS LAMPE LASER LAUBE LAUNE LEBEN LEHNE LEISE LESEN LICHT LIEBE LINIE LINKS LISTE LOBEN LUNGE MAGEN MAUER MEISE MENGE MILCH MITTE MONAT MORSE MOTOR NABEL NACHT NADEL NARBE NEBEL NEBEN NELKE NEUER NOTEN NUTEN OASEN OPFER ORDEN ORGEL PALME PANDA PANNE PAPPE PARTY PASTE PAUSE PERLE PFERD PFOTE PILOT PILZE PLATZ PORTO PRISE PROBE PUMPE PUNKT RACHE RADIO RAMPE RAUCH RAUPE RECHT REGAL REGEN REIHE REISE RESTE RIESE RINDE RINGE ROBBE ROLLE ROMAN ROSEN RUDER RUNDE SAHNE SALAT SAMEN SAUCE SCHAF SCHAL SCHAU SCHUH SEIFE SEILE SEITE SENDE SERIE SONNE SORGE SPALT SPASS SPIEL SPORT STADT STALL STAND STAUB STEIN STERN STIEL STOFF STROM STUFE SUCHE SUMME SUPER SUPPE TAFEL TANGO TANTE TANNE TASSE TAUBE TEICH TEILE THEMA TIGER TINTE TISCH TITEL TRAUM TREUE TULPE TURBO UNTEN VATER VEGAN VIELE VOGEL VORNE WAAGE WACHE WAGEN WALZE WANGE WARUM WATTE WEBEN WEICH WEIDE WEILE WEISE WELLE WERKE WESPE WETTE WIESE WILDE WOLKE WORTE WUCHT WUNDE WURST ZANGE ZEBRA ZEILE ZEITEN ZELTE ZIEGE ZIELE ZITAT ZUNGE ZWECK ZWEIG'.split(' ').filter(w=>w.length===5),answer=words[Math.floor(Math.random()*words.length)];let guesses=[],marks=[],draft='',done=false;const root=c.el('section','wordle-game'),status=c.el('p','new-game-status','Tippe dein erstes Wort.'),board=c.el('div','wordle-board'),keyboard=c.el('div','wordle-keyboard');root.append(status,board,keyboard,c.btn('Neues Wort',()=>wordle(c)));c.view.append(root);
function enter(key){if(done)return;if(key==='⌫'||key==='Backspace'){draft=draft.slice(0,-1);render();return;}if(key==='Enter'){if(draft.length!==5){status.textContent='Bitte fünf Buchstaben eingeben.';return;}const row=Array(5).fill('absent'),left=[...answer];for(let i=0;i<5;i++)if(draft[i]===answer[i]){row[i]='correct';left[i]=null;}for(let i=0;i<5;i++)if(row[i]!=='correct'){const at=left.indexOf(draft[i]);if(at>=0){row[i]='present';left[at]=null;}}guesses.push(draft);marks.push(row);done=draft===answer||guesses.length===6;status.textContent=done?(draft===answer?'Geschafft in '+guesses.length+' Versuchen!':'Das Wort war '+answer+'.'):'Versuch '+(guesses.length+1)+' / 6';if(draft===answer)c.sound('win');draft='';render();return;}if(/^[A-Z]$/.test(key)&&draft.length<5){draft+=key;render();}}
function render(){board.replaceChildren();for(let r=0;r<6;r++)for(let i=0;i<5;i++){const tile=c.el('span','wordle-tile',(guesses[r]||r===guesses.length&&draft||'')[i]||'');if(marks[r])tile.dataset.mark=marks[r][i];board.append(tile);}keyboard.replaceChildren();const states={},rank={absent:1,present:2,correct:3};guesses.forEach((w,r)=>[...w].forEach((ch,i)=>{if((rank[states[ch]]||0)<rank[marks[r][i]])states[ch]=marks[r][i];}));for(const letters of ['QWERTZUIOP','ASDFGHJKL',['Enter',...'YXCVBNM','⌫']]){const row=c.el('div');for(const key of letters){const b=c.btn(key==='Enter'?'↵':key,()=>enter(key),'wordle-key');b.dataset.mark=states[key]||'';b.disabled=done;b.setAttribute('aria-label',key==='Enter'?'Wort prüfen':key==='⌫'?'Buchstabe löschen':key);row.append(b);}keyboard.append(row);}}c.keys(e=>{if(e.ctrlKey||e.metaKey||e.altKey)return;if(e.key==='Enter'||e.key==='Backspace'||/^[a-zA-Z]$/.test(e.key)){e.preventDefault();if(!e.repeat)enter(e.key.length===1?e.key.toUpperCase():e.key);}});render();}
function blocks(c){c.begin('blocks','Block Blast','Schaffe Platz. Plane drei Blöcke voraus.');const shapes=[[[0,0]],[[0,0],[0,1]],[[0,0],[1,0]],[[0,0],[0,1],[0,2]],[[0,0],[1,0],[2,0]],[[0,0],[0,1],[1,0],[1,1]],[[0,0],[1,0],[2,0],[2,1]],[[0,0],[0,1],[0,2],[1,1]],[[0,0],[0,1],[1,1],[1,2]],[[0,0],[0,1],[0,2],[1,0],[1,1],[1,2],[2,0],[2,1],[2,2]],[[0,0],[1,0],[2,0],[3,0]],[[0,0],[0,1],[0,2],[0,3]]];let grid=Array(64).fill(0),tray=[],selected=0,score=0,combo=0,over=false;const root=c.el('section','blocks-game'),status=c.el('p','new-game-status'),board=c.el('div','blast-board'),pieces=c.el('div','blast-tray');root.append(status,board,pieces,c.btn('Neue Runde',()=>blocks(c)));c.view.append(root);
const fits=(shape,i)=>!!shape&&shape.every(([y,x])=>Math.floor(i/8)+y<8&&i%8+x<8&&!grid[i+y*8+x]);
function refill(){tray=Array.from({length:3},()=>shapes[Math.floor(Math.random()*shapes.length)]);selected=0;}
function hint(i){const valid=fits(tray[selected],i),cells=new Set((tray[selected]||[]).map(([y,x])=>i+y*8+x));[...board.children].forEach((b,n)=>b.dataset.preview=String(valid&&cells.has(n)));}
function place(i){if(over||!fits(tray[selected],i))return;for(const [y,x]of tray[selected])grid[i+y*8+x]=selected+1;score+=tray[selected].length*10;tray[selected]=null;const rows=[],cols=[];for(let n=0;n<8;n++){if(Array.from({length:8},(_,x)=>grid[n*8+x]).every(Boolean))rows.push(n);if(Array.from({length:8},(_,y)=>grid[y*8+n]).every(Boolean))cols.push(n);}if(rows.length||cols.length){combo++;score+=(rows.length+cols.length)*100*combo;for(let n=0;n<64;n++)if(rows.includes(Math.floor(n/8))||cols.includes(n%8))grid[n]=0;c.sound('win');}else{combo=0;c.sound('point');}if(tray.every(p=>!p))refill();else selected=tray.findIndex(Boolean);over=!tray.some(shape=>shape&&grid.some((_,i)=>fits(shape,i)));render();}
function render(){status.textContent=score+' Punkte'+(combo?' · '+combo+'× Combo':'')+(over?' · Kein Block passt mehr.':' · Block wählen, dann Zielfeld antippen');board.replaceChildren();grid.forEach((v,i)=>{const b=c.btn('',()=>place(i),'blast-cell');b.dataset.mark=v;b.disabled=over;b.setAttribute('aria-label','Zeile '+(Math.floor(i/8)+1)+', Spalte '+(i%8+1)+(v?' belegt':' frei'));b.onpointerenter=()=>hint(i);b.ondragover=e=>{e.preventDefault();hint(i);};b.ondrop=e=>{e.preventDefault();place(i);};board.append(b);});board.onpointerleave=()=>[...board.children].forEach(b=>delete b.dataset.preview);pieces.replaceChildren();tray.forEach((shape,i)=>{const b=c.btn('',()=>{if(shape&&!over){selected=i;render();}},'blast-piece');b.disabled=!shape||over;b.draggable=!!shape&&!over;b.setAttribute('aria-pressed',String(selected===i));b.setAttribute('aria-label','Block '+(i+1));b.ondragstart=e=>{selected=i;e.dataTransfer.setData('text/plain',String(i));};if(shape){const h=Math.max(...shape.map(p=>p[0]))+1,w=Math.max(...shape.map(p=>p[1]))+1;b.style.setProperty('--cols',w);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const bit=c.el('i');bit.dataset.on=String(shape.some(p=>p[0]===y&&p[1]===x));b.append(bit);}}pieces.append(b);});}refill();render();}
function uno(c,root,r,api,now){let panel=root.querySelector('.uno-table');if(!panel){panel=c.el('section','uno-table');root.append(panel);}const key=r.version+':'+r.phase;if(panel.dataset.key===key){const clock=panel.querySelector('.uno-clock');if(clock&&r.phase!=='finished')clock.textContent=Math.max(0,Math.ceil((r.deadline-now)/1000))+' s';return;}panel.dataset.key=key;panel.replaceChildren();const u=r.uno;if(!u)return;const me=r.turn===r.you&&r.phase==='uno-play',player=r.players.find(p=>p.id===r.turn),winner=r.players.find(p=>p.id===r.winner),title=c.el('h2','',r.phase==='finished'?(winner?winner.name+' gewinnt!':'Unentschieden'):player?.name+' ist dran');panel.append(title,c.el('p','uno-clock',r.phase==='finished'?(r.reason||''):Math.max(0,Math.ceil((r.deadline-now)/1000))+' s'));const others=c.el('div','uno-opponents');for(const p of r.players.filter(p=>p.id!==r.you))others.append(c.el('span','',p.name+' · '+(u.counts.find(x=>x.id===p.id)?.count||0)+' Karten'));panel.append(others);
const symbols={skip:'⊘',reverse:'⇄',draw2:'+2',draw4:'+4',wild:'✦'},top=c.el('div','uno-card uno-discard',symbols[u.top.value]||u.top.value);top.dataset.color=u.color;panel.append(top,c.el('p','games-muted',u.note||'Deine Karten bleiben für andere Spieler verborgen.'));const color=c.el('select'),label=c.el('label','uno-color','Wunschfarbe');for(const [v,text]of [['red','Rot'],['yellow','Gelb'],['green','Grün'],['blue','Blau']]){const o=c.el('option','',text);o.value=v;color.append(o);}color.value=u.color;label.append(color);const say=c.el('label','uno-say'),check=c.el('input');check.type='checkbox';say.append(check,c.el('span','','UNO! (vor der vorletzten Karte)'));panel.append(label,say);const send=payload=>api('uno',{...payload,version:r.version}),hand=c.el('div','uno-hand');for(const card of u.hand){const b=c.btn(symbols[card.value]||card.value,()=>send({move:'play',cardId:card.id,color:color.value,saidUno:check.checked}),'uno-card');b.dataset.color=card.color;b.disabled=!me||u.drawn&&u.drawn!==card.id;b.setAttribute('aria-label',card.color+' '+(symbols[card.value]||card.value));hand.append(b);}const draw=c.btn('Eine Karte ziehen',()=>send({move:'draw'}),'secondary-button'),pass=c.btn('Passen',()=>send({move:'pass'}),'secondary-button');draw.disabled=!me||!!u.drawn;pass.disabled=!me||!u.drawn;panel.append(c.el('h3','','Deine Hand · '+u.hand.length),hand,draw,pass);}
})();

/* Original city-swallowing arcade game. No third-party game code or assets. */
(() => {
  'use strict';
  const games = window.AtlasNewGames;
  if (!games) return;
  const MAPS = {
    islands: {name:'Island Metropolis',tag:'Glasfassaden · Inseln · Skyline',cols:7,rows:6,water:['#5599cd','#245d94'],road:'#859398',paving:'#e1e4d9'},
    city: {name:'Downtown',tag:'Dichte Blocks · große Beute',cols:7,rows:5,water:['#6eabb9','#3c748b'],road:'#747c85',paving:'#d4d6ce'},
    park: {name:'Green Gardens',tag:'Parks · Alleen · Gartenvillen',cols:6,rows:6,water:['#65a9b5','#347e92'],road:'#a39882',paving:'#dcd6be'},
    harbor: {name:'Sunset Harbor',tag:'Docks · Lagerhäuser · Abendlicht',cols:8,rows:4,water:['#d09e9d','#667eab'],road:'#857d86',paving:'#e7c6ab'},
    oldtown: {name:'Old Town',tag:'Innenhöfe · Ziegeldächer · Uhrturm',cols:6,rows:5,water:['#86b4c7','#4d839e'],road:'#a59b8e',paving:'#e9d6af'},
    neon: {name:'Neon Bay',tag:'Nachtstadt · Neon · Cyber-Türme',cols:7,rows:6,water:['#172b52','#09162e'],road:'#303c55',paving:'#61718b',night:true}
  };
  const TYPES = {
    lamp:{name:'Straßenlaternen',r:5,mass:5,score:8,h:37},signal:{name:'Ampeln',r:5,mass:4,score:7,h:31},bollard:{name:'Poller',r:4,mass:2,score:3,h:9}, person:{name:'Menschen',r:4,mass:3,score:5,h:15},
    bench:{name:'Bänke',r:9,mass:8,score:12,h:9}, tree:{name:'Bäume',r:12,mass:13,score:18,h:32},
    car:{name:'Autos',r:17,mass:28,score:35,h:16}, fountain:{name:'Brunnen',r:20,mass:35,score:48,h:18},
    kiosk:{name:'Kioske',r:24,mass:48,score:65,h:32}, house:{name:'Häuser',r:36,mass:110,score:140,h:76},
    tower:{name:'Hochhäuser',r:53,mass:245,score:320,h:190}, landmark:{name:'Wahrzeichen',r:83,mass:700,score:1200,h:250}
  };
  const COLORS = ['#a6ffe4','#ffb6bd','#c3adff','#ffd982','#8fd4ff'];
  const POWER = {magnet:{name:'Magnet',symbol:'◎',color:'#81edff'},overdrive:{name:'Overdrive',symbol:'ϟ',color:'#ffde75'},vortex:{name:'Mega-Mund',symbol:'◉',color:'#d1adff'}};
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), rand=(a,b)=>a+Math.random()*(b-a), dist2=(a,b)=>(a.x-b.x)**2+(a.y-b.y)**2;
  let preferences={map:'islands',difficulty:'normal',mode:'classic',quality:'auto',effects:true,sound:true};
  try {preferences={...preferences,...JSON.parse(localStorage.getItem('atlas.hole.options.v3')||'{}')};} catch {}
  if(!MAPS[preferences.map])preferences.map='islands';
  if(!['easy','normal','hard'].includes(preferences.difficulty))preferences.difficulty='normal';
  if(!['classic','blitz','explore'].includes(preferences.mode))preferences.mode='classic';
  if(!['auto','high','low'].includes(preferences.quality))preferences.quality='auto';
  const prior=games.start;
  games.solo.hole=['Atlas Hole','◉','Sechs Inselstädte. Eine lebendige Skyline. Werde zum Stadt-Verschlinger.',[
    'WASD / Pfeile bewegen dein Loch. Maus: auf dem Spielfeld halten. Touch: ziehen wie mit einem Joystick. Leertaste oder Boost halten beschleunigt.',
    'Kleine Objekte zuerst! Mit deiner Größe schaltest du Autos, Häuser, Hochhäuser und schließlich das Wahrzeichen frei. Nur passende Objekte werden verschlungen.',
    'Schnell hintereinander sammeln erhöht den Punkte-Multiplikator. Stadtaufträge, Power-ups und verschlungene Rivalen geben zusätzliche Punkte.',
    'Stadtrunde: drei Minuten. Blitz: 90 Sekunden. Entdecken: ohne Zeitlimit und ohne Rivalen. Tabwechsel pausiert die Runde; kein Fortschritt im Hintergrund.',
    'Rekorde werden automatisch auf diesem Gerät gespeichert, getrennt nach Karte, Schwierigkeit und Modus. Es gibt hier keine Cloud-Bestenliste.'
  ]];
  games.start=(id,c)=>id==='hole'?play(c):prior(id,c);

  function play(c) {
    const config={...preferences},map=MAPS[config.map],night=!!map.night,explore=config.mode==='explore';
    c.begin('hole','Atlas Hole','CITY EATER · Sechs Städte, neue Kräfte, größere Ziele.');
    const root=c.el('section','hole-deluxe'),toolbar=c.el('div','hole-toolbar'),stats=c.el('div','hole-stats');
    const stage=c.el('div','hole-stage'),canvas=c.el('canvas','hole-canvas'),overlay=c.el('div','hole-overlay');
    const footer=c.el('div','hole-footer'),message=c.el('p','hole-message'),missionsBox=c.el('div','hole-missions');
    const pause=c.btn('Starten',()=>toggle()),boostButton=c.btn('ϟ Boost halten',()=>{},'primary-button');
    const reset=c.btn('Neue Runde',()=>{if(phase==='playing'||phase==='paused'){if(!confirm('Die laufende Runde beenden und neu starten?'))return;}play(c);});
    const help=c.el('p','games-muted','WASD / Pfeile · Leertaste: Boost · P: Pause · Touch: Joystick · M: Kartenübersicht');
    const style=c.el('style');style.textContent=`
      .hole-deluxe{--hole-accent:#a6ffe4;max-width:1450px;margin:auto;width:100%}
      .hole-toolbar,.hole-footer{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:12px 0}
      .hole-toolbar label{display:grid;gap:4px;color:#aab7c8;font-size:11px;letter-spacing:.04em}
      .hole-toolbar select{max-width:210px;min-height:39px;background:#172331;color:#e9f3f4;border:1px solid #ffffff20;border-radius:10px;padding:7px 10px}
      .hole-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;margin:12px 0}
      .hole-stat{padding:12px 16px;background:linear-gradient(120deg,#a6ffe410,#b29bff09);border:1px solid #ffffff12;border-radius:14px}
      .hole-stat small{display:block;font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:#96abbe}.hole-stat b{display:block;margin-top:3px;color:#eafff6;font-size:21px}
      .hole-stage{position:relative;isolation:isolate;border:1px solid #b7e4ff30;border-radius:22px;overflow:hidden;background:#162c46;box-shadow:0 18px 60px #0003}
      .hole-canvas{display:block;width:100%;height:clamp(390px,65vh,830px);touch-action:none;outline:none}
      .hole-overlay{position:absolute;inset:0;display:grid;place-items:center;padding:20px;background:linear-gradient(130deg,#07152180,#09112740);backdrop-filter:blur(3px)}
      .hole-overlay[hidden]{display:none}.hole-card{max-width:470px;width:100%;text-align:center;padding:30px;border:1px solid #a6ffe444;border-radius:24px;background:linear-gradient(145deg,#132c3bf2,#111a2df5);box-shadow:0 25px 80px #0006}
      .hole-card h2{font-size:clamp(25px,4vw,42px);line-height:1.08;color:#edfff6;margin:12px 0}.hole-card p{color:#b7c9d6;line-height:1.65}.hole-card button{margin:6px}.hole-card .hole-kicker{font-size:10px;letter-spacing:.24em;color:#a6ffe4}
      .hole-missions{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px}.hole-mission{padding:10px 12px;border:1px solid #ffffff15;border-radius:12px;background:#ffffff04;font-size:12px;color:#bdcdd5}.hole-mission b{display:block;color:#e7f9ee;margin-bottom:6px}.hole-track{height:4px;background:#ffffff15;border-radius:6px;overflow:hidden;margin-top:8px}.hole-track i{display:block;height:100%;background:#a6ffe4;transition:width .2s}
      .hole-message{flex:1;min-width:200px;margin:0;color:#b6ead8;font-size:13px}.hole-footer button{touch-action:none;user-select:none}.hole-option{display:flex;gap:7px;align-items:center;color:#afbdce;font-size:12px}
      @media(max-width:650px){.hole-toolbar{gap:8px}.hole-toolbar label{flex:1 1 40%}.hole-toolbar select{width:100%;max-width:none}.hole-stats{gap:5px}.hole-stat{padding:9px}.hole-stat b{font-size:16px}.hole-stat small{font-size:8px}.hole-canvas{height:68vh;min-height:400px;max-height:850px}.hole-missions{grid-template-columns:1fr}.hole-card{padding:22px}.hole-footer .hole-message{order:3;width:100%}}
      @media(prefers-reduced-motion:reduce){.hole-track i{transition:none}}
    `;
    function select(label,options,value,change){const wrapper=c.el('label','',label),input=c.el('select');input.setAttribute('aria-label',label);for(const [id,text]of options){const o=c.el('option','',text);o.value=id;input.append(o);}input.value=value;input.onchange=()=>change(input.value);wrapper.append(input);toolbar.append(wrapper);return input;}
    function changeSetting(key,value){if((phase==='playing'||phase==='paused')&&!confirm('Diese Einstellung startet eine neue Runde. Fortfahren?')){selectors[key].value=config[key];return;}preferences[key]=value;saveOptions();play(c);}
    const selectors={};
    selectors.map=select('Stadt',Object.entries(MAPS).map(([id,m])=>[id,m.name]),config.map,v=>changeSetting('map',v));
    selectors.mode=select('Modus',[['classic','Stadtrunde · 3 Minuten'],['blitz','Blitz · 90 Sekunden'],['explore','Entdecken · ohne Zeitlimit']],config.mode,v=>changeSetting('mode',v));
    selectors.difficulty=select('Rivalen',[['easy','Entspannt'],['normal','Normal'],['hard','Herausforderung']],config.difficulty,v=>changeSetting('difficulty',v));
    selectors.quality=select('Grafik',[['auto','Ausgewogen'],['high','Hoch'],['low','Leicht']],config.quality,v=>changeSetting('quality',v));
    const fxLabel=c.el('label','hole-option'),fx=c.el('input');fx.type='checkbox';fx.checked=config.effects;fx.onchange=()=>{config.effects=preferences.effects=fx.checked;saveOptions();};fxLabel.append(fx,c.el('span','','Effekte'));toolbar.append(fxLabel);
    const audioLabel=c.el('label','hole-option'),audioToggle=c.el('input');audioToggle.type='checkbox';audioToggle.checked=config.sound!==false;audioToggle.onchange=()=>{config.sound=preferences.sound=audioToggle.checked;saveOptions();if(config.sound)unlockAudio();else muteAudio();};audioLabel.append(audioToggle,c.el('span','','Sound'));toolbar.append(audioLabel);
    const statNodes=['Zeit','Punkte','Größe','Stadt verschlungen'].map(label=>{const card=c.el('div','hole-stat'),v=c.el('b','','—');card.append(c.el('small','',label),v);stats.append(card);return v;});
    canvas.tabIndex=0;canvas.setAttribute('aria-label','Atlas Hole. WASD oder Pfeile bewegen, Leertaste Boost, P Pause.');
    message.setAttribute('role','status');message.setAttribute('aria-live','polite');stage.append(canvas,overlay);footer.append(pause,boostButton,c.btn('Karte',()=>{bigMap=!bigMap;}),reset,message);root.append(style,toolbar,stats,stage,footer,missionsBox,help);c.view.append(root);

    const ctx=canvas.getContext('2d',{alpha:false}),T=340,W=map.cols*T+80,H=map.rows*T+80;
    let logicalW=1000,logicalH=700,dpr=1,phase='ready',dead=false,frameId=0,lastTime=0,lastDraw=0,elapsed=0,lastHud=-1;
    const duration=config.mode==='blitz'?90:180;let remaining=duration,zoom=.88,camera={x:210,y:210};
    let energy=1,pointer=null,boostHeld=false,bigMap=false,soundAt=-1,combo=0,comboUntil=0,missionIndex=0,nextPower=14,shake=0;
    let record=0,level=0;const keys=new Set(),objects=[],districts=[],powers=[],particles=[],popups=[],rings=[];
    const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches||(typeof uiPreferences!=='undefined'&&!!uiPreferences.reduceMotion),quality=config.quality,spriteCache=new Map(),districtLookup=new Map();
    let audioContext=null,audioGain=null;
    const recordKey='atlas.hole.deluxe.record.'+config.map+'.'+config.mode+'.'+config.difficulty;
    try{record=Number(localStorage.getItem(recordKey))||0;}catch{}
    const counts={all:0,car:0,tower:0,landmark:0,rivals:0};
    const missionTemplates=[{name:'Straßenfeger',key:'all',goal:30,reward:200},{name:'Parkverbot',key:'car',goal:10,reward:350},{name:'Skyline-Knacker',key:'tower',goal:3,reward:600},{name:'Das große Finale',key:'landmark',goal:1,reward:1200}];
    const missions=missionTemplates.map(m=>({...m,done:false}));
    const me=makePlayer('Du',COLORS[0],0),players=[me];
    if(!explore)for(let i=1;i<5;i++)players.push(makePlayer(['','Nova','Orbit','Echo','Flux'][i],COLORS[i],i));
    function makePlayer(name,color,i){return {name,color,x:i===4?Math.floor(map.cols/2)*T+40:i%2?W-210:210,y:i===4?40:i<2?210:H-210,vx:0,vy:0,mass:0,r:20,score:0,shield:0,freeze:0,target:null,route:[],routeTarget:null,nextThink:0,power:{magnet:0,overdrive:0,vortex:0}};}
    function saveOptions(){try{localStorage.setItem('atlas.hole.options.v3',JSON.stringify(preferences));}catch{}}
    function radius(p){return p.r*(p.power.vortex>elapsed?1.3:1);}
    function updateSize(p){p.r=Math.min(195,20+Math.sqrt(p.mass)*1.85);}
    function land(px,py){if(px<12||py<12||px>W-12||py>H-12)return false;const col=Math.floor(px/T),row=Math.floor(py/T);return px%T<80||py%T<80||districtLookup.has(col+','+row);}
    function add(type,px,py,extra={}){const o={type,x:px,y:py,variant:Math.floor(rand(0,6)),eaten:false,fall:null,...extra};if(land(px,py))objects.push(o);return o;}
    function districtType(col,row){
      const cx=(map.cols-1)/2,cy=(map.rows-1)/2,distance=Math.hypot((col-cx)*.85,row-cy);
      if(config.map==='park')return distance<1.8||col<2?'park':'village';
      if(config.map==='oldtown')return col===1&&row>=1&&row<=2?'park':'village';
      if(config.map==='harbor')return row===0?'industrial':col<=2?'village':distance<1.6?'city':'park';
      if(col===map.cols-2&&row>=1&&row<=2)return 'park';
      return distance<2?'city':distance<2.8?'mixed':'village';
    }
    for(let col=0;col<map.cols;col++)for(let row=0;row<map.rows;row++){
      if(config.map==='islands'&&((col===0&&row>3)||(col===map.cols-1&&row<2)||(col===3&&(row===1||row===4))))continue;
      if(config.map==='neon'&&col===2&&row>1&&row<5)continue;
      const d={col,row,x:col*T+80,y:row*T+80,type:districtType(col,row),total:0,eaten:0};districts.push(d);districtLookup.set(col+','+row,d);
    }
    for(const d of districts){const a=d.x,b=d.y;
      for(let i=0;i<8;i++){add('bollard',a+18+i*30,b-14,{district:d});add(i%3?'person':'bench',a-17,b+18+i*30,{district:d,walk:i%3?rand(7,15):0,low:b+8,high:b+246});}
      for(let i=0;i<3;i++)add('car',a-(i===0?(d.col%2?27:53):17),b+32+i*76,{district:d,traffic:i===0?rand(19,29):0,direction:d.col%2?-1:1,low:b+10,high:b+245});
      add('lamp',a+7,b-10,{district:d});add('lamp',a-10,b+243,{district:d});add('signal',a-13,b-10,{district:d});
      if(d.type==='park'){
        for(let i=0;i<12;i++)add('tree',a+28+(i%4)*64+rand(-11,11),b+25+Math.floor(i/4)*78+rand(-10,10),{district:d});
        add('fountain',a+133,b+180,{district:d});add('kiosk',a+213,b+219,{district:d});
      }else{
        for(let i=0;i<4;i++){let type=d.type==='village'?(i%3===0?'kiosk':'house'):d.type==='industrial'?'house':d.type==='mixed'?(i===2?'tower':'house'):(i%3===0?'house':'tower');if(d.col<2&&d.row<2)type=i%2?'house':'kiosk';add(type,a+64+(i%2)*122,b+67+Math.floor(i/2)*124,{district:d,industrial:d.type==='industrial',zone:d.type});}
        for(let i=0;i<4;i++)add('tree',a+18+i*65,b+251,{district:d});
      }
    }
    const landmarkDistrict=districts.find(d=>d.col===Math.floor(map.cols/2)&&d.row===Math.floor(map.rows/2))||districts[Math.floor(districts.length/2)];
    // Reserve a proper plaza, so the landmark never overlaps a smaller building.
    for(let i=objects.length-1;i>=0;i--)if(objects[i].district===landmarkDistrict&&dist2(objects[i],{x:landmarkDistrict.x+130,y:landmarkDistrict.y+130})<125**2)objects.splice(i,1);
    add('landmark',landmarkDistrict.x+130,landmarkDistrict.y+130,{district:landmarkDistrict,variant:night?1:config.map==='oldtown'?2:0});
    for(const p of players){p.x=clamp(p.x,40,W-40);p.y=clamp(p.y,40,H-40);if(!land(p.x,p.y)){p.x=Math.floor(p.x/T)*T+40;p.y=Math.floor(p.y/T)*T+40;}for(let i=0;i<24;i++){const a=i*Math.PI/12;add(i%4===0?'tree':i%3===0?'bench':'bollard',p.x+Math.cos(a)*rand(30,115),p.y+Math.sin(a)*rand(30,115));}}
    for(const o of objects)if(o.district)o.district.total++;
    const signalIndex=new Map(objects.filter(o=>o.type==='signal').map(o=>[Math.floor(o.x/T)+','+Math.floor(o.y/T),o]));
    const initialCount=objects.length;let eatenCount=0;
    for(const type of Object.keys(POWER))spawnPower(type);

    function announce(text){if(message.textContent!==text)message.textContent=text;}
    function audioAllowed(){return config.sound!==false&&!document.hidden&&(typeof uiPreferences==='undefined'||uiPreferences.soundEffects!==false);}
    function unlockAudio(){if(!audioAllowed())return;try{const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;if(!audioContext){audioContext=new Audio();audioGain=audioContext.createGain();audioGain.connect(audioContext.destination);}if(audioContext.state==='suspended')audioContext.resume().catch(()=>{});}catch{}}
    function muteAudio(){if(audioGain&&audioContext)audioGain.gain.setValueAtTime(0,audioContext.currentTime);}
    function sound(kind='point'){
      if(!audioAllowed()||!(elapsed-soundAt>.13||kind==='win'))return;soundAt=elapsed;
      if(!audioContext||audioContext.state!=='running')return;
      const volume=typeof uiPreferences==='undefined'?.6:Number(uiPreferences.soundVolume??.6);audioGain.gain.setValueAtTime(clamp(Number.isFinite(volume)?volume:.6,0,1)*.1,audioContext.currentTime);
      const notes=kind==='win'?[330,440,660]:kind==='rumble'?[100]:[240+Math.min(combo,20)*15];
      notes.forEach((hz,i)=>{const osc=audioContext.createOscillator(),gain=audioContext.createGain(),at=audioContext.currentTime+i*.075,length=kind==='rumble'?.25:kind==='win'?.17:.08;osc.type=kind==='rumble'?'triangle':'sine';osc.frequency.setValueAtTime(hz,at);osc.frequency.exponentialRampToValueAtTime(kind==='rumble'?35:hz*.75,at+length);gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(.75,at+.008);gain.gain.exponentialRampToValueAtTime(.0001,at+length);osc.connect(gain);gain.connect(audioGain);osc.start(at);osc.stop(at+length+.01);osc.onended=()=>{osc.disconnect();gain.disconnect();};});
    }
    function popup(px,py,text,color='#effff8'){if(popups.length>18)popups.shift();popups.push({x:px,y:py,text,color,life:1.2,max:1.2});}
    function burst(px,py,color,n=12){if(!config.effects||reduced)return;for(let i=0;i<n&&particles.length<100;i++)particles.push({x:px,y:py,z:rand(3,25),vx:rand(-60,60),vy:rand(-60,60),vz:rand(30,100),life:rand(.3,.65),color});}
    function ring(px,py,color){if(config.effects&&!reduced){if(rings.length>8)rings.shift();rings.push({x:px,y:py,r:20,t:0,color});}}
    function reward(p,o){
      const def=TYPES[o.type];p.mass+=def.mass;updateSize(p);let multi=1;
      if(p===me){combo=elapsed<comboUntil?combo+1:1;comboUntil=elapsed+2;multi=1+Math.min(2,Math.floor(combo/8)*.25);counts.all++;if(o.type in counts)counts[o.type]++;const nextLevel=p.r<30?0:p.r<44?1:p.r<63?2:p.r<98?3:4;
        if(nextLevel>level){level=nextLevel;ring(p.x,p.y,p.color);popup(p.x,p.y,'LEVEL '+(level+1),'#fff3ab');announce(['','GRÖSSER! Autos und Kioske werden zur Beute.','Häuser passen jetzt hinein.','Die Skyline gehört dir.','GIANT MODE · Hol dir das Wahrzeichen!'][level]);sound('win');}
        if(o.type==='tower'||o.type==='landmark'){burst(o.x,o.y,'#f6dfa1',18);ring(o.x,o.y,p.color);if(config.effects&&!reduced)shake=o.type==='landmark'?5:2;}
        popup(o.x,o.y,'+'+Math.round(def.score*multi),p.color);sound(o.type==='tower'||o.type==='landmark'?'rumble':'point');
      }
      p.score+=Math.round(def.score*multi);eatenCount++;if(o.district){o.district.eaten++;if(o.district.eaten===o.district.total){p.score+=300;if(p===me){popup(o.x,o.y,'BLOCK GESÄUBERT +300','#ffe2a0');ring(o.x,o.y,'#ffe2a0');}}}
      if(p===me)for(const mission of missions)if(!mission.done&&counts[mission.key]>=mission.goal){mission.done=true;p.score+=mission.reward;popup(p.x,p.y,'AUFTRAG +'+mission.reward,'#ffe2a0');announce(mission.name+' geschafft · +'+mission.reward+' Punkte');sound('win');}
    }
    function spawnPower(type){const col=Math.floor(rand(0,map.cols)),row=Math.floor(rand(0,map.rows));powers.push({type,x:col*T+40,y:row*T+40,born:elapsed});}
    function collectPower(p,power){p.power[power.type]=elapsed+8;if(p===me){announce(POWER[power.type].name+' · 8 Sekunden');popup(p.x,p.y,POWER[power.type].name,POWER[power.type].color);ring(p.x,p.y,POWER[power.type].color);sound('win');}}
    function routeFor(p,target){const ax=Math.floor(p.x/T)*T+40,ay=Math.floor(p.y/T)*T+40,bx=Math.floor(target.x/T)*T+40,by=Math.floor(target.y/T)*T+40;return [{x:ax,y:ay},{x:bx,y:ay},{x:bx,y:by}];}
    function think(p){
      p.nextThink=elapsed+rand(.4,.85);let best=Infinity,target=null;
      for(const o of objects){if(o.eaten||o.fall||TYPES[o.type].r*1.18>=radius(p))continue;const distance=dist2(o,p)/(1+Math.sqrt(TYPES[o.type].mass)*.09);if(distance<best){best=distance;target=o;}}
      if(p.target!==target){p.target=target;p.route=target?routeFor(p,target):[];}
    }
    function movePlayer(p,dt){
      if(p.freeze>elapsed)return;let dx=0,dy=0,boosted=false;
      if(p===me){dx=Number(keys.has('KeyD')||keys.has('ArrowRight'))-Number(keys.has('KeyA')||keys.has('ArrowLeft'));dy=Number(keys.has('KeyS')||keys.has('ArrowDown'))-Number(keys.has('KeyW')||keys.has('ArrowUp'));
        if(pointer&&!dx&&!dy){dx=pointer.x-(pointer.anchor?.x??logicalW/2);dy=pointer.y-(pointer.anchor?.y??logicalH*.56);if(Math.hypot(dx,dy)<10)dx=dy=0;}
        const sx=dx/.78,sy=dy/.43;dx=(sx+sy)*.5;dy=(sy-sx)*.5;boosted=boostHeld&&(energy>.02||p.power.overdrive>elapsed);
        energy=clamp(energy+dt*(boosted&&p.power.overdrive<=elapsed?-.4:.2),0,1);
      }else{
        if(elapsed>=p.nextThink||!p.target||p.target.eaten||p.target.fall)think(p);
        if(p.target){while(p.route.length&&dist2(p,p.route[0])<15**2)p.route.shift();const target=p.route[0]||p.target;dx=target.x-p.x;dy=target.y-p.y;}
        for(const rival of players)if(rival!==p&&radius(rival)>radius(p)*1.35&&dist2(rival,p)<(radius(rival)*2.5)**2){dx=p.x-rival.x;dy=p.y-rival.y;p.nextThink=elapsed+.4;}
        boosted=config.difficulty==='hard'&&Math.sin(elapsed+p.x)>.94;
      }
      const len=Math.hypot(dx,dy),speed=(p===me?210:config.difficulty==='easy'?120:config.difficulty==='hard'?192:158)*(boosted?1.65:1)/(1+p.r/650);
      const response=1-Math.exp(-dt*12);p.vx+=(len?dx/len*speed-p.vx:-p.vx)*response;p.vy+=(len?dy/len*speed-p.vy:-p.vy)*response;
      const nx=clamp(p.x+p.vx*dt,15,W-15),ny=clamp(p.y+p.vy*dt,15,H-15);
      if(land(nx,ny)){p.x=nx;p.y=ny;}else if(land(nx,p.y)){p.x=nx;p.vy=0;}else if(land(p.x,ny)){p.y=ny;p.vx=0;}else{p.vx=p.vy=0;if(p!==me){p.target=null;p.nextThink=0;}}
      const pr=radius(p),magnet=p.power.magnet>elapsed;
      for(const o of objects){if(o.eaten||o.fall||TYPES[o.type].r*1.18>=pr)continue;const dr=TYPES[o.type].r,distance=dist2(o,p);
        if(distance<(pr-dr*.25)**2)o.fall={owner:p,t:0,sx:o.x,sy:o.y};
        else if(magnet&&distance<(pr*2.6)**2&&dr<25){const pull=1-Math.exp(-dt*2.4),ox=o.x+(p.x-o.x)*pull,oy=o.y+(p.y-o.y)*pull;if(land(ox,oy)){o.x=ox;o.y=oy;}}
      }
      for(let i=powers.length-1;i>=0;i--)if(dist2(p,powers[i])<(pr+10)**2){collectPower(p,powers[i]);powers.splice(i,1);}
    }
    function step(dt){
      elapsed+=dt;if(!explore)remaining=Math.max(0,duration-elapsed);
      for(const o of objects){if(o.eaten)continue;if(o.fall){o.fall.t+=dt/(['tower','landmark'].includes(o.type)?0.85:0.42);if(o.fall.t>=1){o.eaten=true;reward(o.fall.owner,o);}continue;}
        if(o.traffic){const dir=o.direction||1,position=o.y%T,col=Math.floor(o.x/T),row=Math.floor(o.y/T)+(dir>0?1:0),signal=signalIndex.get(col+','+row),red=signal&&!signal.eaten&&!signal.fall&&(Math.floor(elapsed/6)+col)%2!==0,approaching=dir>0?position>T-28:position>80&&position<108;if(!(red&&approaching)){o.y+=o.traffic*dir*dt;if(o.y>H-16)o.y=16;if(o.y<16)o.y=H-16;}}
        else if(o.walk){o.y+=o.walk*(o.direction||1)*dt;if(o.y>o.high||o.y<o.low){o.y=clamp(o.y,o.low,o.high);o.direction=-(o.direction||1);}}
      }
      for(const p of players)movePlayer(p,dt);
      for(let i=0;i<players.length;i++)for(let j=i+1;j<players.length;j++){
        let a=players[i],b=players[j];if(radius(a)<radius(b))[a,b]=[b,a];
        if(a.shield>elapsed||b.shield>elapsed||radius(a)<=radius(b)*1.35||dist2(a,b)>(radius(a)-radius(b)*.4)**2)continue;
        for(const o of objects)if(o.fall?.owner===b)o.fall=null;
        a.mass+=Math.max(35,b.mass*.18);a.score+=150;updateSize(a);b.mass*=.65;updateSize(b);b.x=Math.random()<.5?40:W-40;b.y=Math.random()<.5?40:H-40;b.vx=b.vy=0;b.shield=elapsed+4;b.target=null;
        if(a===me){counts.rivals++;popup(a.x,a.y,'RIVALE +150','#ffe9a9');ring(a.x,a.y,a.color);sound('win');}
        if(b===me){resetInput();camera.x=b.x;camera.y=b.y;announce('Verschlungen! Deine Punkte bleiben. Vier Sekunden Schutz zum Neustart.');}
      }
      if(elapsed>=nextPower){nextPower=elapsed+22;if(powers.length<6)spawnPower(Object.keys(POWER)[Math.floor(rand(0,3))]);}
      for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;p.vz-=dt*230;if(p.life<=0)particles.splice(i,1);}
      for(let i=popups.length-1;i>=0;i--){popups[i].life-=dt;if(popups[i].life<=0)popups.splice(i,1);}
      for(let i=rings.length-1;i>=0;i--){rings[i].t+=dt;rings[i].r+=dt*160;if(rings[i].t>1)rings.splice(i,1);}
      shake=Math.max(0,shake-dt*12);
      if((!explore&&remaining<=0)||eatenCount===initialCount)finish();
    }
    function finish(){if(phase==='finished')return;phase='finished';resetInput();record=Math.max(record,me.score);try{localStorage.setItem(recordKey,String(record));}catch{}pause.disabled=true;boostButton.disabled=true;showOverlay(true);sound('win');updateHud();}
    function toggle(){if(phase==='finished')return;phase=phase==='playing'?'paused':'playing';resetInput();overlay.hidden=phase==='playing';pause.textContent=phase==='playing'?'Pause':'Weiter';updateHud();if(phase==='playing'){unlockAudio();canvas.focus();}else{muteAudio();showOverlay();}}
    function showOverlay(finished=false){overlay.hidden=false;overlay.replaceChildren();const card=c.el('div','hole-card'),rank=[...players].sort((a,b)=>b.score-a.score).indexOf(me)+1;
      card.append(c.el('span','hole-kicker',finished?'CITY REPORT':'ATLAS HOLE · CITY EATER'),c.el('h2','',finished?(rank===1?'Die Stadt gehört dir.':'Runde geschafft.'):phase==='ready'?map.name:'Kurze Verschnaufpause.'),c.el('p','',finished?me.score.toLocaleString('de-CH')+' Punkte · Platz '+rank+' / '+players.length+' · Rekord '+record.toLocaleString('de-CH'):map.tag+'\n'+(explore?'Erkunde die Stadt ohne Zeitdruck.':'Erst die Straße. Dann die Skyline.')));
      if(finished)card.append(c.btn('Noch eine Stadt verschlingen',()=>play(c),'primary-button'));
      else card.append(c.btn(phase==='ready'?'Los geht’s':'Weiter verschlingen',()=>toggle(),'primary-button'),c.el('p','','Sammle kleine Dinge, halte deine Serie am Leben und sichere dir die Power-ups.'));
      overlay.append(card);
    }
    function resetInput(){keys.clear();pointer=null;boostHeld=false;}
    function pauseBackground(){muteAudio();if(phase==='playing'){phase='paused';pause.textContent='Weiter';resetInput();showOverlay();updateHud();}else resetInput();}
    function keyup(e){keys.delete(e.code);if(e.code==='Space')boostHeld=false;}
    function visibility(){if(document.hidden)pauseBackground();}
    c.keys(e=>{if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','KeyW','KeyA','KeyS','KeyD','Space'].includes(e.code)){e.preventDefault();keys.add(e.code);if(e.code==='Space')boostHeld=true;}if(!e.repeat&&e.code==='KeyP'){e.preventDefault();toggle();}if(!e.repeat&&e.code==='KeyM'){e.preventDefault();bigMap=!bigMap;}});
    document.addEventListener('keyup',keyup);window.addEventListener('blur',pauseBackground);document.addEventListener('visibilitychange',visibility);window.addEventListener('pagehide',pauseBackground);
    function pointerAt(e){const b=canvas.getBoundingClientRect();return {x:(e.clientX-b.left)/b.width*logicalW,y:(e.clientY-b.top)/b.height*logicalH};}
    canvas.onpointerdown=e=>{if(phase!=='playing')return;e.preventDefault();canvas.focus();canvas.setPointerCapture(e.pointerId);const p=pointerAt(e);pointer={...p,anchor:e.pointerType==='touch'?p:null,id:e.pointerId};};
    canvas.onpointermove=e=>{if(pointer&&pointer.id===e.pointerId)pointer={...pointer,...pointerAt(e)};};
    canvas.onpointerup=canvas.onpointercancel=canvas.onlostpointercapture=e=>{if(pointer?.id===e.pointerId)pointer=null;};
    boostButton.onpointerdown=e=>{e.preventDefault();if(phase==='playing'){boostHeld=true;boostButton.setPointerCapture(e.pointerId);}};boostButton.onpointerup=boostButton.onpointercancel=boostButton.onlostpointercapture=()=>{boostHeld=false;};
    function resize(){const b=canvas.getBoundingClientRect();logicalH=clamp(logicalW*b.height/Math.max(1,b.width),430,1900);dpr=Math.min(devicePixelRatio||1,quality==='high'?2:quality==='low'?1:1.35);canvas.width=Math.round(logicalW*dpr);canvas.height=Math.round(logicalH*dpr);}
    const observer=new ResizeObserver(resize);observer.observe(canvas);resize();

    // Pre-render the streets once; moving the camera only transforms this texture.
    const groundScale=.65,groundCanvas=document.createElement('canvas');groundCanvas.width=Math.ceil(W*groundScale);groundCanvas.height=Math.ceil(H*groundScale);
    const ground=groundCanvas.getContext('2d');ground.scale(groundScale,groundScale);
    function rr(g,x,y,w,h,r,color){g.fillStyle=color;g.beginPath();g.roundRect(x,y,w,h,r);g.fill();}
    function paintGround(){
      for(let col=0;col<=map.cols;col++){const major=col===Math.floor(map.cols/2),width=major?66:46;ground.fillStyle=map.paving;ground.fillRect(col*T,0,80,H);ground.fillStyle=night?'#29364c':'#6f787d';ground.fillRect(col*T+(80-width)/2,0,width,H);}
      for(let row=0;row<=map.rows;row++){const major=row===Math.floor(map.rows/2),width=major?66:46;ground.fillStyle=map.paving;ground.fillRect(0,row*T,W,80);ground.fillStyle=night?'#29364c':'#6f787d';ground.fillRect(0,row*T+(80-width)/2,W,width);}
      ground.lineWidth=1.4;ground.strokeStyle=night?'#93a4ba':'#ebe5ca';ground.setLineDash([12,18]);
      for(let col=0;col<=map.cols;col++){const center=col*T+40;ground.beginPath();ground.moveTo(center,0);ground.lineTo(center,H);ground.stroke();}
      for(let row=0;row<=map.rows;row++){ground.beginPath();ground.moveTo(0,row*T+40);ground.lineTo(W,row*T+40);ground.stroke();}ground.setLineDash([]);
      // Texture is baked once: asphalt grain, pavement joints and planted beds.
      for(let i=0;i<9500;i++){const px=rand(0,W),py=rand(0,H);if(px%T>80&&py%T>80)continue;ground.fillStyle=i%2?'#ffffff0b':'#0000000c';ground.fillRect(px,py,rand(.5,1.6),rand(.5,1.6));}
      for(const d of districts){const a=d.x,b=d.y,park=d.type==='park';rr(ground,a,b,260,260,0,map.paving);rr(ground,a+12,b+12,236,236,2,park?(night?'#3c594d':'#8ba674'):night?'#4a556a':d.type==='industrial'?'#b3b0a5':'#bdc0b1');
        ground.strokeStyle=night?'#7c8d9e26':'#67777d24';ground.lineWidth=.6;for(let n=0;n<=260;n+=13){ground.beginPath();ground.moveTo(a+n,b);ground.lineTo(a+n,b+10);ground.moveTo(a,b+n);ground.lineTo(a+10,b+n);ground.stroke();}
        if(park){ground.strokeStyle=night?'#8a9280':'#d5cdb1';ground.lineWidth=13;ground.lineCap='round';ground.beginPath();ground.moveTo(a+15,b+170);ground.bezierCurveTo(a+90,b+65,a+160,b+240,a+245,b+70);ground.stroke();ground.lineCap='butt';for(let i=0;i<28;i++){ground.fillStyle=i%3?(night?'#526d56':'#91ac7a'):(night?'#6e7d62':'#a4b784');ground.beginPath();ground.ellipse(a+rand(20,240),b+rand(20,240),rand(4,12),rand(3,9),rand(0,3),0,Math.PI*2);ground.fill();}}
        else{for(let i=0;i<4;i++){const px=a+64+(i%2)*122,py=b+67+Math.floor(i/2)*124;rr(ground,px-49,py-48,98,96,1,night?'#687484':'#d2d0c2');ground.strokeStyle=night?'#b6bbbc55':'#f9f6e299';ground.lineWidth=1;for(let j=0;j<3;j++)ground.strokeRect(px-40+j*24,py+31,19,12);ground.fillStyle=night?'#687b67':'#8b9c72';ground.fillRect(px-43,py-42,12,9);}}
        for(let i=0;i<6;i++){ground.fillStyle=night?'#acb8c0':'#f2eee0';ground.fillRect(a-62+i*8,b-5,4,19);ground.fillRect(a-5,b-62+i*8,19,4);}
        ground.strokeStyle=night?'#c5ceca55':'#f0eadb';ground.lineWidth=1;for(let j=0;j<3;j++)ground.strokeRect(a-27,b+18+j*76,18,48);
        // Stop lines belong before each marked crossing.
        ground.fillStyle=night?'#b8c4cb':'#eee9db';ground.fillRect(a-58,b-14,45,2);ground.fillRect(a-14,b-58,2,45);
        if(d===landmarkDistrict){rr(ground,a+16,b+16,228,228,8,night?'#67758b':'#d9d2be');ground.strokeStyle=night?'#b0bad1':'#b6ad95';ground.lineWidth=2;for(let z=24;z<100;z+=17)ground.strokeRect(a+z,b+z,260-z*2,260-z*2);}
      }
      ground.fillStyle=night?'#abb7c688':'#eff0e488';ground.font='10px system-ui';ground.textAlign='center';const avenue=Math.floor(map.rows/2)*T+55;for(let col=0;col<map.cols;col+=2)ground.fillText(config.map==='harbor'?'QUAY AVENUE':'CENTRAL AVENUE',col*T+210,avenue);
    }
    paintGround();
    const rankOrder=()=>[...players].sort((a,b)=>b.score-a.score);
    function project(wx,wy,z=0){return {x:logicalW/2+(wx-camera.x-wy+camera.y)*.78*zoom,y:logicalH*.56+(wx-camera.x+wy-camera.y)*.43*zoom-z*zoom};}
    function ellipse(wx,wy,r,color,stroke){const p=project(wx,wy);ctx.beginPath();ctx.ellipse(p.x,p.y,r*1.103*zoom,r*.608*zoom,0,0,Math.PI*2);if(color){ctx.fillStyle=color;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=Math.max(2,3*zoom);ctx.stroke();}}
    function architecture(o){
      const def=TYPES[o.type],v=o.variant;
      if(!['tower','house','kiosk'].includes(o.type))return {w:o.type==='car'?8:def.r,d:o.type==='car'?18:def.r,h:def.h};
      const narrow=[1,.82,.78,.96,.88,.7],depth=[.68,.96,.8,.72,.9,1];
      let height=o.type==='tower'?def.h*(.7+v*.12):o.industrial?30+v*2:def.h*(o.zone==='village'?.65+v*.06:.85+v*.05);
      return {w:def.r*narrow[v],d:def.r*depth[v],h:height};
    }
    function sprite(o){
      const cacheKey=o.type+':'+o.variant+':'+!!o.industrial+':'+(o.zone||'');if(spriteCache.has(cacheKey))return spriteCache.get(cacheKey);
      const def=TYPES[o.type],{w,d,h}=architecture(o),pad=20;
      const sw=Math.ceil((w+d)*1.56)+pad*2,sh=Math.ceil((w+d)*.86+h)+pad*2,ratio=1.6;
      const image=document.createElement('canvas');image.width=Math.ceil(sw*ratio);image.height=Math.ceil(sh*ratio);const g=image.getContext('2d');g.scale(ratio,ratio);
      const anchor={x:sw/2,y:sh-pad-(w+d)*.43};g.translate(anchor.x,anchor.y);
      const p=(a,b,z=0)=>({x:(a-b)*.78,y:(a+b)*.43-z});
      function poly(points,color){g.fillStyle=color;g.beginPath();points.forEach((q,i)=>i?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y));g.closePath();g.fill();}
      function box(a,b,cx,cy,z,pal,base=0){const corners=[[-cx,-cy],[cx,-cy],[cx,cy],[-cx,cy]],low=corners.map(([x,y])=>p(a+x,b+y,base)),top=corners.map(([x,y])=>p(a+x,b+y,z));poly([low[1],low[2],top[2],top[1]],pal[1]);poly([low[2],low[3],top[3],top[2]],pal[2]);poly(top,pal[0]);return {top,low};}
      // Directional ground shadows are drawn once per visible object in the world pass.
      const stone=[['#eedbb6','#aa8b70','#ccb291'],['#f2c4a4','#b57a65','#d39e85'],['#d8d8ca','#8c978b','#b0b9aa'],['#e3d5bc','#9e8b76','#c1ae95'],['#cfdbe2','#798f9e','#a2b8c3'],['#e8c9b3','#9b7d75','#c6a492']][o.variant%6];
      if(o.type==='lamp'||o.type==='signal'){box(0,0,1.5,1.5,h-5,['#b0b6ac','#596770','#87918b']);const tip=p(7,0,h-7);g.strokeStyle='#74838a';g.lineWidth=2;g.beginPath();g.moveTo(0,-h+5);g.lineTo(tip.x,tip.y);g.stroke();if(o.type==='lamp'){g.fillStyle=night?'#ffe7ad':'#dad9c7';g.beginPath();g.ellipse(tip.x,tip.y,5,2,0,0,Math.PI*2);g.fill();}else{g.fillStyle='#263c42';g.fillRect(-4,-h+4,8,15);for(let j=0;j<3;j++){g.fillStyle=['#c58a79','#d5bb78','#7fb49b'][j];g.beginPath();g.arc(0,-h+7+j*4,1.4,0,Math.PI*2);g.fill();}}}
      else if(o.type==='bollard'){box(0,0,3,3,9,['#f9e8a8','#7c8c91','#c3ced0']);}
      else if(o.type==='person'){const shirt=['#f7b7a7','#8bc7d5','#c0b1e1','#e9ca84','#b0ce94','#ddd9ce'][o.variant];box(0,0,2,2,10,[shirt,shirt,'#56667c']);g.fillStyle='#ebc7aa';g.beginPath();g.arc(0,-13,3,0,Math.PI*2);g.fill();}
      else if(o.type==='bench'){box(0,0,10,4,5,['#c99b65','#745a44','#9b774d']);box(0,-3,10,2,10,['#d2ac72','#806044','#a28158'],5);}
      else if(o.type==='tree'){box(0,0,2,2,18,['#a88760','#72523d','#927145']);const crown=p(0,0,27);if(o.variant%3===2){poly([{x:-12,y:-13},{x:0,y:-43},{x:12,y:-13}],night?'#4c7970':'#57774e');poly([{x:-9,y:-24},{x:0,y:-45},{x:9,y:-24}],night?'#71968a':'#7d9465');}else{g.fillStyle=night?'#3c7c7a':['#536f49','#617d50','#687c4f'][o.variant%3];g.beginPath();g.ellipse(crown.x+3,crown.y+3,14,16,0,0,Math.PI*2);g.fill();g.fillStyle=night?'#6fada2':['#91a56e','#849c64','#a2ad7a'][o.variant%3];g.beginPath();g.ellipse(crown.x-3,crown.y-3,12,13,0,0,Math.PI*2);g.fill();}}
      else if(o.type==='car'){const color=['#da8b6c','#e3c880','#9ebad1','#c1d6c6','#b49bcd','#e4deda'][o.variant];box(0,0,8,18,8,[color,'#657582','#85969c']);box(0,-1,6,10,15,['#bfd5e1','#36586b','#7195a5'],8);const front=p(0,18,5);g.fillStyle='#fff1af';g.fillRect(front.x-5,front.y-2,3,2);g.fillRect(front.x+3,front.y-2,3,2);}
      else if(o.type==='fountain'){box(0,0,19,19,5,['#a7d5d6','#7d9c9e','#b0b8ad']);g.fillStyle=night?'#74d3ff':'#6cb9cb';g.beginPath();g.ellipse(0,-5,21,11,0,0,Math.PI*2);g.fill();box(0,0,3,3,18,['#e7eee1','#9caaa4','#c9d6c7']);}
      else if(o.type==='landmark'){
        if(config.map==='oldtown'){box(0,0,38,38,210,stone);box(0,0,46,46,220,['#e3ce93','#7f685b','#b49774'],200);poly([p(-46,-46,220),p(46,-46,220),p(0,0,252)],'#8a6a68');poly([p(46,-46,220),p(46,46,220),p(0,0,252)],'#705863');const face=p(0,39,185);g.fillStyle='#f8edc4';g.beginPath();g.arc(face.x,face.y,10,0,Math.PI*2);g.fill();g.strokeStyle='#665c60';g.beginPath();g.moveTo(face.x,face.y-7);g.lineTo(face.x,face.y);g.lineTo(face.x+5,face.y+3);g.stroke();}
        else{box(0,0,80,80,16,['#e7d8b1','#7a8b99','#a5b3bc']);box(0,0,55,55,145,[night?'#a6b9e9':'#b3d3df','#3c6380','#779eae'],16);box(0,0,39,39,225,['#c3e2df','#476e89','#82acb7'],145);box(0,0,22,22,245,['#fff0b8','#a49872','#d5c99b'],225);g.strokeStyle=night?'#d5b3f4':'#b9dfdf';g.lineWidth=1;g.beginPath();for(let z=30;z<218;z+=14){const w=z<145?55:39;const left=p(-w,w,z),middle=p(w,w,z),right=p(w,-w,z);g.moveTo(left.x,left.y);g.lineTo(middle.x,middle.y);g.lineTo(right.x,right.y);}g.stroke();g.strokeStyle=night?'#e7baff':'#f7e8b5';g.lineWidth=3;g.beginPath();g.moveTo(0,-245);g.lineTo(0,-265);g.stroke();}
      }else{
        const glass=o.type==='tower'&&o.variant%2===0,pal=o.industrial?['#b1b8b2','#778787','#929d97']:glass?[night?'#8ca6d0':'#b1c0c4',night?'#3e5384':'#667d89',night?'#506b9b':'#8ca0a8']:stone;
        if(o.type==='tower'&&o.variant===2){const gr=g.createLinearGradient(-w,0,w,0);gr.addColorStop(0,night?'#335082':'#4c7894');gr.addColorStop(.45,night?'#7f94bf':'#9bbaca');gr.addColorStop(1,night?'#40527e':'#537b93');g.fillStyle=gr;g.beginPath();g.ellipse(0,-h,w*1.1,w*.61,0,Math.PI,Math.PI*2);g.lineTo(w*1.1,0);g.ellipse(0,0,w*1.1,w*.61,0,0,Math.PI);g.closePath();g.fill();for(let z=14;z<h;z+=17){g.strokeStyle=night?'#b6b7ec99':'#c0d3dd88';g.beginPath();g.ellipse(0,-z,w*1.1,w*.61,0,0,Math.PI);g.stroke();}g.fillStyle=pal[0];g.beginPath();g.ellipse(0,-h,w*1.1,w*.61,0,0,Math.PI*2);g.fill();}
        else{box(0,0,w,d,h,pal);g.beginPath();for(let z=11;z<h-9;z+=o.type==='tower'?17:16)for(let a=-Math.min(w,d)+8;a<Math.min(w,d)-3;a+=14){const q=[p(a-3,d,z),p(a+3,d,z),p(a+3,d,z+8),p(a-3,d,z+8)];q.forEach((q,i)=>i?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y));g.closePath();const v=[p(w,a-3,z),p(w,a+3,z),p(w,a+3,z+8),p(w,a-3,z+8)];v.forEach((q,i)=>i?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y));g.closePath();}g.fillStyle=night?['#ffda9c','#8ee6f4','#c5c0fa'][o.variant%3]:glass?'#b2cddd':'#4d6776';g.fill();}
        const rooftop=p(0,0,h);g.fillStyle=night?'#a8a7c3':'#8f9fa6';g.fillRect(rooftop.x-8,rooftop.y-5,16,8);g.strokeStyle='#ffffff65';g.lineWidth=1;const roof=[p(-w+3,-d+3,h),p(w-3,-d+3,h),p(w-3,d-3,h),p(-w+3,d-3,h)];g.beginPath();roof.forEach((q,i)=>i?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y));g.closePath();g.stroke();
        if(o.type==='house'&&o.zone==='village'){
          const rise=14,tiles=['#a87661','#947b69','#ad8064','#8e7970','#a88f76','#9b7166'][o.variant];
          poly([p(-w,-d,h),p(0,-d,h+rise),p(0,d,h+rise),p(-w,d,h)],tiles);
          poly([p(0,-d,h+rise),p(w,-d,h),p(w,d,h),p(0,d,h+rise)],'#846c60');box(-w*.35,-d*.3,3,3,h+20,['#c4b6a0','#826e64','#a0907c'],h+7);
        }else if(o.type==='tower'||o.industrial){box(-w*.3,-d*.3,7,5,h+5,['#b4bdba','#687b82','#89989a'],h);if(o.variant%2===1){const z=h+1;poly([p(2,0,z),p(w-5,0,z),p(w-5,d-6,z),p(2,d-6,z)],'#436674');g.strokeStyle='#92a7a8';g.lineWidth=.6;g.beginPath();const a=p(3,(d-6)/2,z),b=p(w-5,(d-6)/2,z);g.moveTo(a.x,a.y);g.lineTo(b.x,b.y);g.stroke();}}
        if(o.type==='house'&&!o.industrial){g.strokeStyle='#65777d26';g.lineWidth=.5;g.beginPath();for(let z=6;z<h;z+=6){const a=p(-w,d,z),b=p(w,d,z),c=p(w,-d,z);g.moveTo(a.x,a.y);g.lineTo(b.x,b.y);g.lineTo(c.x,c.y);}g.stroke();}
        const door=[p(-5,d,0),p(5,d,0),p(5,d,15),p(-5,d,15)];poly(door,night?'#ebd9aa':'#516366');
        if(o.type==='kiosk'){const awning=['#899c89','#b7927f','#a99f7d','#8b9fac','#a4949a','#94a196'][o.variant];poly([p(-w-2,d,18),p(w+2,d,18),p(w+2,d+7,14),p(-w-2,d+7,14)],awning);}
        if(night){g.strokeStyle=['#cf9aff','#78e4ef','#f3b1d8'][o.variant%3];g.lineWidth=2;g.beginPath();g.moveTo(...[p(w,d,0).x,p(w,d,0).y]);g.lineTo(...[p(w,d,h).x,p(w,d,h).y]);g.stroke();}
      }
      const result={image,w:sw,h:sh,ax:anchor.x,ay:anchor.y,height:h};spriteCache.set(cacheKey,result);return result;
    }
    function drawMap(large){
      const mw=large?Math.min(logicalW-70,620):150,mh=mw*H/W,left=large?(logicalW-mw)/2:logicalW-mw-18,top=large?(logicalH-mh)/2:logicalH-mh-20;
      rr(ctx,left-8,top-8,mw+16,mh+16,12,'#081725e8');ctx.drawImage(groundCanvas,left,top,mw,mh);
      if(!objects.find(o=>o.type==='landmark').eaten){ctx.fillStyle='#ffe4a4';const o=objects.find(o=>o.type==='landmark');ctx.fillRect(left+o.x/W*mw-3,top+o.y/H*mh-3,6,6);}
      for(const p of players){ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(left+p.x/W*mw,top+p.y/H*mh,p===me?4:3,0,Math.PI*2);ctx.fill();}
      if(large){ctx.fillStyle='#e8f9f1';ctx.font='bold 17px system-ui';ctx.textAlign='center';ctx.fillText(map.name+' · M schließt die Karte',logicalW/2,top-22);}
    }
    function render(){
      ctx.setTransform(dpr,0,0,dpr,0,0);ctx.globalAlpha=1;
      const follow=phase==='playing'?.12:1;camera.x+=(me.x-camera.x)*follow;camera.y+=(me.y-camera.y)*follow;zoom+=(.96/(1+Math.max(0,me.r-25)/160)-zoom)*.075;
      const water=ctx.createLinearGradient(0,0,0,logicalH);water.addColorStop(0,map.water[0]);water.addColorStop(1,map.water[1]);ctx.fillStyle=water;ctx.fillRect(0,0,logicalW,logicalH);
      if(config.effects&&!reduced){ctx.strokeStyle=night?'#a6b8df13':'#d2f4ff18';ctx.lineWidth=1;for(let i=0;i<15;i++){const sy=(i*89+elapsed*3)%logicalH;ctx.beginPath();ctx.moveTo((i*137)%logicalW,sy);ctx.lineTo((i*137)%logicalW+40,sy);ctx.stroke();}}
      ctx.save();if(shake&&config.effects&&!reduced)ctx.translate(Math.sin(elapsed*41)*shake,Math.cos(elapsed*47)*shake*.5);
      for(let i=0;i<5;i++){const wx=-85,wy=180+i*(H-300)/5,at=project(wx,wy,config.effects&&!reduced?Math.sin(elapsed*.8+i)*1.2:0);if(at.x<-100||at.x>logicalW+100||at.y<-100||at.y>logicalH+100)continue;ctx.save();ctx.translate(at.x,at.y);ctx.scale(zoom,zoom);ctx.fillStyle='#102e4930';ctx.beginPath();ctx.ellipse(3,8,28,12,-.35,0,Math.PI*2);ctx.fill();ctx.fillStyle=night?'#778fa5':'#e8e3d2';ctx.beginPath();ctx.moveTo(-29,2);ctx.lineTo(17,-16);ctx.lineTo(32,-3);ctx.lineTo(-12,16);ctx.closePath();ctx.fill();ctx.fillStyle='#899b9e';ctx.fillRect(-5,-12,16,10);ctx.strokeStyle='#c4c5b4';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,-36);ctx.stroke();ctx.restore();}
      // Foundations are short vertical walls; streets and roof sprites remain cached.
      for(const d of districts){if(districtLookup.has((d.col+1)+','+d.row)&&districtLookup.has(d.col+','+(d.row+1)))continue;const a=project(d.x,d.y+260),b=project(d.x+260,d.y+260),q=project(d.x+260,d.y);ctx.fillStyle=night?'#34405b':'#a1b5bb';ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.lineTo(q.x,q.y);ctx.lineTo(q.x,q.y+9*zoom);ctx.lineTo(b.x,b.y+9*zoom);ctx.lineTo(a.x,a.y+9*zoom);ctx.closePath();ctx.fill();}
      ctx.save();const a=.78*zoom,b=.43*zoom;ctx.transform(a,b,-a,b,logicalW/2-a*(camera.x-camera.y),logicalH*.56-b*(camera.x+camera.y));ctx.drawImage(groundCanvas,0,0,W,H);ctx.restore();
      for(const ring of rings){ctx.globalAlpha=1-ring.t;ellipse(ring.x,ring.y,ring.r,null,ring.color);}ctx.globalAlpha=1;
      const sorted=objects.filter(o=>{if(o.eaten)return false;const p=project(o.x,o.y);return p.x>-230&&p.x<logicalW+230&&p.y>-80&&p.y<logicalH+340;}).sort((a,b)=>(a.x+a.y)-(b.x+b.y));
      if(!night)for(const o of sorted){if(o.fall||TYPES[o.type].h<12)continue;const a=architecture(o),sx=a.h*.42,sy=a.h*.13,corners=[[-a.w,-a.d],[a.w,-a.d],[a.w+sx,a.d+sy],[-a.w+sx,a.d+sy]].map(([wx,wy])=>project(o.x+wx,o.y+wy));ctx.fillStyle='#243b4a24';ctx.beginPath();corners.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fill();}
      if(night&&quality!=='low')for(const o of sorted)if(o.type==='lamp'&&!o.eaten){ctx.globalAlpha=.09;ellipse(o.x+8,o.y,23,'#ffe7ad');ctx.globalAlpha=1;}
      const rank=rankOrder();for(const p of [...players].sort((a,b)=>radius(b)-radius(a))){const at=project(p.x,p.y),r=radius(p);ctx.globalAlpha=p.shield>elapsed?.55:1;ellipse(p.x+4,p.y+5,r+4,'#0004');ellipse(p.x,p.y,r,'#030610',p.color);ellipse(p.x,p.y,r*.72,'#01030a');ctx.strokeStyle=p.color+'50';ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(at.x,at.y,r*.68*1.103*zoom,r*.68*.608*zoom,0,0,Math.PI*2);ctx.stroke();if(p===me&&p.power.magnet>elapsed){ctx.globalAlpha=.12;ellipse(p.x,p.y,r*2.6,p.color);}ctx.globalAlpha=1;}
      for(const o of sorted){const asset=sprite(o),t=o.fall?.t||0,owner=o.fall?.owner;let wx=o.x,wy=o.y,scale=1;
        if(owner){wx=o.fall.sx+(owner.x-o.fall.sx)*Math.min(1,t*1.5);wy=o.fall.sy+(owner.y-o.fall.sy)*Math.min(1,t*1.5);scale=1-t*.45;}
        const p=project(wx,wy),z=zoom*scale;ctx.save();
        if(owner){const at=project(owner.x,owner.y),r=radius(owner),rx=r*1.103*zoom;ctx.beginPath();ctx.rect(0,0,logicalW,Math.max(0,at.y));ctx.moveTo(at.x+rx,at.y);ctx.ellipse(at.x,at.y,rx,r*.608*zoom,0,0,Math.PI*2);ctx.clip();ctx.globalAlpha=1-t*t*.75;}
        else if(asset.height>60&&p.y>logicalH*.56&&p.y-asset.height*zoom<logicalH*.56+35&&Math.abs(p.x-logicalW/2)<(TYPES[o.type].r*1.3+radius(me))*zoom)ctx.globalAlpha=.38;
        if(owner&&TYPES[o.type].h>60){ctx.translate(p.x,p.y+t*asset.height*zoom*.72);ctx.rotate(t*.12*(o.variant%2?1:-1));ctx.drawImage(asset.image,-asset.ax*z,-asset.ay*z,asset.w*z,asset.h*z);}else ctx.drawImage(asset.image,p.x-asset.ax*z,p.y-asset.ay*z+(owner?t*asset.height*zoom*.72:0),asset.w*z,asset.h*z);ctx.restore();
        if(o.type==='signal'&&!owner){const green=(Math.floor(elapsed/6)+Math.floor(o.x/T))%2===0,light=project(o.x,o.y,TYPES.signal.h-(green?15:7));ctx.fillStyle=green?'#b8dfb1':'#e7a092';ctx.beginPath();ctx.arc(light.x,light.y,Math.max(.8,1.6*zoom),0,Math.PI*2);ctx.fill();}
      }
      for(const power of powers){const at=project(power.x,power.y,19+Math.sin(elapsed*3+power.x)*4),info=POWER[power.type];ctx.fillStyle=info.color+'35';ctx.beginPath();ctx.arc(at.x,at.y,20*zoom,0,Math.PI*2);ctx.fill();ctx.fillStyle=info.color;ctx.font='bold '+Math.max(16,24*zoom)+'px system-ui';ctx.textAlign='center';ctx.fillText(info.symbol,at.x,at.y+7*zoom);}
      for(const p of players){const at=project(p.x,p.y);ctx.font='bold 12px system-ui';ctx.textAlign='center';ctx.lineWidth=4;ctx.strokeStyle='#14202be0';ctx.strokeText(p.name,at.x,at.y+5);ctx.fillStyle=p.color;ctx.fillText(p.name,at.x,at.y+5);
        if(p===rank[0]&&!explore){const crown=project(p.x,p.y,radius(p)*.75+15);ctx.fillStyle='#ffe4a0';ctx.beginPath();ctx.moveTo(crown.x-11,crown.y+6);ctx.lineTo(crown.x-14,crown.y-5);ctx.lineTo(crown.x-5,crown.y);ctx.lineTo(crown.x,crown.y-9);ctx.lineTo(crown.x+5,crown.y);ctx.lineTo(crown.x+14,crown.y-5);ctx.lineTo(crown.x+11,crown.y+6);ctx.closePath();ctx.fill();}}
      for(const p of particles){const at=project(p.x,p.y,p.z);ctx.globalAlpha=clamp(p.life*2,0,1);ctx.fillStyle=p.color;ctx.fillRect(at.x-2,at.y-2,4,4);}ctx.globalAlpha=1;
      for(const p of popups){const at=project(p.x,p.y,20+(1-p.life/p.max)*55);ctx.globalAlpha=Math.min(1,p.life*2);ctx.font='bold '+(p.text.length>10?15:18)+'px system-ui';ctx.textAlign='center';ctx.lineWidth=3;ctx.strokeStyle='#112030a0';ctx.strokeText(p.text,at.x,at.y);ctx.fillStyle=p.color;ctx.fillText(p.text,at.x,at.y);}ctx.globalAlpha=1;ctx.restore();
      if(!explore){const top=logicalW<600?3:4;rank.slice(0,top).forEach((p,i)=>{rr(ctx,logicalW-210,14+i*34,195,28,14,'#071626d9');ctx.font='bold 12px system-ui';ctx.textAlign='left';ctx.fillStyle=p.color;ctx.fillText((i+1)+'. '+p.name+'  ·  '+p.score,logicalW-198,33+i*34);});}
      rr(ctx,18,18,160,64,16,'#071626df');ctx.textAlign='left';ctx.fillStyle='#edfdf5';ctx.font='bold 24px system-ui';ctx.fillText(explore?'ENTDECKEN':Math.ceil(remaining)+' s',30,48);ctx.fillStyle='#a9b9c8';ctx.font='11px system-ui';ctx.fillText('LEVEL '+(level+1)+' · '+Math.round(eatenCount/initialCount*100)+' % STADT',30,68);
      const powerActive=Object.entries(me.power).filter(([,until])=>until>elapsed);powerActive.forEach(([key,until],i)=>{rr(ctx,18,96+i*29,165,24,8,'#071626dc');ctx.fillStyle=POWER[key].color;ctx.font='bold 11px system-ui';ctx.textAlign='left';ctx.fillText(POWER[key].name+' · '+Math.ceil(until-elapsed)+' s',27,112+i*29);});
      if(combo>=8&&elapsed<comboUntil){ctx.textAlign='center';ctx.font='bold 22px system-ui';ctx.fillStyle='#ffe7a4';ctx.fillText('×'+(1+Math.min(2,Math.floor(combo/8)*.25)).toFixed(2)+'  ·  '+combo+' KOMBO',logicalW/2,45);}
      rr(ctx,20,logicalH-39,180,10,5,'#ffffff30');rr(ctx,20,logicalH-39,Math.max(2,energy*180),10,5,energy>.2?'#a6ffe4':'#ffbf89');ctx.fillStyle='#e5fff4';ctx.font='11px system-ui';ctx.textAlign='left';ctx.fillText('BOOST · '+Math.round(energy*100)+'%',20,logicalH-49);
      if(pointer?.anchor){const q=pointer.anchor,dx=pointer.x-q.x,dy=pointer.y-q.y,len=Math.hypot(dx,dy)||1;ctx.strokeStyle='#f1fff580';ctx.lineWidth=3;ctx.beginPath();ctx.arc(q.x,q.y,45,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#a6ffe4c0';ctx.beginPath();ctx.arc(q.x+dx/len*Math.min(32,len),q.y+dy/len*Math.min(32,len),15,0,Math.PI*2);ctx.fill();}
      drawMap(bigMap);
    }
    function updateHud(){statNodes[0].textContent=explore?'∞':Math.ceil(remaining)+' s';statNodes[1].textContent=me.score.toLocaleString('de-CH');statNodes[2].textContent='Level '+(level+1);statNodes[3].textContent=Math.round(eatenCount/initialCount*100)+' %';missionsBox.replaceChildren();
      for(const m of missions.slice(missionIndex,missionIndex+3)){const card=c.el('div','hole-mission'),v=Math.min(m.goal,counts[m.key]),track=c.el('div','hole-track'),fill=c.el('i');fill.style.width=v/m.goal*100+'%';track.append(fill);card.append(c.el('b','',(m.done?'✓ ':'')+m.name),c.el('span','',v+' / '+m.goal+' · +'+m.reward+' Punkte'),track);missionsBox.append(card);}if(missions[0].done&&missionIndex===0)missionIndex=1;
      boostButton.disabled=phase!=='playing';pause.textContent=phase==='ready'?'Starten':phase==='playing'?'Pause':'Weiter';if(phase==='finished'){pause.textContent='Runde beendet';pause.disabled=true;}}
    function frame(now){if(dead||!canvas.isConnected)return;const dt=Math.min(.05,Math.max(0,(now-lastTime)/1000));lastTime=now;
      if(phase==='playing'&&!document.hidden)step(dt);
      const cap=phase==='playing'?(quality==='high'?60:quality==='low'?30:45):15;
      if(now-lastDraw>=1000/cap){render();lastDraw=now;}if(elapsed-lastHud>.2||lastHud<0){updateHud();lastHud=elapsed;}
      frameId=requestAnimationFrame(frame);
    }
    announce('Kleine Dinge zuerst. Der goldene Punkt auf der Karte ist das Wahrzeichen.');showOverlay();updateHud();frameId=requestAnimationFrame(frame);
    c.cleanup(()=>{dead=true;cancelAnimationFrame(frameId);observer.disconnect();document.removeEventListener('keyup',keyup);window.removeEventListener('blur',pauseBackground);document.removeEventListener('visibilitychange',visibility);window.removeEventListener('pagehide',pauseBackground);resetInput();muteAudio();audioContext?.close().catch(()=>{});spriteCache.clear();groundCanvas.width=groundCanvas.height=1;});
  }
})();
